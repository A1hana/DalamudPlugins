using AihanaTuner.Core;
using Dalamud.Configuration;

namespace AihanaTuner;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    public TuningSettings Settings { get; set; } = new();
    public bool ShowHud = true;
    public bool LockHud;
    public void Normalize() { Settings ??= new(); Settings.Normalize(); }
}
