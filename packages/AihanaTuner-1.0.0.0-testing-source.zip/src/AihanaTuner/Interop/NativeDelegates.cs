namespace AihanaTuner.Interop;

// Win64 uses floating-point positional registers: rotation=XMM1, distance=XMM2,
// duration=XMM3. Never replace the duration parameter with an integer/pointer.
public static class NativeDelegates
{
    public delegate float Speed(nint representation);
    public delegate float Range(uint actionId);
    public delegate byte Displacement(nint gameObject, float rotation, float distance, float duration, byte arg5, int arg6);
    // The fifth native argument is read with MOVSS from the stack in this CN build.
    public delegate void ForcedAction(nint gameObject, float x, float y, float z, float duration, nint arg6);
}
