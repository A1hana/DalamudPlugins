using Dalamud.Hooking;

namespace AihanaTuner.Interop;

internal sealed class HookSlot<T>(string name, Services services) : IDisposable where T : Delegate
{
    private Hook<T>? hook;
    public string Name => name;
    public string? Error { get; private set; }
    public bool Available => hook != null && Error == null;
    public bool Enabled => hook?.IsEnabled == true;
    public T Original => hook!.Original;
    public string State => Error != null ? $"不可用：{Error}" : hook == null ? "未初始化" : Enabled ? "已挂接" : "已停用";

    public void Initialize(Func<Hook<T>> factory)
    {
        try { hook = factory(); }
        catch (Exception ex) { Error = ex.Message; services.Log.Error(ex, "AihanaTuner cannot initialize {Feature}", name); }
    }

    public void SetEnabled(bool enabled)
    {
        if (hook == null || enabled && Error != null) return;
        try
        {
            if (enabled && !hook.IsEnabled) hook.Enable();
            else if (!enabled && hook.IsEnabled) hook.Disable();
        }
        catch (Exception ex) { Error = ex.Message; services.Log.Error(ex, "AihanaTuner cannot toggle {Feature}", name); }
    }

    public void Dispose()
    {
        if (hook == null) return;
        try { hook.Dispose(); }
        catch (Exception ex) { services.Log.Error(ex, "AihanaTuner cannot dispose {Feature}", name); }
        hook = null;
    }
}
