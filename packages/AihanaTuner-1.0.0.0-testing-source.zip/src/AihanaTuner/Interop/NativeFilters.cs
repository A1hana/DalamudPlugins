using AihanaTuner.Core;

namespace AihanaTuner.Interop;

public static class NativeFilters
{
    public static byte Displace(RuntimeState state, NativeDelegates.Displacement original,
        nint gameObject, float rotation, float distance, float duration, byte arg5, int arg6)
    {
        var adjusted = state.IsLocalObject(gameObject) ? TuningMath.Displacement(distance, state.Settings) : distance;
        // The tested adapter ALWAYS invokes the original exactly once, even when adjusted == 0.
        return original(gameObject, rotation, adjusted, duration, arg5, arg6);
    }

    public static bool BlockStatus(RuntimeState state, nint manager, int slot, ushort statusId) =>
        state.IsLocalManager(manager) && slot is >= 0 and < 60 && state.Blocks(statusId);

    public static bool IgnoreForcedAction(RuntimeState state, nint gameObject, bool knownControlPresent) =>
        state.IsLocalObject(gameObject) && state.Settings.IgnoreCharmFear &&
        (!state.Settings.CharmFearOnlyWhenPresent || knownControlPresent);
}
