using AihanaTuner.Core;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Hooking;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Character;
using FFXIVClientStructs.FFXIV.Client.Game.Object;

namespace AihanaTuner.Interop;

internal sealed record DistanceSample(float Original, float Modified, float Duration);
internal sealed record LiveStatus(ushort Id, float Remaining);
internal sealed record FeatureHealth(string Name, string State, bool Available, bool Enabled);

internal sealed unsafe class TuningEngine : IDisposable
{
    private readonly Services services;
    private readonly HookSlot<NativeDelegates.Speed> speed;
    private readonly HookSlot<NativeDelegates.Range> range;
    private readonly HookSlot<NativeDelegates.Displacement> displacement;
    private readonly HookSlot<NativeDelegates.ForcedAction> charmFear;
    private readonly HookSlot<StatusManager.Delegates.SetStatus> status;
    private RuntimeState state = RuntimeState.Inactive;
    private TuningSettings requested;
    private TuningSettings? lastApplied;
    private nint lastObject;
    private nint lastManager;
    private nint lastRepresentation;
    private bool disposed;
    private long nextLiveScan;
    private long nextErrorLog;
    private long speedCalls, rangeCalls, displacementCalls, charmCalls, incomingStatuses, existingStatuses;
    private int lastBlockedStatus;
    private DistanceSample? lastDisplacement;
    public string Activity { get; private set; } = "总开关关闭";
    public bool Ready { get; private set; }
    public LiveStatus[] LiveStatuses { get; private set; } = [];
    public long SpeedCalls => Interlocked.Read(ref speedCalls);
    public long RangeCalls => Interlocked.Read(ref rangeCalls);
    public long DisplacementCalls => Interlocked.Read(ref displacementCalls);
    public long CharmCalls => Interlocked.Read(ref charmCalls);
    public long IncomingStatuses => Interlocked.Read(ref incomingStatuses);
    public long ExistingStatuses => Interlocked.Read(ref existingStatuses);
    public ushort LastBlockedStatus => (ushort)Volatile.Read(ref lastBlockedStatus);
    public DistanceSample? LastDisplacement => Volatile.Read(ref lastDisplacement);

    public TuningEngine(Services services, TuningSettings initial)
    {
        this.services = services;
        requested = initial.Copy(); requested.Normalize();
        speed = new("移速倍率", services);
        range = new("技能射程", services);
        displacement = new("受迫位移倍率", services);
        charmFear = new("魅惑恐惧移动", services);
        status = new("本地状态屏蔽", services);
        // Hook objects are prepared disabled. A feature is installed only when explicitly enabled.
        speed.Initialize(() => FromSignature(Signatures.Speed, (NativeDelegates.Speed)SpeedDetour));
        range.Initialize(() => FromSignature(Signatures.Range, (NativeDelegates.Range)RangeDetour));
        displacement.Initialize(() => FromSignature(Signatures.Displacement, (NativeDelegates.Displacement)DisplacementDetour));
        charmFear.Initialize(() => FromSignature(Signatures.ForcedAction, (NativeDelegates.ForcedAction)ForcedActionDetour));
        status.Initialize(() =>
        {
            var address = StatusManager.Addresses.SetStatus.Value;
            if (address == 0 || StatusManager.Addresses.RemoveStatus.Value == 0)
                throw new InvalidOperationException("当前 ClientStructs 尚未解析状态函数");
            return services.Interop.HookFromAddress<StatusManager.Delegates.SetStatus>(address, SetStatusDetour);
        });
    }

    private Hook<T> FromSignature<T>(string signature, T detour) where T : Delegate
    {
        var matches = services.Scanner.ScanAllText(signature);
        if (matches.Length != 1)
            throw new InvalidOperationException($"函数匹配数为 {matches.Length}，需要唯一匹配");
        // ScanText follows relative call signatures, ScanAllText only checks uniqueness.
        return services.Interop.HookFromAddress(services.Scanner.ScanText(signature), detour);
    }

    public FeatureHealth[] Health =>
    [new(speed.Name, speed.State, speed.Available, speed.Enabled),
     new(range.Name, range.State, range.Available, range.Enabled),
     new(displacement.Name, displacement.State, displacement.Available, displacement.Enabled),
     new(status.Name, status.State, status.Available, status.Enabled),
     new(charmFear.Name, charmFear.State, charmFear.Available, charmFear.Enabled)];

    public void Apply(TuningSettings settings)
    {
        var next = settings.Copy(); next.Normalize();
        Volatile.Write(ref requested, next);
        // Off takes effect in the detours immediately; physical unhooking stays on the framework thread.
        if (!next.Enabled) Volatile.Write(ref state, RuntimeState.Inactive);
    }

    public void Suspend()
    {
        Volatile.Write(ref state, RuntimeState.Inactive);
        lastApplied = null;
        LiveStatuses = [];
        Ready = false;
    }

    public void Update()
    {
        if (disposed) return;
        try
        {
            var settings = Volatile.Read(ref requested);
            var local = services.Objects.LocalPlayer;
            var transitioning = !services.Client.IsLoggedIn || services.Conditions[ConditionFlag.BetweenAreas] ||
                services.Conditions[ConditionFlag.BetweenAreas51] || services.Conditions[ConditionFlag.WatchingCutscene] ||
                services.Conditions[ConditionFlag.WatchingCutscene78] || services.Conditions[ConditionFlag.OccupiedInCutSceneEvent];
            Ready = !transitioning && local is { IsDead: false, CurrentHp: > 0, Address: not 0 };
            if (!Ready || local == null)
            {
                Suspend(); SyncHooks(new());
                Activity = "角色未就绪、已倒地或区域加载中";
                return;
            }
            var character = (Character*)local.Address;
            var manager = character->GetStatusManager();
            var representation = (nint)(&character->RepresentationContainer);
            if (!ReferenceEquals(lastApplied, settings) || lastObject != local.Address ||
                lastManager != (nint)manager || lastRepresentation != representation)
            {
                Volatile.Write(ref state, RuntimeState.Inactive);
                SyncHooks(settings);
                var effective = settings.Copy();
                effective.SpeedEnabled &= speed.Available;
                effective.RangeEnabled &= range.Available;
                effective.DisplacementEnabled &= displacement.Available;
                effective.IgnoreCharmFear &= charmFear.Available;
                effective.StatusEnabled &= status.Available;
                Volatile.Write(ref state, new(effective, local.Address, representation, (nint)manager));
                lastApplied = settings;
                lastObject = local.Address; lastManager = (nint)manager; lastRepresentation = representation;
            }
            var snapshot = Volatile.Read(ref state);
            Activity = !settings.Enabled ? "总开关关闭" : "已启用 · 仅本客户端";
            if (manager == null) return;
            var now = Environment.TickCount64;
            if (now >= nextLiveScan)
            {
                LiveStatuses = manager->Status.ToArray().Where(s => s.StatusId != 0)
                    .Select(s => new LiveStatus(s.StatusId, s.RemainingTime)).ToArray();
                nextLiveScan = now + 250;
            }
            if (!snapshot.IsLocalManager((nint)manager) || !snapshot.Settings.StatusEnabled) return;
            // Typed client functions handle flags/counts. No packet layout guessing or raw buffer rewriting.
            for (var i = 0; i < manager->Status.Length; i++)
            {
                var id = manager->Status[i].StatusId;
                if (!snapshot.Blocks(id)) continue;
                manager->RemoveStatus(i, 0);
                Volatile.Write(ref lastBlockedStatus, id);
                Interlocked.Increment(ref existingStatuses);
            }
        }
        catch (Exception ex)
        {
            Suspend(); SyncHooks(new());
            Activity = "读取失败，本次已暂停；详情见 Dalamud 日志";
            if (Environment.TickCount64 >= nextErrorLog)
            {
                services.Log.Error(ex, "AihanaTuner update failed; modifications suspended");
                nextErrorLog = Environment.TickCount64 + 10000;
            }
        }
    }

    private void SyncHooks(TuningSettings s)
    {
        speed.SetEnabled(s.Enabled && s.SpeedEnabled);
        range.SetEnabled(s.Enabled && s.RangeEnabled);
        displacement.SetEnabled(s.Enabled && s.DisplacementEnabled);
        charmFear.SetEnabled(s.Enabled && s.IgnoreCharmFear);
        status.SetEnabled(s.Enabled && s.StatusEnabled);
    }

    private float SpeedDetour(nint representation)
    {
        var original = speed.Original(representation);
        var s = Volatile.Read(ref state);
        if (!s.IsLocalRepresentation(representation)) return original;
        var changed = TuningMath.Speed(original, s.Settings);
        if (changed != original) Interlocked.Increment(ref speedCalls);
        return changed;
    }

    private float RangeDetour(uint actionId)
    {
        var original = range.Original(actionId);
        var s = Volatile.Read(ref state);
        if (!s.Active) return original;
        var changed = TuningMath.Range(original, s.Settings);
        if (changed != original) Interlocked.Increment(ref rangeCalls);
        return changed;
    }

    private byte DisplacementDetour(nint gameObject, float rotation, float distance, float duration, byte arg5, int arg6)
    {
        var s = Volatile.Read(ref state);
        var changed = s.IsLocalObject(gameObject) ? TuningMath.Displacement(distance, s.Settings) : distance;
        if (s.IsLocalObject(gameObject) && s.Settings.DisplacementEnabled)
        {
            Volatile.Write(ref lastDisplacement, new(distance, changed, duration));
            Interlocked.Increment(ref displacementCalls);
        }
        // Always call the original, including a multiplier of zero. Preserve direction, duration,
        // flags and return value; this is distance scaling, not suppression of the whole operation.
        return NativeFilters.Displace(s, displacement.Original, gameObject, rotation, distance, duration, arg5, arg6);
    }

    private void ForcedActionDetour(nint gameObject, float x, float y, float z, float duration, nint arg6)
    {
        var s = Volatile.Read(ref state);
        var knownControl = false;
        if (s.IsLocalObject(gameObject) && s.Settings.IgnoreCharmFear && s.StatusManager != 0)
            foreach (var entry in ((StatusManager*)s.StatusManager)->Status)
                if (Array.IndexOf(StatusLists.CharmFear, entry.StatusId) >= 0) { knownControl = true; break; }
        if (NativeFilters.IgnoreForcedAction(s, gameObject, knownControl))
        { Interlocked.Increment(ref charmCalls); return; }
        charmFear.Original(gameObject, x, y, z, duration, arg6);
    }

    private bool SetStatusDetour(StatusManager* manager, int index, ushort statusId, float remaining,
        ushort param, GameObjectId sourceObject, bool refreshFlags)
    {
        var s = Volatile.Read(ref state);
        if (NativeFilters.BlockStatus(s, (nint)manager, index, statusId))
        {
            Interlocked.Increment(ref incomingStatuses);
            Volatile.Write(ref lastBlockedStatus, statusId);
            return status.Original(manager, index, 0, 0, 0, new GameObjectId { Id = 0xE0000000 }, true);
        }
        return status.Original(manager, index, statusId, remaining, param, sourceObject, refreshFlags);
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        Suspend();
        status.Dispose(); charmFear.Dispose(); displacement.Dispose(); range.Dispose(); speed.Dispose();
    }
}
