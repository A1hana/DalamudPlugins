using System.Globalization;
using AihanaTuner.Core;
using AihanaTuner.Interop;
using AihanaTuner.UI;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace AihanaTuner;

public sealed class Plugin : IDalamudPlugin
{
    private readonly Services services;
    private readonly Configuration config;
    private readonly TuningEngine engine;
    private readonly WindowSystem windows = new("AihanaTuner");
    private readonly MainWindow main;
    private readonly bool ownsCommand;
    private bool disposed;

    public Plugin(IDalamudPluginInterface plugin, ICommandManager commands, IFramework framework, IClientState client,
        IObjectTable objects, ICondition conditions, IGameInteropProvider interop, ISigScanner scanner,
        IDataManager data, IChatGui chat, IPluginLog log)
    {
        services = new(plugin, commands, framework, client, objects, conditions, interop, scanner, data, chat, log);
        config = plugin.GetPluginConfig() as Configuration ?? new();
        config.Normalize();
        engine = new(services, config.Settings);
        main = new(config, engine, data, Save, Stop);
        windows.AddWindow(main);
        windows.AddWindow(new HudWindow(config, engine, () => main.IsOpen = true, Stop));
        ownsCommand = commands.AddHandler("/atune", new CommandInfo(Command)
        { HelpMessage = "战斗调节器。on/off 总开关；speed 倍率；range mul 倍率 或 range add 米数；knock 倍率；status on/off；charm on/off；hud。" });
        if (!ownsCommand) log.Warning("AihanaTuner: /atune is already owned by another plugin.");
        framework.Update += Update;
        client.TerritoryChanged += TerritoryChanged;
        plugin.UiBuilder.Draw += windows.Draw;
        plugin.UiBuilder.OpenConfigUi += Open;
        plugin.UiBuilder.OpenMainUi += Open;
    }

    private void Save() { config.Normalize(); engine.Apply(config.Settings); services.Plugin.SavePluginConfig(config); }
    private void Stop() { config.Settings.Enabled = false; Save(); }
    private void Open() => main.IsOpen = true;
    private void Update(IFramework _) => engine.Update();
    private void TerritoryChanged(uint _) => engine.Suspend();

    private void Command(string command, string args)
    {
        var words = args.Trim().ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var s = config.Settings;
        if (words.Length == 0) { main.Toggle(); return; }
        if (words is ["on"]) s.Enabled = true;
        else if (words is ["off"]) { Stop(); services.Chat.Print("[战斗调节器] 已停用全部修改。"); return; }
        else if (words is ["hud"]) config.ShowHud = !config.ShowHud;
        else if (words is ["status", "on"]) s.StatusEnabled = true;
        else if (words is ["status", "off"]) s.StatusEnabled = false;
        else if (words is ["charm", "on"]) s.IgnoreCharmFear = true;
        else if (words is ["charm", "off"]) s.IgnoreCharmFear = false;
        else if (words is ["speed", var value] && Number(value, 0.1f, 5, out var speed))
        { s.SpeedEnabled = true; s.SpeedMultiplier = speed; }
        else if (words is ["knock", var kbValue] && Number(kbValue, 0, 3, out var kb))
        { s.DisplacementEnabled = true; s.DisplacementMultiplier = kb; }
        else if (words is ["range", "mul", var mulValue] && Number(mulValue, 1, 5, out var mul))
        { s.RangeEnabled = true; s.RangeMode = RangeMode.Multiply; s.RangeMultiplier = mul; }
        else if (words is ["range", "add", var addValue] && Number(addValue, 0, 50, out var add))
        { s.RangeEnabled = true; s.RangeMode = RangeMode.Add; s.RangeAddition = add; }
        else
        {
            services.Chat.Print("[战斗调节器] /atune on|off|hud；speed 0.1~5；range mul 1~5 或 range add 0~50；knock 0~3；status on|off；charm on|off。");
            return;
        }
        Save();
        services.Chat.Print($"[战斗调节器] 已保存。总开关：{(s.Enabled ? "开启" : "关闭，输入 /atune on 启用")}");
    }

    private static bool Number(string text, float min, float max, out float value) =>
        float.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) &&
        float.IsFinite(value) && value >= min && value <= max;

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        services.Framework.Update -= Update;
        services.Client.TerritoryChanged -= TerritoryChanged;
        services.Plugin.UiBuilder.Draw -= windows.Draw;
        services.Plugin.UiBuilder.OpenConfigUi -= Open;
        services.Plugin.UiBuilder.OpenMainUi -= Open;
        if (ownsCommand) services.Commands.RemoveHandler("/atune");
        engine.Dispose();
        windows.RemoveAllWindows();
    }
}
