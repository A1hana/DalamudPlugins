using System.Numerics;
using AihanaTuner.Core;
using AihanaTuner.Interop;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;
using StatusRow = Lumina.Excel.Sheets.Status;

namespace AihanaTuner.UI;

internal sealed class MainWindow : Window
{
    internal static readonly Vector4 Mint = new(0.35f, 0.93f, 0.73f, 1);
    internal static readonly Vector4 Amber = new(1f, 0.73f, 0.35f, 1);
    private readonly Configuration config;
    private readonly TuningEngine engine;
    private readonly IDataManager data;
    private readonly Action save;
    private readonly Action stop;
    private readonly Dictionary<ushort, string> statusNames = [];
    private string editor;
    private string listMessage = "名单改变后，点击“应用名单”。";

    public MainWindow(Configuration config, TuningEngine engine, IDataManager data, Action save, Action stop)
        : base("Aihana 战斗调节器###AihanaTunerMain")
    {
        this.config = config; this.engine = engine; this.data = data; this.save = save; this.stop = stop;
        editor = string.Join(", ", config.Settings.BlockedStatuses);
        Size = new(720, 840); SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new() { MinimumSize = new(580, 480), MaximumSize = new(1400, 1600) };
    }

    public override void Draw()
    {
        var s = config.Settings;
        ImGui.TextColored(Mint, "AIHANA TUNER   /   战斗调节器");
        ImGui.TextWrapped("按需启用下面的项目，再打开总开关。参数保存后立即应用。");
        Toggle("总开关", s.Enabled, x => s.Enabled = x);
        ImGui.SameLine();
        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.55f, 0.18f, 0.20f, 1));
        if (ImGui.Button("立即全部停用  /atune off")) stop();
        ImGui.PopStyleColor();
        ImGui.SameLine();
        if (ImGui.Checkbox("悬浮窗", ref config.ShowHud)) save();
        ImGui.TextColored(s.Enabled ? Mint : Amber, engine.Activity);
        ImGui.Separator();
        if (!ImGui.BeginTabBar("TuningTabs")) return;
        if (ImGui.BeginTabItem("参数")) { DrawParameters(); ImGui.EndTabItem(); }
        if (ImGui.BeginTabItem("状态名单")) { DrawStatuses(); ImGui.EndTabItem(); }
        if (ImGui.BeginTabItem("诊断与用法")) { DrawDiagnostics(); ImGui.EndTabItem(); }
        ImGui.EndTabBar();
    }

    private void DrawParameters()
    {
        var s = config.Settings;
        ImGui.PushItemWidth(ImGui.GetContentRegionAvail().X * 0.55f);
        Toggle("启用移速修改", s.SpeedEnabled, x => s.SpeedEnabled = x);
        Float("移速倍率", s.SpeedMultiplier, x => s.SpeedMultiplier = x, 0.1f, 5);
        ImGui.TextWrapped($"结果 = 游戏原始速度 x {s.SpeedMultiplier:F2}。1.00 保持原速，只调整本地角色。");
        ImGui.Separator();
        Toggle("启用技能距离扩展", s.RangeEnabled, x => s.RangeEnabled = x);
        if (ImGui.RadioButton("倍率提升", s.RangeMode == RangeMode.Multiply)) { s.RangeMode = RangeMode.Multiply; save(); }
        ImGui.SameLine();
        if (ImGui.RadioButton("固定加算", s.RangeMode == RangeMode.Add)) { s.RangeMode = RangeMode.Add; save(); }
        ImGui.BeginDisabled(s.RangeMode != RangeMode.Multiply);
        Float("射程倍率", s.RangeMultiplier, x => s.RangeMultiplier = x, 1, 5);
        ImGui.EndDisabled();
        ImGui.BeginDisabled(s.RangeMode != RangeMode.Add);
        Float("射程加算 (m)", s.RangeAddition, x => s.RangeAddition = x, 0, 50);
        ImGui.EndDisabled();
        var example = s.Copy(); example.RangeEnabled = true;
        ImGui.TextColored(Mint, s.RangeMode == RangeMode.Multiply ?
            $"当前公式：原射程 x {s.RangeMultiplier:F2}；20 m -> {TuningMath.Range(20, example):F1} m" :
            $"当前公式：原射程 + {s.RangeAddition:F1} m；20 m -> {TuningMath.Range(20, example):F1} m");
        ImGui.TextWrapped("两组参数分别保存，只有选中的模式生效。修改主目标施法距离，不扩大群攻半径；原射程小于等于 0 的技能保持原值。");
        ImGui.Separator();
        Toggle("启用受迫移动距离调节", s.DisplacementEnabled, x => s.DisplacementEnabled = x);
        Float("受迫位移倍率", s.DisplacementMultiplier, x => s.DisplacementMultiplier = x, 0, 3);
        if (ImGui.Button("0 距离")) { s.DisplacementMultiplier = 0; save(); }
        ImGui.SameLine(); if (ImGui.Button("0.8 倍")) { s.DisplacementMultiplier = 0.8f; save(); }
        ImGui.SameLine(); if (ImGui.Button("1 倍原距")) { s.DisplacementMultiplier = 1; save(); }
        ImGui.TextWrapped($"10 m -> {10 * s.DisplacementMultiplier:F1} m。始终调用原函数，只缩放距离，保留原方向和持续时间。0 表示零距离处理，原锁定行为可能仍保留；其他路径的强制位移需另行验证。");
        ImGui.Separator();
        Toggle("启用本地异常状态屏蔽", s.StatusEnabled, x => s.StatusEnabled = x);
        ImGui.TextWrapped($"当前名单 {s.BlockedStatuses.Length} 项，可在“状态名单”中编辑。通过状态写入过滤和已有状态清理实现。服务器上的状态与技能结算不保证同步改变。");
        Toggle("无视魅惑恐惧造成的强制移动", s.IgnoreCharmFear, x => s.IgnoreCharmFear = x);
        Toggle("仅在检测到已知魅惑恐惧状态时拦截", s.CharmFearOnlyWhenPresent, x => s.CharmFearOnlyWhenPresent = x);
        ImGui.TextWrapped("默认按状态识别，保留其他强制移动。关闭这一限制将拦截同入口的所有本地强制移动，可能影响其他机制。若名单同时屏蔽了魅惑恐惧状态，识别可能受影响。");
        ImGui.PopItemWidth();
    }

    private void DrawStatuses()
    {
        ImGui.TextWrapped("填写状态 ID，以逗号、空格或换行分隔。仅对本地角色过滤，最多 256 项。默认名单为 PvP 控制 1343 至 1348，默认不开启屏蔽。");
        ImGui.InputTextMultiline("##StatusIds", ref editor, 4096, new(-1, 95));
        if (ImGui.Button("加入常规控制")) Merge(StatusLists.Basic);
        ImGui.SameLine(); if (ImGui.Button("加入 PvP 控制")) Merge(StatusLists.Pvp);
        ImGui.SameLine(); if (ImGui.Button("加入移动限制")) Merge(StatusLists.Movement);
        if (ImGui.Button("清空编辑框")) editor = "";
        ImGui.SameLine(); if (ImGui.Button("还原已保存名单")) editor = string.Join(", ", config.Settings.BlockedStatuses);
        ImGui.SameLine(); if (ImGui.Button("应用名单")) ApplyList();
        ImGui.TextWrapped(listMessage);
        ImGui.TextColored(Amber, "状态屏蔽属于客户端处理，实际解控效果需要逐项验证。");
        ImGui.TextWrapped("关闭后停止过滤后续更新；已经清理的本地状态以服务器后续同步为准。不会使用净化，也不会请求服务器解除状态。");
        ImGui.Separator();
        ImGui.TextUnformatted("已保存名单");
        ImGui.BeginChild("SavedStatuses", new(0, 220), true);
        if (config.Settings.BlockedStatuses.Length == 0) ImGui.TextDisabled("名单为空，不会屏蔽任何状态。");
        foreach (var id in config.Settings.BlockedStatuses) ImGui.TextUnformatted($"{id}  {StatusName(id)}");
        ImGui.EndChild();
        ImGui.TextUnformatted("当前本地状态（可加入编辑框）");
        if (engine.LiveStatuses.Length == 0) ImGui.TextDisabled("暂无可显示状态，或角色尚未就绪。");
        foreach (var status in engine.LiveStatuses)
        {
            ImGui.PushID(status.Id);
            if (ImGui.SmallButton("加入")) Merge([status.Id]);
            ImGui.SameLine(); ImGui.TextUnformatted($"{status.Id}  {StatusName(status.Id)}  {status.Remaining:F1} s");
            ImGui.PopID();
        }
    }

    private void DrawDiagnostics()
    {
        ImGui.TextWrapped("各项目分别检测函数。某项不可用时会显示原因，其他可用项目仍可启用。");
        foreach (var h in engine.Health)
        {
            ImGui.TextColored(h.Available ? Mint : Amber, h.Name);
            ImGui.SameLine(); ImGui.TextWrapped(h.State);
        }
        ImGui.Separator();
        ImGui.TextUnformatted($"移速修改 {engine.SpeedCalls} 次；射程修改 {engine.RangeCalls} 次");
        ImGui.TextUnformatted($"受迫位移处理 {engine.DisplacementCalls} 次；魅惑恐惧移动拦截 {engine.CharmCalls} 次");
        ImGui.TextUnformatted($"状态写入过滤 {engine.IncomingStatuses} 次；已有状态清理 {engine.ExistingStatuses} 次");
        if (engine.LastDisplacement is { } d)
            ImGui.TextUnformatted($"最近位移：{d.Original:F2} m -> {d.Modified:F2} m，原持续时间 {d.Duration:F2} s");
        if (engine.LastBlockedStatus != 0)
            ImGui.TextWrapped($"最近屏蔽：{engine.LastBlockedStatus}  {StatusName(engine.LastBlockedStatus)}");
        ImGui.TextWrapped("这些计数仅表示本地处理次数，不能作为服务器已接受修改的证明。射程函数是本客户端公共查询，其他插件读到的距离也可能受影响。");
        ImGui.Separator();
        if (ImGui.Checkbox("固定悬浮窗并鼠标穿透", ref config.LockHud)) save();
        ImGui.TextWrapped("/atune 打开面板；/atune on 启用总开关；/atune off 立即全部停用。");
        ImGui.TextWrapped("/atune speed 1.2 设置并启用移速；/atune range mul 1.2 选择倍率射程；/atune range add 3 选择加算射程；/atune knock 0.8 设置位移倍率。参数命令不会自动打开总开关。");
        ImGui.TextWrapped("/atune status on|off 切换名单屏蔽；/atune charm on|off 切换魅惑恐惧移动拦截；/atune hud 切换悬浮窗。");
        ImGui.TextWrapped("默认全部停用。换区、过场和倒地期间暂停处理。避免同时开启其他插件对同一移速、射程或控制函数的修改，否则结果可能叠加或相互覆盖。");
    }

    private void Toggle(string label, bool value, Action<bool> setter)
    { if (ImGui.Checkbox(label, ref value)) { setter(value); save(); } }
    private void Float(string label, float value, Action<float> setter, float min, float max)
    { if (ImGui.SliderFloat(label, ref value, min, max, "%.2f")) { setter(value); save(); } }

    private string StatusName(ushort id)
    {
        if (statusNames.TryGetValue(id, out var name)) return name;
        var row = data.GetExcelSheet<StatusRow>().GetRowOrDefault(id);
        name = row?.Name.ToString() ?? "";
        statusNames[id] = name;
        return name;
    }

    private void Merge(ushort[] ids)
    {
        if (!StatusLists.TryParse(editor, out var current, out listMessage)) return;
        editor = string.Join(", ", current.Concat(ids).Distinct().Order());
        listMessage = "已加入编辑框，请点击“应用名单”保存。";
    }

    private void ApplyList()
    {
        if (!StatusLists.TryParse(editor, out var ids, out listMessage)) return;
        foreach (var id in ids)
            if (string.IsNullOrWhiteSpace(StatusName(id)))
            { listMessage = $"当前游戏数据找不到具名状态 {id}，名单尚未保存。"; return; }
        config.Settings.BlockedStatuses = ids;
        save();
        listMessage = $"已保存 {ids.Length} 个状态。";
    }
}
