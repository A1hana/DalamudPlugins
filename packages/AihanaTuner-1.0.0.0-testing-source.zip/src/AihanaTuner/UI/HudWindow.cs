using System.Numerics;
using AihanaTuner.Core;
using AihanaTuner.Interop;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace AihanaTuner.UI;

internal sealed class HudWindow : Window
{
    private readonly Configuration config;
    private readonly TuningEngine engine;
    private readonly Action open, stop;
    public HudWindow(Configuration config, TuningEngine engine, Action open, Action stop)
        : base("战斗调节器###AihanaTunerHud")
    {
        this.config = config; this.engine = engine; this.open = open; this.stop = stop;
        IsOpen = true; ShowCloseButton = false; RespectCloseHotkey = false;
        Position = new Vector2(40, 420); PositionCondition = ImGuiCond.FirstUseEver;
    }
    public override bool DrawConditions() => config.ShowHud && config.Settings.Enabled && engine.Ready;
    public override void PreDraw()
    {
        Flags = ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoFocusOnAppearing;
        if (config.LockHud) Flags |= ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoInputs;
    }
    public override void Draw()
    {
        var s = config.Settings;
        ImGui.TextColored(MainWindow.Mint, "战斗调节器 · 已启用");
        if (s.SpeedEnabled) ImGui.TextUnformatted($"移速 x{s.SpeedMultiplier:F2}");
        if (s.RangeEnabled) ImGui.TextUnformatted(s.RangeMode == RangeMode.Multiply ? $"射程 x{s.RangeMultiplier:F2}" : $"射程 +{s.RangeAddition:F1} m");
        if (s.DisplacementEnabled) ImGui.TextUnformatted($"受迫位移 x{s.DisplacementMultiplier:F2}");
        if (s.StatusEnabled) ImGui.TextUnformatted($"状态名单 {s.BlockedStatuses.Length} 项");
        if (s.IgnoreCharmFear) ImGui.TextUnformatted("魅惑恐惧移动拦截 开");
        var failed = engine.Health.Count(h => !h.Available);
        if (failed > 0) ImGui.TextColored(MainWindow.Amber, $"{failed} 项不可用，请查看诊断");
        if (!config.LockHud)
        {
            if (ImGui.Button("全部停用")) stop();
            ImGui.SameLine(); if (ImGui.Button("设置")) open();
        }
    }
}
