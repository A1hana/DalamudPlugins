using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace AihanaTuner;

internal sealed record Services(IDalamudPluginInterface Plugin, ICommandManager Commands, IFramework Framework,
    IClientState Client, IObjectTable Objects, ICondition Conditions, IGameInteropProvider Interop,
    ISigScanner Scanner, IDataManager Data, IChatGui Chat, IPluginLog Log);
