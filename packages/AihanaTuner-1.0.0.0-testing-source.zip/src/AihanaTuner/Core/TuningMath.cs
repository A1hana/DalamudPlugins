namespace AihanaTuner.Core;

public static class TuningMath
{
    public static float Speed(float original, TuningSettings s) =>
        !s.SpeedEnabled || !float.IsFinite(original) || original <= 0 ? original : SafeResult(original * s.SpeedMultiplier, original);

    public static float Range(float original, TuningSettings s)
    {
        if (!s.RangeEnabled || !float.IsFinite(original) || original <= 0) return original;
        // A single enum selects the formula. The inactive parameter never participates.
        return SafeResult(s.RangeMode == RangeMode.Add ? original + s.RangeAddition : original * s.RangeMultiplier, original);
    }

    public static float Displacement(float original, TuningSettings s) =>
        !s.DisplacementEnabled || !float.IsFinite(original) ? original : SafeResult(original * s.DisplacementMultiplier, original);

    private static float SafeResult(float changed, float original) => float.IsFinite(changed) ? changed : original;
}
