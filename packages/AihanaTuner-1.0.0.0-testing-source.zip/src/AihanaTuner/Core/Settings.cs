namespace AihanaTuner.Core;

public enum RangeMode { Multiply, Add }

public sealed class TuningSettings
{
    public bool Enabled { get; set; }
    public bool SpeedEnabled { get; set; }
    public float SpeedMultiplier { get; set; } = 1;
    public bool RangeEnabled { get; set; }
    public RangeMode RangeMode { get; set; }
    public float RangeMultiplier { get; set; } = 1;
    public float RangeAddition { get; set; }
    public bool DisplacementEnabled { get; set; }
    public float DisplacementMultiplier { get; set; } = 1;
    public bool StatusEnabled { get; set; }
    public ushort[] BlockedStatuses { get; set; } = [1343, 1344, 1345, 1346, 1347, 1348];
    public bool IgnoreCharmFear { get; set; }
    public bool CharmFearOnlyWhenPresent { get; set; } = true;

    public void Normalize()
    {
        SpeedMultiplier = FiniteClamp(SpeedMultiplier, 0.1f, 5, 1);
        RangeMultiplier = FiniteClamp(RangeMultiplier, 1, 5, 1);
        RangeAddition = FiniteClamp(RangeAddition, 0, 50, 0);
        DisplacementMultiplier = FiniteClamp(DisplacementMultiplier, 0, 3, 1);
        if (!Enum.IsDefined(RangeMode)) RangeMode = RangeMode.Multiply;
        BlockedStatuses = (BlockedStatuses ?? []).Where(x => x > 0).Distinct().Order().Take(256).ToArray();
    }

    public TuningSettings Copy()
    {
        var copy = (TuningSettings)MemberwiseClone();
        copy.BlockedStatuses = (ushort[])(BlockedStatuses ?? []).Clone();
        return copy;
    }

    private static float FiniteClamp(float value, float min, float max, float fallback) =>
        float.IsFinite(value) ? Math.Clamp(value, min, max) : fallback;
}

public sealed class RuntimeState
{
    public static readonly RuntimeState Inactive = new(new(), 0, 0, 0);
    public TuningSettings Settings { get; }
    public nint LocalObject { get; }
    public nint Representation { get; }
    public nint StatusManager { get; }
    private readonly HashSet<ushort> statuses;

    public RuntimeState(TuningSettings settings, nint localObject, nint representation, nint statusManager)
    {
        Settings = settings.Copy();
        Settings.Normalize();
        LocalObject = localObject;
        Representation = representation;
        StatusManager = statusManager;
        statuses = Settings.BlockedStatuses.ToHashSet();
    }

    public bool Active => Settings.Enabled && LocalObject != 0;
    public bool IsLocalObject(nint address) => Active && address != 0 && address == LocalObject;
    public bool IsLocalRepresentation(nint address) => Active && address != 0 && address == Representation;
    public bool IsLocalManager(nint address) => Active && address != 0 && address == StatusManager;
    public bool Blocks(ushort id) => Active && Settings.StatusEnabled && id != 0 && statuses.Contains(id);
}
