namespace AihanaTuner.Core;

public static class StatusLists
{
    public static readonly ushort[] Basic = [2, 3, 7, 9, 13, 14, 142, 149];
    public static readonly ushort[] Pvp = [1343, 1344, 1345, 1346, 1347, 1348];
    // Named Seduced / Hysteria / Terror rows, checked against XIVAPI on 2026-10-27.
    public static readonly ushort[] CharmFear = [66, 227, 296, 823, 991, 1389, 1400, 2266, 3023, 3024, 3363, 3624, 3942, 4167];
    public static readonly ushort[] Movement =
    [604, 905, 911, 1257, 1293, 1294, 1295, 1296, 1422, 1579, 1580, 1681,
        1958, 1959, 1960, 1961, 2161, 2162, 2163, 2164, 2381, 2382, 2383, 2384,
        2936, 3629, 3694, 3698, 3699, 3700, 3701, 3715, 3716, 3717, 3718, 3719, 3737, 3909];

    public static bool TryParse(string text, out ushort[] ids, out string error)
    {
        ids = [];
        error = "";
        var values = new SortedSet<ushort>();
        foreach (var token in text.Split([' ', ',', ';', '\r', '\n', '\t', '，', '、', '；'], StringSplitOptions.RemoveEmptyEntries))
        {
            if (!ushort.TryParse(token, out var id) || id == 0)
            { error = $"无效状态 ID：{token}。请填写 1 至 65535 的整数。"; return false; }
            values.Add(id);
            if (values.Count > 256) { error = "名单最多包含 256 个状态。"; return false; }
        }
        ids = values.ToArray();
        return true;
    }
}
