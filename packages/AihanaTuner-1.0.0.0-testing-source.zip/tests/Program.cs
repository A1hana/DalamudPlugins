using AihanaTuner.Core;
using AihanaTuner.Interop;

var count = 0;
void Check(bool condition, string message) { count++; if (!condition) throw new InvalidOperationException(message); }
void Near(float actual, float expected, string message) => Check(MathF.Abs(actual - expected) < 0.0001f, $"{message}: {actual} != {expected}");

var defaults = new TuningSettings();
Check(!defaults.Enabled && !defaults.SpeedEnabled && !defaults.RangeEnabled && !defaults.StatusEnabled &&
    !defaults.DisplacementEnabled && !defaults.IgnoreCharmFear, "all mutation features default off");
var s = new TuningSettings { Enabled = true, SpeedEnabled = true, SpeedMultiplier = 1.2f,
    RangeEnabled = true, RangeMultiplier = 1.5f, RangeAddition = 3,
    DisplacementEnabled = true, DisplacementMultiplier = .8f, StatusEnabled = true };
Near(TuningMath.Speed(6, s), 7.2f, "speed multiplication");
Near(TuningMath.Range(20, s), 30, "multiply mode ignores saved addition");
s.RangeMode = RangeMode.Add;
Near(TuningMath.Range(20, s), 23, "addition mode ignores saved multiplier");
Near(TuningMath.Range(3, s), 6, "addition is fixed not proportional");
Near(TuningMath.Range(0, s), 0, "self-centered range preserved");
Near(TuningMath.Range(-1, s), -1, "special negative range preserved");
Near(TuningMath.Displacement(10, s), 8, "requested 0.8 displacement");
Near(TuningMath.Displacement(-10, s), -8, "draw-in signed displacement preserved");
Check(float.IsNaN(TuningMath.Range(float.NaN, s)), "non-finite original passthrough");
Check(float.IsPositiveInfinity(TuningMath.Speed(float.PositiveInfinity, s)), "infinite original passthrough");

var snapshot = new RuntimeState(s, 100, 200, 300);
Check(snapshot.IsLocalObject(100) && !snapshot.IsLocalObject(999) && !snapshot.IsLocalObject(0), "actor isolation");
Check(snapshot.IsLocalRepresentation(200) && !snapshot.IsLocalRepresentation(100), "representation isolation");
Check(snapshot.IsLocalManager(300) && !snapshot.IsLocalManager(100), "status-manager identity, not unreliable Owner field");
Check(NativeFilters.BlockStatus(snapshot, 300, 0, 1343), "selected PvP stun filtered");
Check(NativeFilters.BlockStatus(snapshot, 300, 59, 1344), "last valid slot filtered");
Check(!NativeFilters.BlockStatus(snapshot, 300, 60, 1343), "invalid slot not rewritten");
Check(!NativeFilters.BlockStatus(snapshot, 300, -1, 1343), "negative slot not rewritten");
Check(!NativeFilters.BlockStatus(snapshot, 301, 0, 1343), "other actor status never filtered");
Check(!NativeFilters.BlockStatus(snapshot, 300, 0, 999), "unlisted status preserved");
Check(!NativeFilters.BlockStatus(snapshot, 300, 0, 0), "empty status preserved");
s.BlockedStatuses[0] = 999;
Check(snapshot.Blocks(1343) && !snapshot.Blocks(999), "published state detached from editable config");
s.BlockedStatuses = [1343, 1344, 1345, 1346, 1347, 1348];

void NativeCheck(float multiplier, nint actor, float expectedDistance, bool enabled = true)
{
    var settings = s.Copy(); settings.DisplacementMultiplier = multiplier; settings.Enabled = enabled;
    var st = new RuntimeState(settings, 100, 200, 300);
    var calls = 0;
    NativeDelegates.Displacement original = (obj, rotation, distance, duration, flag, extra) =>
    {
        calls++;
        Check(obj == actor, "native object preserved");
        Near(rotation, 1.234f, "native rotation preserved");
        Near(distance, expectedDistance, "native distance scaled");
        Near(duration, 2.345f, "native duration preserved as float");
        Check(flag == 7 && extra == -19, "native extra parameters preserved");
        return 173;
    };
    var ret = NativeFilters.Displace(st, original, actor, 1.234f, 10, 2.345f, 7, -19);
    Check(calls == 1, "original called exactly once, including zero multiplier");
    Check(ret == 173, "original return value preserved");
}
NativeCheck(0, 100, 0);
NativeCheck(.8f, 100, 8);
NativeCheck(1, 100, 10);
NativeCheck(2, 100, 20);
NativeCheck(0, 999, 10);
NativeCheck(0, 100, 10, false);
NativeCheck(0, 0, 10);

var off = new RuntimeState(new(), 100, 200, 300);
Check(!off.IsLocalObject(100) && !off.IsLocalManager(300) && !off.Blocks(1343), "master stop disables all local guards");
Check(!RuntimeState.Inactive.Active, "unloaded context inactive");
var noManager = new RuntimeState(s, 100, 200, 0);
Check(!noManager.IsLocalManager(0), "null manager never accepted");
var charmSettings = s.Copy(); charmSettings.IgnoreCharmFear = true;
var charmState = new RuntimeState(charmSettings, 100, 200, 300);
Check(NativeFilters.IgnoreForcedAction(charmState,100,true), "known charm or fear blocks local forced movement");
Check(!NativeFilters.IgnoreForcedAction(charmState,100,false), "unrelated forced movement retained by default");
Check(!NativeFilters.IgnoreForcedAction(charmState,999,true), "other actors' forced movement preserved");
charmSettings.CharmFearOnlyWhenPresent = false;
Check(NativeFilters.IgnoreForcedAction(new(charmSettings,100,200,300),100,false), "explicit broad mode available");
Check(StatusLists.CharmFear.Contains((ushort)3023) && StatusLists.CharmFear.Contains((ushort)3024) &&
    !StatusLists.CharmFear.Contains((ushort)1747), "PvP control rows included, Fearless buff excluded");

Check(StatusLists.TryParse("1343，1344; 1343\n1345、1346", out var ids, out _) && ids.SequenceEqual(new ushort[]{1343,1344,1345,1346}), "parse normalize and deduplicate");
Check(StatusLists.TryParse("", out ids, out _) && ids.Length == 0, "empty list valid");
foreach (var text in new[] { "0", "-1", "65536", "2.5", "NaN", "1343 wrong" })
    Check(!StatusLists.TryParse(text, out _, out _), $"invalid ID rejected: {text}");
Check(!StatusLists.TryParse(string.Join(',', Enumerable.Range(1,257)), out _, out _), "list cap");
var corrupt = new TuningSettings { SpeedMultiplier = float.NaN, RangeMultiplier = float.PositiveInfinity,
    RangeAddition = -20, DisplacementMultiplier = -1, RangeMode = (RangeMode)42, BlockedStatuses = [0,7,7,2] };
corrupt.Normalize();
Check(corrupt.SpeedMultiplier == 1 && corrupt.RangeMultiplier == 1 && corrupt.RangeAddition == 0 &&
    corrupt.DisplacementMultiplier == 0 && corrupt.RangeMode == RangeMode.Multiply &&
    corrupt.BlockedStatuses.SequenceEqual(new ushort[]{2,7}), "malformed persisted values normalized");

var rng = new Random(271026);
for (var i = 0; i < 1000; i++)
{
    var initial = (float)rng.NextDouble()*50 + 0.01f;
    var multiplier = (float)rng.NextDouble()*4+1;
    var add = (float)rng.NextDouble()*50;
    var p = new TuningSettings { RangeEnabled=true, RangeMode=RangeMode.Multiply, RangeMultiplier=multiplier, RangeAddition=add };
    var result = TuningMath.Range(initial,p);
    p.RangeAddition += 50;
    Near(TuningMath.Range(initial,p),result,"multiply independent of additive parameter");
    p.RangeMode=RangeMode.Add;
    result=TuningMath.Range(initial,p);
    p.RangeMultiplier+=5;
    Near(TuningMath.Range(initial,p),result,"addition independent of multiplier parameter");
    p.DisplacementEnabled=true; p.DisplacementMultiplier=(float)rng.NextDouble()*3;
    Near(TuningMath.Displacement(-initial,p),-TuningMath.Displacement(initial,p),"distance sign symmetry");
}
Console.WriteLine($"PASS: {count} assertions. Mutual exclusion, local actor isolation, status filtering and original displacement invocation verified.");
