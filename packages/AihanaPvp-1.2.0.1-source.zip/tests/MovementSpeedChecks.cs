using OPP.Core;
using OPP.Interop;

internal static class MovementSpeedChecks
{
    internal static void Run(Action<bool, string> check)
    {
        const int movement = 100, animation = 200;
        var memory = new FakeMemory();
        var patch = new MovementSpeedPatch(memory);
        check(patch.Apply(movement, animation, 2, out _) && memory.Values[movement] == 12 && memory.Values[animation] == 12
            && patch.AppliedBaseSpeed == 12, "Movement and animation speeds both apply and read back");
        var writes = memory.Writes;
        check(patch.Apply(movement, animation, 2, out _) && memory.Writes == writes && memory.Values[movement] == 12,
            "Repeated updates neither compound the multiplier nor rewrite unchanged memory");
        check(patch.Apply(movement, animation, 3, out _) && memory.Values[movement] == 18 && memory.Values[animation] == 18,
            "A changed multiplier is based on the original speed");
        check(patch.Restore(out _) && memory.Values[movement] == 6 && memory.Values[animation] == 6 && !patch.HasChanges,
            "Reset restores original movement and animation values");

        memory = new FakeMemory(); memory.Values[movement] = 7; memory.Values[animation] = 5;
        patch = new(memory);
        check(patch.Apply(movement, animation, 1.5f, out _) && memory.Values[movement] == 10.5f
            && memory.Values[animation] == 7.5f && patch.Restore(out _)
            && memory.Values[movement] == 7 && memory.Values[animation] == 5,
            "Each speed restores its own original value instead of a hardcoded 6");

        memory = new FakeMemory { FailingWrite = animation };
        patch = new(memory);
        check(!patch.Apply(movement, animation, 2, out var error) && error.Contains("动画")
            && memory.Values[movement] == 6 && memory.Values[animation] == 6 && patch.AppliedBaseSpeed == null,
            "A second write failure rolls the first cell back and reports no success");

        memory = new FakeMemory(); patch = new(memory);
        patch.Apply(movement, animation, 2, out _);
        memory.FailingWrite = animation;
        var failed = !patch.Apply(movement, animation, 3, out _);
        memory.FailingWrite = 0;
        check(failed && memory.Values[movement] == 12 && memory.Values[animation] == 12
            && patch.Restore(out _) && memory.Values[movement] == 6 && memory.Values[animation] == 6,
            "Failed multiplier changes preserve previous ownership so a later reset fully restores both cells");

        memory = new FakeMemory { FailingWrite = animation, FailAfterWriting = true };
        patch = new(memory);
        check(!patch.Apply(movement, animation, 2, out _) && memory.Values[movement] == 6 && memory.Values[animation] == 6,
            "A write that changes bytes but reports failure is rolled back");
        memory = new FakeMemory { DroppedWrite = animation }; patch = new(memory);
        check(!patch.Apply(movement, animation, 2, out _) && memory.Values[movement] == 6 && memory.Values[animation] == 6,
            "Readback detects a write reported as successful without changing memory");
        memory = new FakeMemory { Unreadable = animation }; patch = new(memory);
        check(!patch.Apply(movement, animation, 2, out _) && memory.Writes == 0,
            "Both original speeds must be readable before any write");

        var invalid = true;
        foreach (var value in new[] { float.NaN, float.PositiveInfinity, 0f, -2f })
        {
            memory = new FakeMemory(); memory.Values[movement] = value; patch = new(memory);
            invalid &= !patch.Apply(movement, animation, 2, out _) && memory.Writes == 0;
        }
        check(invalid, "Invalid or uninitialized game speed values are never overwritten");
        invalid = true;
        foreach (var value in new[] { float.NaN, float.PositiveInfinity, 0f, -1f, 20f })
        {
            memory = new FakeMemory(); patch = new(memory);
            invalid &= !patch.Apply(movement, animation, value, out _) && memory.Writes == 0;
        }
        check(invalid, "Invalid requested multipliers cause no writes");
        memory = new FakeMemory(); patch = new(memory);
        check(!patch.Apply(0, animation, 2, out _) && !patch.Apply(movement, movement, 2, out _) && memory.Writes == 0,
            "Null or aliased speed addresses are rejected");

        memory = new FakeMemory(); patch = new(memory); patch.Apply(movement, animation, 2, out _);
        memory.Values[movement] = 7;
        check(patch.Restore(out _) && memory.Values[movement] == 7 && memory.Values[animation] == 6,
            "Reset preserves speed values subsequently changed by the game or another plugin");

        memory = new FakeMemory(); patch = new(memory); patch.Apply(movement, animation, 2, out _);
        memory.Values[movement] = 6;
        check(patch.Apply(movement, animation, 2, out _) && memory.Values[movement] == 12 && memory.Values[animation] == 12,
            "Game-side resets can be reapplied without multiplying the other cell again");
        memory.FailingWrite = animation;
        var restorationFailed = !patch.Restore(out _) && patch.HasChanges;
        memory.FailingWrite = 0;
        check(restorationFailed && patch.Restore(out _) && !patch.HasChanges
            && memory.Values[movement] == 6 && memory.Values[animation] == 6,
            "Failed restoration remains tracked and completes on retry");

        memory = new FakeMemory(); patch = new(memory); patch.Apply(movement, animation, 2, out _);
        memory.Values.Remove(animation); memory.Values[300] = 8;
        check(patch.Apply(movement, 300, 2, out _) && memory.Values[movement] == 12 && memory.Values[300] == 16
            && patch.Restore(out _) && memory.Values[movement] == 6 && memory.Values[300] == 8,
            "A replaced animation row is recaptured without touching the old allocation");
        check(MovementSpeedLayout.MatchesControl(0x10000 + MovementSpeedLayout.BaseSpeedOffset, 0x10000)
            && !MovementSpeedLayout.MatchesControl(0, 0)
            && !MovementSpeedLayout.MatchesControl(0x10000 + MovementSpeedLayout.BaseSpeedOffset + 20, 0x10000),
            "Independent Control layout validation rejects null and incorrectly offset speed fields");
    }

    private sealed class FakeMemory : ISpeedMemory
    {
        internal readonly Dictionary<nint, float> Values = new() { [100] = 6, [200] = 6 };
        internal nint FailingWrite;
        internal nint DroppedWrite;
        internal nint Unreadable;
        internal bool FailAfterWriting;
        internal int Writes;
        public bool Read(nint address, out float value)
        {
            value = 0;
            return address != Unreadable && Values.TryGetValue(address, out value);
        }
        public bool Write(nint address, float value)
        {
            Writes++;
            if (!Values.ContainsKey(address)) throw new Exception("Access to stale allocation");
            if (address == FailingWrite)
            {
                if (FailAfterWriting) Values[address] = value;
                return false;
            }
            if (address != DroppedWrite) Values[address] = value;
            return true;
        }
    }
}
