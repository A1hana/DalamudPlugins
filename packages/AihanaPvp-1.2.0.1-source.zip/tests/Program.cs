using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OPP;
using TyniaPVPRadar;

var dalamudDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
    "XIVLauncherCN", "addon", "Hooks", "dev");
AssemblyLoadContext.Default.Resolving += (context, name) =>
{
    var path = Path.Combine(dalamudDirectory, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
RunChecks();

[MethodImpl(MethodImplOptions.NoInlining)]
static void RunChecks()
{
    var checks = 0;
    var fixtureRoot = Path.Combine(AppContext.BaseDirectory, "fixtures", Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(fixtureRoot);
    var configPath = Path.Combine(fixtureRoot, "AihanaPvp.json");
    var legacyNinjaPath = Path.Combine(fixtureRoot, "0xPvpPlugin.json");
    var legacyRadarPath = Path.Combine(fixtureRoot, "TyniaPVPRadar.json");
    var errors = new List<string>();
    var loader = typeof(Configuration).Assembly.GetType("OPP.ConfigurationLoader")!
        .GetMethod("Load", BindingFlags.Static | BindingFlags.NonPublic)!;
    var initialize = typeof(Configuration).GetMethod("Initialize", BindingFlags.Instance | BindingFlags.NonPublic)!;

    Configuration Load() => (Configuration)loader.Invoke(null,
        [configPath, (Action<Exception, string>)((_, message) => errors.Add(message))])!;
    void Bind(Configuration config, Action<Configuration> save) => initialize.Invoke(config, [save]);
    void Check(bool valid, string name)
    {
        if (!valid) throw new InvalidOperationException("FAILED: " + name);
        checks++;
        Console.WriteLine("PASS: " + name);
    }

    var defaults = Load();
    Check(!defaults.AutoSelect && defaults.Dspeed == 1 && defaults.Radar.ShowEnemyDots
        && defaults.DarkKnightAutoAim && defaults.DarkKnightMaxHeight == 5,
        "New installations preserve module defaults");

    const string ninjaJson = """
        {"$type":"OPP.Configuration, 0xPvpPlugin","AutoSelect":true,"SelectDistance":25,
        "SelectInterval":80,"XDTZ":false,"TD":false,"MS":true,"Dspeed":1.3,"upDistance":4}
        """;
    const string radarJson = """
        {"$type":"TyniaPVPRadar.PluginConfig, TyniaPVPRadar","Version":2,
        "DotSize":7,"SaveWindowStates":true,"MainWindowIsOpen":true,"ShowEnemyMapDots":false,
        "WatchCollections":{"$type":"System.Collections.Generic.List`1[[TyniaPVPRadar.关注列表, TyniaPVPRadar]], System.Private.CoreLib",
        "$values":[{"$type":"TyniaPVPRadar.关注列表, TyniaPVPRadar","Name":"测试关注",
        "Members":[{"CID":12345,"Name":"测试成员","ServerName":"测试服务器"}]}]},
        "MarkerConfigs":[{"标记类型":1,"玩家CID":12345,"玩家名称":"测试成员"}],
        "Lines":[{"TargetCID":12345,"TargetName":"保留","IsTemporary":false},
        {"TargetCID":54321,"TargetName":"临时","IsTemporary":true}]}
        """;
    File.WriteAllText(legacyNinjaPath, ninjaJson);
    File.WriteAllText(legacyRadarPath, radarJson);
    var migrated = Load();
    Check(migrated.AutoSelect && migrated.SelectDistance == 25 && migrated.SelectInterval == 80
        && !migrated.XDTZ && !migrated.TD && migrated.MS && migrated.upDistance == 4
        && Math.Abs(migrated.Dspeed - 1.3f) < 0.001, "Ninja configuration migration");
    Check(migrated.DarkKnightAutoAim && migrated.DarkKnightMaxHeight == 5,
        "Existing configurations gain Dark Knight defaults without changing Ninja preferences");
    Check(migrated.Radar.DotSize == 7 && !migrated.Radar.ShowEnemyMapDots
        && migrated.Radar.SaveWindowStates && migrated.Radar.MainWindowIsOpen,
        "Radar display and window state migration");
    Check(migrated.Radar.WatchCollections.Single().Members.Single().CID == 12345
        && migrated.Radar.MarkerConfigs.Single().玩家CID == 12345,
        "Watch lists and marker assignments survive legacy assembly metadata");
    Check(migrated.Radar.Lines.Count == 1 && migrated.Radar.Lines[0].TargetCID == 12345,
        "Temporary lines are discarded at startup");
    Check(errors.Count == 0 && File.ReadAllText(legacyNinjaPath) == ninjaJson
        && File.ReadAllText(legacyRadarPath) == radarJson, "Legacy configuration files remain unchanged");

    migrated.Radar.Lines.Add(new 连线数据 { TargetCID = 67890, IsTemporary = true });
    var originalLines = migrated.Radar.Lines;
    string? saved = null;
    Bind(migrated, config => saved = JsonConvert.SerializeObject(config,
        new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All }));
    migrated.AutoSelect = false;
    migrated.DarkKnightAutoAim = false;
    migrated.DarkKnightMaxHeight = 3;
    migrated.Save();
    var savedObject = JObject.Parse(saved!);
    Check(savedObject["AutoSelect"]!.Value<bool>() == false
        && savedObject["Radar"]!["DotSize"]!.Value<float>() == 7
        && ((JArray)savedObject["Radar"]!["Lines"]!["$values"]!).Count == 1,
        "Ninja changes save both modules and omit temporary radar lines");
    Check(ReferenceEquals(originalLines, migrated.Radar.Lines) && migrated.Radar.Lines.Count == 2,
        "Saving preserves live temporary line state");
    Bind(migrated, _ => throw new IOException("Simulated save failure"));
    try { migrated.Save(); } catch (IOException) { }
    Check(ReferenceEquals(originalLines, migrated.Radar.Lines) && migrated.Radar.Lines.Count == 2,
        "Failed save also restores live radar state");

    File.WriteAllText(configPath, saved!);
    File.WriteAllText(legacyNinjaPath, "{\"AutoSelect\":true,\"SelectDistance\":5}");
    var reloaded = Load();
    Check(!reloaded.AutoSelect && reloaded.SelectDistance == 25 && reloaded.Radar.DotSize == 7
        && reloaded.Radar.WatchCollections.Single().Members.Single().CID == 12345,
        "Merged configuration reload takes precedence over legacy files");
    Check(!reloaded.DarkKnightAutoAim && reloaded.DarkKnightMaxHeight == 3,
        "Dark Knight settings persist independently of Ninja and radar settings");
    File.WriteAllText(configPath, "{ broken json");
    var rejected = false;
    try { Load(); } catch (TargetInvocationException exception) when (exception.InnerException is JsonException) { rejected = true; }
    Check(rejected && File.ReadAllText(configPath) == "{ broken json",
        "A damaged merged configuration is rejected without overwriting it");

    using var stream = File.OpenRead(typeof(Configuration).Assembly.Location);
    using var pe = new PEReader(stream);
    var metadata = pe.GetMetadataReader();
    var entryPoints = metadata.TypeDefinitions.Select(handle => metadata.GetTypeDefinition(handle))
        .Where(type => type.GetInterfaceImplementations().Any(handle =>
        {
            var implemented = metadata.GetInterfaceImplementation(handle).Interface;
            if (implemented.Kind != HandleKind.TypeReference) return false;
            var reference = metadata.GetTypeReference((TypeReferenceHandle)implemented);
            return metadata.GetString(reference.Name) == "IDalamudPlugin";
        })).ToList();
    Check(entryPoints.Count == 1 && metadata.GetString(entryPoints[0].Name) == "Plugin",
        "Exactly one Dalamud plugin entry point");
    var references = metadata.AssemblyReferences.Select(handle => metadata.GetString(metadata.GetAssemblyReference(handle).Name)).ToArray();
    Check(!references.Contains("0xPvpPlugin") && !references.Contains("TyniaPVPRadar")
        && references.Contains("OmenTools"), "Both modules are compiled into the merged assembly");
    Check(typeof(Configuration).Assembly.GetTypes().Length > 25,
        "All merged plugin types resolve against local API 15 dependencies");

    EventideChecks.Run(Check);
    MovementSpeedChecks.Run(Check);
    var migrationDirectory = Path.Combine(fixtureRoot, "selector-migration");
    Directory.CreateDirectory(migrationDirectory);
    File.WriteAllText(Path.Combine(migrationDirectory, "PvpAutoLb.json"), "{\"Version\":6,\"Enabled\":true,\"HpThresholdPercent\":43,\"AutoSelectRangeYalms\":25,\"AutoSelectLowestHp\":false,\"PreventUnsafeNinjaTenchu\":true}");
    var selectorRoot = (Configuration)loader.Invoke(null, [Path.Combine(migrationDirectory, "AihanaPvp.json"), (Action<Exception,string>)((_, _) => {})])!;
    Check(selectorRoot.Selector is { HpThresholdPercent: 43, AutoSelectRangeYalms: 25, AutoSelectLowestHp: false, PreventUnsafeNinjaTenchu: true }, "Original selector settings migrate without changing tested preferences");
    var rootSaves = 0;
    Bind(selectorRoot, _ => rootSaves++);
    selectorRoot.Selector!.Persist = selectorRoot.Save;
    selectorRoot.Selector.Save();
    Check(rootSaves == 1, "Original module saves through the unified configuration root");
    Check(typeof(Configuration).Assembly.GetType("OPP.Core.NinjaTargetSelector") == null
        && typeof(Configuration).Assembly.GetType("OPP.Interop.NinjaActionHook") == null
        && typeof(Configuration).Assembly.GetType("PvpAutoLb.Core.NinjaTenchuProtector") != null,
        "Legacy Ninja selector and hooks are excluded; original tested protector is compiled");

    Console.WriteLine($"All {checks} checks passed.");
}
