using System.Numerics;
using OPP.Core;

internal static class EventideChecks
{
    internal static void Run(Action<bool, string> check)
    {
        check(Enumerable.Range(0, 50).All(job =>
            JobActionPolicy.NinjaEnabled(true, true, (uint)job, true) == (job == 30)),
            "Every non-Ninja job is excluded from Ninja selection");
        check(!JobActionPolicy.NinjaEnabled(true, false, 30, true)
            && !JobActionPolicy.NinjaEnabled(false, true, 30, true)
            && !JobActionPolicy.NinjaEnabled(true, true, 30, false),
            "Ninja selection is disabled outside PvP, while dead, or when switched off");

        EventideEnemy Point(float x, float z, float radius = 0) => new(new(x, z), radius);
        check(EventidePlanner.Hits(Point(0, 15), 0) && EventidePlanner.Hits(Point(0, -15), 0)
            && !EventidePlanner.Hits(Point(0, 15.01f), 0) && !EventidePlanner.Hits(Point(0, -15.01f), 0),
            "Eventide reaches 15m both forwards and backwards, not 30m each");
        check(EventidePlanner.Hits(Point(3, 4), 0) && EventidePlanner.Hits(Point(-3, -4), 0)
            && !EventidePlanner.Hits(Point(3.01f, 4), 0), "Eventide width is 6m in total");
        check(EventidePlanner.Hits(Point(3.5f, 4, 0.5f), 0)
            && !EventidePlanner.Hits(Point(3.6f, 4, 0.5f), 0)
            && !EventidePlanner.Hits(Point(3.4f, 15.4f, 0.5f), 0)
            && EventidePlanner.Hits(Point(3.4f, 15.4f, 0.6f), 0),
            "Hitboxes intersect straight edges and rounded corners accurately");
        EventideEnemy[] bothSides = [Point(0, 14), Point(0, -14), Point(12, 0)];
        check(EventidePlanner.FindBest(bothSides, MathF.PI / 2)?.Hits == 2,
            "Opposite-side enemies contribute to one shared rectangle");

        var bearing = 0.22f;
        EventideEnemy[] between = [Point(12 * MathF.Sin(bearing), 12 * MathF.Cos(bearing)),
            Point(-12 * MathF.Sin(bearing), 12 * MathF.Cos(bearing))];
        var bestBetween = EventidePlanner.FindBest(between, MathF.PI / 2)!.Value;
        check(bestBetween.Hits == 2 && EventidePlanner.Count(between, bearing) == 1
            && EventidePlanner.Count(between, -bearing) == 1,
            "Free aiming can cover both enemies when aiming at either enemy cannot");
        check(EventidePlanner.FindBest(between, 0) is { Rotation: 0, Hits: 2 },
            "An already optimal facing is preserved");
        var facingBack = EventidePlanner.FindBest(between, MathF.PI - 0.6f)!.Value;
        check(facingBack.Hits == 2 && Math.Abs(Math.IEEERemainder(facingBack.Rotation - (MathF.PI - 0.6f), Math.Tau)) <= Math.PI / 2 + 0.00001,
            "Equivalent opposite facings avoid an unnecessary 180-degree turn");
        check(EventidePlanner.FindBest([], 0) == null
            && EventidePlanner.FindBest([Point(40, 0)], 0) == null
            && EventidePlanner.FindBest([Point(float.NaN, 2), Point(0, float.PositiveInfinity), Point(1, 2, -1)], 0) == null
            && EventidePlanner.FindBest(between, float.NaN) == null,
            "Empty, unreachable and non-finite data produce no aim");

        var exactCorners = true;
        foreach (var rotation in new[] { 0.1234f, 0.65f, 1.5421f, 2.17f, 3.13f, -2.999f })
        {
            EventideEnemy[] corners = [Rotate(Point(3, 15), rotation), Rotate(Point(-3, 15), rotation),
                Rotate(Point(3, -15), rotation), Rotate(Point(-3, -15), rotation)];
            exactCorners &= EventidePlanner.FindBest(corners, rotation + 0.7f)?.Hits == 4;
        }
        check(exactCorners, "Boundary-only optimal orientations are found without angle sampling");

        var random = new Random(29097);
        var oraclePassed = true;
        for (var scene = 0; scene < 100; scene++)
        {
            var enemies = Enumerable.Range(0, 18).Select(_ => Point(
                (float)(random.NextDouble() * 36 - 18), (float)(random.NextDouble() * 36 - 18),
                scene % 2 == 0 ? 0 : (float)(random.NextDouble() * 1.2))).ToArray();
            var plan = EventidePlanner.FindBest(enemies, (float)(random.NextDouble() * Math.Tau - Math.PI));
            var gridMaximum = 0;
            for (var step = 0; step < 4096; step++)
                gridMaximum = Math.Max(gridMaximum, OracleCount(enemies, step * Math.PI / 4096));
            if (plan == null) oraclePassed &= gridMaximum == 0;
            else oraclePassed &= plan.Value.Hits >= gridMaximum
                && plan.Value.Hits == OracleCount(enemies, plan.Value.Rotation);
            if (!oraclePassed) throw new Exception($"Angle oracle mismatch in scene {scene}");
        }
        check(oraclePassed, "100 random scenes match an independent rectangle-edge oracle over 4096 directions");

        var routing = true;
        foreach (var job in Enumerable.Range(0, 50).Where(job => job != 32))
        {
            var game = new FakeRuntime { Player = FakeRuntime.DefaultPlayer with { Job = (uint)job } };
            routing &= PassesThrough(game);
        }
        routing &= PassesThrough(new FakeRuntime(), enabled: false);
        routing &= PassesThrough(new FakeRuntime(), action: 29515);
        routing &= PassesThrough(new FakeRuntime(), action: 41438); // Not Eventide, even on DRK.
        routing &= PassesThrough(new FakeRuntime(), type: 5);
        routing &= PassesThrough(new FakeRuntime { Player = FakeRuntime.DefaultPlayer with { IsPvP = false } });
        routing &= PassesThrough(new FakeRuntime { Player = FakeRuntime.DefaultPlayer with { Alive = false } });
        routing &= PassesThrough(new FakeRuntime { Ready = false });
        routing &= PassesThrough(new FakeRuntime { Present = false });
        check(routing, "Only an enabled, ready, living DRK PvP Eventide request can alter facing or targets");
        check(PassesThrough(new FakeRuntime { Enemies = [] }),
            "A zero-hit defensive Eventide still executes normally");

        var runtime = new FakeRuntime();
        var controller = new EventideAimController(runtime);
        var casts = 0;
        var dispatched = controller.Execute(1, 29097, 777, true, (target, aimed) =>
        {
            casts++;
            check(target == 100 && aimed && runtime.Targets == new EventideTargets(0, 0)
                && EventidePlanner.Count(runtime.Enemies, runtime.Player.Rotation) == 2,
                "Targets are cleared and arbitrary optimal facing is set before the self-targeted dispatch");
            return true;
        });
        check(dispatched && casts == 1 && controller.LastHitCount == 2 && runtime.Targets == new EventideTargets(0, 0),
            "Successful dispatch runs exactly once and retains the chosen facing");

        runtime = new FakeRuntime();
        controller = new(runtime);
        casts = 0;
        var failed = controller.Execute(1, 29097, 777, true, (_, _) => { casts++; return false; });
        check(!failed && casts == 1 && runtime.Player.Rotation == FakeRuntime.DefaultPlayer.Rotation
            && runtime.Targets == new EventideTargets(777, 888) && controller.LastHitCount == null,
            "A rejected cast restores the original hard target, soft target and facing");

        runtime = new FakeRuntime();
        controller = new(runtime);
        casts = 0;
        try { controller.Execute(1, 29097, 777, true, (_, _) => { casts++; throw new IOException("Dispatch failure"); }); }
        catch (IOException) { }
        check(casts == 1 && runtime.Targets == new EventideTargets(777, 888)
            && runtime.Player.Rotation == FakeRuntime.DefaultPlayer.Rotation,
            "An exception from original dispatch is not retried and restores local state");

        runtime = new FakeRuntime { ThrowOnCapture = true };
        check(PassesThrough(runtime) && runtime.Errors == 1, "A scan error falls back to one unmodified request");
        runtime = new FakeRuntime { ThrowFirstFacing = true };
        controller = new(runtime);
        casts = 0;
        var fallback = controller.Execute(1, 29097, 777, true, (target, aimed) =>
        { casts++; return target == 777 && !aimed; });
        check(fallback && casts == 1 && runtime.Errors == 1 && runtime.Targets == new EventideTargets(777, 888)
            && runtime.Player.Rotation == FakeRuntime.DefaultPlayer.Rotation,
            "A partial mutation failure restores state before falling back");
    }

    private static bool PassesThrough(FakeRuntime runtime, bool enabled = true, uint type = 1, uint action = 29097)
    {
        var calls = 0;
        var controller = new EventideAimController(runtime);
        var result = controller.Execute(type, action, 777, enabled, (target, aimed) =>
        { calls++; return target == 777 && !aimed; });
        return result && calls == 1 && runtime.ClearCalls == 0 && runtime.FaceCalls == 0;
    }

    private static EventideEnemy Rotate(EventideEnemy point, float rotation)
        => point with { Offset = new(point.Offset.X * MathF.Cos(rotation) + point.Offset.Y * MathF.Sin(rotation),
            point.Offset.Y * MathF.Cos(rotation) - point.Offset.X * MathF.Sin(rotation)) };

    // Independent oracle: build all four world-space edges, test polygon inclusion,
    // otherwise measure the point's distance to each segment (not projection bounds).
    private static int OracleCount(EventideEnemy[] enemies, double rotation)
    {
        var sin = Math.Sin(rotation);
        var cos = Math.Cos(rotation);
        var corners = new (double X, double Z)[4];
        var local = new (double X, double Z)[] { (-3, -15), (3, -15), (3, 15), (-3, 15) };
        for (var i = 0; i < 4; i++) corners[i] = (local[i].X * cos + local[i].Z * sin, local[i].Z * cos - local[i].X * sin);
        var count = 0;
        foreach (var enemy in enemies)
        {
            var inside = true;
            var distanceSquared = double.PositiveInfinity;
            for (var i = 0; i < 4; i++)
            {
                var a = corners[i];
                var b = corners[(i + 1) % 4];
                var dx = b.X - a.X;
                var dz = b.Z - a.Z;
                var px = enemy.Offset.X - a.X;
                var pz = enemy.Offset.Y - a.Z;
                inside &= dx * pz - dz * px >= 0;
                var t = Math.Clamp((px * dx + pz * dz) / (dx * dx + dz * dz), 0, 1);
                distanceSquared = Math.Min(distanceSquared, Math.Pow(px - t * dx, 2) + Math.Pow(pz - t * dz, 2));
            }
            if (inside || distanceSquared <= Math.Pow(enemy.Radius + 0.00001, 2)) count++;
        }
        return count;
    }

    private sealed class FakeRuntime : IEventideRuntime
    {
        internal static readonly EventidePlayer DefaultPlayer = new(100, 32, true, true, Vector3.Zero, MathF.PI / 2);
        internal EventidePlayer Player = DefaultPlayer;
        internal EventideTargets Targets = new(777, 888);
        internal EventideEnemy[] Enemies = [new(new(2.6f, 12), 0), new(new(-2.6f, 12), 0)];
        internal bool Present = true;
        internal bool Ready = true;
        internal bool ThrowOnCapture;
        internal bool ThrowFirstFacing;
        internal int ClearCalls;
        internal int FaceCalls;
        internal int Errors;
        public bool TryGetPlayer(out EventidePlayer player) { player = Player; return Present; }
        public bool IsReady(ulong playerId) => Ready;
        public IReadOnlyList<EventideEnemy> CaptureEnemies(Vector3 origin)
            => ThrowOnCapture ? throw new IOException("Capture failed") : Enemies;
        public EventideTargets CaptureTargets() => Targets;
        public void ClearTargets() { ClearCalls++; Targets = new(0, 0); }
        public void SetFacing(ulong playerId, float rotation)
        {
            FaceCalls++;
            if (ThrowFirstFacing && FaceCalls == 1) throw new IOException("Facing failed");
            Player = Player with { Rotation = rotation };
        }
        public void RestoreTargets(EventideTargets targets) => Targets = targets;
        public void ReportError(Exception exception) => Errors++;
    }
}
