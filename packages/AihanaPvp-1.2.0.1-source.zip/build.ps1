[CmdletBinding()]
param(
    [string]$DotnetPath = 'dotnet',
    [string]$DalamudLibPath = (Join-Path $env:APPDATA 'XIVLauncherCN\addon\Hooks\dev')
)
$ErrorActionPreference = 'Stop'
$projectFile = Join-Path $PSScriptRoot 'src\AihanaPvp\AihanaPvp.csproj'
$dalamudDirectory = (Resolve-Path -LiteralPath $DalamudLibPath).Path
& $DotnetPath build $projectFile -c Release "-p:DalamudLibPath=$dalamudDirectory\" -v minimal
if ($LASTEXITCODE -ne 0) { throw '编译失败。' }

$output = Join-Path $PSScriptRoot 'src\AihanaPvp\bin\Release'
$manifest = Get-Content -LiteralPath (Join-Path $output 'AihanaPvp.json') -Raw | ConvertFrom-Json
$assembly = [Reflection.AssemblyName]::GetAssemblyName((Join-Path $output 'AihanaPvp.dll'))
$version = $manifest.AssemblyVersion
if ($version -notmatch '^\d+\.\d+\.\d+\.\d+$' -or $version -ne $assembly.Version.ToString() -or $manifest.InternalName -ne $assembly.Name) {
    throw '程序集与清单版本不一致。'
}
$dist = Join-Path $PSScriptRoot 'dist'
$stage = Join-Path $dist ('package-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
$files = @('AihanaPvp.dll', 'AihanaPvp.deps.json', 'AihanaPvp.json', 'OmenTools.dll', 'TinyPinyin.dll', 'ECommons.dll')
foreach ($file in $files) {
    $source = Join-Path $output $file
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "缺少依赖：$source" }
    Copy-Item -LiteralPath $source -Destination (Join-Path $stage $file)
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'lib\OmenTools-LICENSE.txt') -Destination $stage
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'THIRD_PARTY.txt') -Destination $stage
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'lib\Selector-LICENSE.txt') -Destination $stage
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'lib\ECommons-LICENSE.txt') -Destination $stage
$archive = Join-Path $dist "AihanaPvp-$version.zip"
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $archive -Force -CompressionLevel Optimal
Get-FileHash -LiteralPath $archive -Algorithm SHA256
Write-Host "安装包：$archive"
