using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Hooking;
using FFXIVClientStructs.FFXIV.Client.Game;
using OPP.Core;
using System;
using System.Linq;

namespace OPP.Interop;

internal sealed unsafe class NinjaActionHook : IDisposable
{
    private const uint MeisuiActionId = 29507;
    private const uint ShukuchiActionId = 29513;
    private const uint SeitonTenchuActionId = 29515;
    private const uint BlockedActionId = 29657;
    private const uint ThreeMudraStatusId = 1317;

    private readonly PluginServices services;
    private readonly Configuration configuration;
    private Hook<ActionManager.Delegates.GetAdjustedActionId>? hook;
    private long lastErrorAt;

    public bool Available => hook is { IsEnabled: true };

    public NinjaActionHook(PluginServices services, Configuration configuration)
    {
        this.services = services;
        this.configuration = configuration;
        Initialize();
    }

    private void Initialize()
    {
        try
        {
            // SDK addresses are already resolved function entries. In particular,
            // Dalamud ScanText also resolves leading E8/E9 calls automatically;
            // decoding either result again reads a function prologue as an offset.
            hook = CreateResolvedHook(ActionManager.Addresses.GetAdjustedActionId.Value, Detour,
                (address, detour) => services.Interop.HookFromAddress(address, detour));
            if (hook == null)
                services.Log.Warning("[AihanaPvp] GetAdjustedActionId unavailable; ninja hotbar rules are disabled.");
        }
        catch (Exception ex)
        {
            services.Log.Warning(ex, "[0xPvpPlugin] Failed to initialize ninja hotbar hook.");
            hook?.Dispose();
            hook = null;
        }
    }

    internal static Hook<ActionManager.Delegates.GetAdjustedActionId>? CreateResolvedHook(
        nint function, ActionManager.Delegates.GetAdjustedActionId detour,
        Func<nint, ActionManager.Delegates.GetAdjustedActionId, Hook<ActionManager.Delegates.GetAdjustedActionId>> create)
    {
        if (function == 0) return null;
        var result = create(function, detour);
        try
        {
            result.Enable();
            return result;
        }
        catch
        {
            result.Dispose();
            throw;
        }
    }

    private uint Detour(ActionManager* actionManager, uint actionId)
    {
        var ninjaContext = false;
        try
        {
            if (hook == null || !services.ClientState.IsPvP) return Original(actionManager, actionId);

            var local = services.Objects.LocalPlayer;
            if (local == null || !JobActionPolicy.NinjaEnabled(true, services.ClientState.IsPvP,
                local.ClassJob.RowId, !local.IsDead && local.CurrentHp > 0)) return Original(actionManager, actionId);
            ninjaContext = true;

            if (configuration.TD && actionId == ShukuchiActionId)
                return ShukuchiActionId;

            if (configuration.MS &&
                actionId == MeisuiActionId &&
                local.StatusList.Any(status => status.StatusId == ThreeMudraStatusId))
            {
                return BlockedActionId;
            }

            if (configuration.XDTZ && actionId == SeitonTenchuActionId && local.CurrentHp != 0)
            {
                if (services.Targets.Target is not IPlayerCharacter target ||
                    target.CurrentHp == 0 ||
                    target.MaxHp == 0 ||
                    (ulong)target.CurrentHp * 2UL >= target.MaxHp)
                {
                    return BlockedActionId;
                }
            }

            return Original(actionManager, actionId);
        }
        catch (Exception ex)
        {
            if (Environment.TickCount64 - lastErrorAt > 5000)
            {
                lastErrorAt = Environment.TickCount64;
                services.Log.Warning(ex, "[0xPvpPlugin] Ninja hotbar detour failed.");
            }

            return ninjaContext && actionId == SeitonTenchuActionId ? BlockedActionId : Original(actionManager, actionId);
        }
    }

    private uint Original(ActionManager* actionManager, uint actionId)
        => hook?.Original(actionManager, actionId) ?? actionId;

    public void Dispose()
    {
        hook?.Dispose();
        hook = null;
    }
}
