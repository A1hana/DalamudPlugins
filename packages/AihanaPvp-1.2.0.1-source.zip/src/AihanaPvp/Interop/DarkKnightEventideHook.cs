using System.Numerics;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Hooking;
using FFXIVClientStructs.FFXIV.Client.Game;
using OPP.Core;
using NativeObject = FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject;
using ActionRow = Lumina.Excel.Sheets.Action;

namespace OPP.Interop;

internal sealed unsafe class DarkKnightEventideHook : IDisposable, IEventideRuntime
{
    private readonly PluginServices services;
    private readonly Configuration config;
    private readonly EventideAimController controller;
    private Hook<ActionManager.Delegates.UseActionLocation>? useHook;
    private Hook<ActionManager.Delegates.AutoFaceTargetPosition>? faceHook;
    private bool handlingAction;
    private bool suppressAutoFace;
    private long lastErrorAt;

    internal bool Available => useHook is { IsEnabled: true } && faceHook is { IsEnabled: true };
    internal int? LastHitCount => controller.LastHitCount;

    internal DarkKnightEventideHook(PluginServices services, Configuration config)
    {
        this.services = services;
        this.config = config;
        controller = new(this);
        try
        {
            // Validate the local game's row; do not apply this footprint to the LB follow-up.
            var row = services.DataManager.GetExcelSheet<ActionRow>().GetRowOrDefault(JobActionPolicy.Eventide);
            if (row is not { } action || !action.IsPvP || action.ClassJob.RowId != JobActionPolicy.DarkKnight
                || action.ActionCategory.RowId != 15 || action.Range != 0 || !action.CanTargetSelf
                || action.TargetArea || action.CastType != 4 || action.EffectRange != 30 || action.XAxisModifier != 6)
                throw new InvalidOperationException("当前客户端夜昏数据与 30×6 米自身范围不匹配。");
            useHook = services.Interop.HookFromAddress<ActionManager.Delegates.UseActionLocation>(
                ActionManager.Addresses.UseActionLocation.Value, UseDetour);
            faceHook = services.Interop.HookFromAddress<ActionManager.Delegates.AutoFaceTargetPosition>(
                ActionManager.Addresses.AutoFaceTargetPosition.Value, FaceDetour);
            faceHook.Enable();
            useHook.Enable();
        }
        catch (Exception exception)
        {
            services.Log.Warning(exception, "[AihanaPvp] 夜昏方向辅助不可用；技能仍按原游戏逻辑释放。");
            Dispose();
        }
    }

    private bool UseDetour(ActionManager* manager, ActionType type, uint id, ulong targetId,
        Vector3* location, uint extraParam, byte a7)
    {
        if (handlingAction || !Available || !config.DarkKnightAutoAim
            || type != ActionType.Action || id != JobActionPolicy.Eventide)
            return useHook!.Original(manager, type, id, targetId, location, extraParam, a7);

        handlingAction = true;
        try
        {
            return controller.Execute((uint)type, id, targetId, config.DarkKnightAutoAim, (resolvedTarget, aimed) =>
            {
                suppressAutoFace = aimed;
                try { return useHook!.Original(manager, type, id, resolvedTarget, location, extraParam, a7); }
                finally { suppressAutoFace = false; }
            });
        }
        finally { handlingAction = false; }
    }

    private void FaceDetour(ActionManager* manager, Vector3* position, ulong targetId)
    {
        // Suppress native target-facing only inside this one aimed Eventide dispatch.
        if (!suppressAutoFace) faceHook!.Original(manager, position, targetId);
    }

    public bool TryGetPlayer(out EventidePlayer player)
    {
        player = default;
        var local = services.Objects.LocalPlayer;
        if (local == null || local.Address == 0 || !services.ClientState.IsLoggedIn
            || services.Condition[ConditionFlag.BetweenAreas] || services.Condition[ConditionFlag.BetweenAreas51]) return false;
        player = new(local.GameObjectId, local.ClassJob.RowId, services.ClientState.IsPvP,
            !local.IsDead && local.CurrentHp > 0, local.Position, local.Rotation);
        return float.IsFinite(player.Position.X) && float.IsFinite(player.Position.Y) && float.IsFinite(player.Position.Z);
    }

    public bool IsReady(ulong playerId)
    {
        var manager = ActionManager.Instance();
        return manager != null && manager->GetActionStatus(ActionType.Action, JobActionPolicy.Eventide, playerId) == 0;
    }

    public IReadOnlyList<EventideEnemy> CaptureEnemies(Vector3 origin)
    {
        var result = new List<EventideEnemy>(48);
        var localId = services.Objects.LocalPlayer?.GameObjectId;
        foreach (var obj in services.Objects.PlayerObjects)
        {
            if (obj is not IPlayerCharacter enemy || enemy.Address == 0 || enemy.GameObjectId == localId
                || !enemy.IsTargetable || enemy.IsDead || enemy.CurrentHp == 0) continue;
            var position = enemy.Position;
            if (!float.IsFinite(position.X) || !float.IsFinite(position.Y) || !float.IsFinite(position.Z)
                || MathF.Abs(position.Y - origin.Y) > config.DarkKnightMaxHeight) continue;
            var radius = enemy.HitboxRadius;
            if (!float.IsFinite(radius) || radius < 0) continue;
            var offset = new Vector2(position.X - origin.X, position.Z - origin.Z);
            // A rotation cannot reach a hitbox beyond the rectangle's circumscribed circle.
            if (offset.LengthSquared() > MathF.Pow(MathF.Sqrt(234) + radius, 2)) continue;
            // Target-category check only; this never initiates an auto-attack.
            if (!ActionManager.CanUseActionOnTarget(7, (NativeObject*)enemy.Address)) continue;
            result.Add(new(offset, radius));
        }
        return result;
    }

    public EventideTargets CaptureTargets()
        => new(services.Targets.Target?.GameObjectId ?? 0, services.Targets.SoftTarget?.GameObjectId ?? 0);

    public void ClearTargets()
    {
        services.Targets.SoftTarget = null;
        services.Targets.Target = null;
    }

    public void SetFacing(ulong playerId, float rotation)
    {
        var local = services.Objects.LocalPlayer;
        if (local == null || local.Address == 0 || local.GameObjectId != playerId || !float.IsFinite(rotation))
            throw new InvalidOperationException("角色已变化，无法调整面向。");
        ((NativeObject*)local.Address)->SetRotation(rotation);
    }

    public void RestoreTargets(EventideTargets targets)
    {
        services.Targets.Target = targets.Hard == 0 ? null : services.Objects.SearchById(targets.Hard);
        services.Targets.SoftTarget = targets.Soft == 0 ? null : services.Objects.SearchById(targets.Soft);
    }

    public void ReportError(Exception exception)
    {
        if (Environment.TickCount64 - lastErrorAt < 5000) return;
        lastErrorAt = Environment.TickCount64;
        services.Log.Warning(exception, "[AihanaPvp] 夜昏方向计算失败，本次保持原技能请求。");
    }

    public void Dispose()
    {
        useHook?.Dispose();
        faceHook?.Dispose();
        useHook = null;
        faceHook = null;
    }
}
