using Dalamud.Game.ClientState.Objects.SubKinds;
using System;
using System.Runtime.InteropServices;

namespace OPP.Interop;

internal sealed class NativeGameFunctions
{
    private const string CanUseActionOnTargetSignature =
        "48 89 5C 24 ?? 57 48 83 EC 20 48 8B DA 8B F9 E8 ?? ?? ?? ?? 4C 8B C3";

    private readonly PluginServices services;
    private CanUseActionOnTargetDelegate? canUseActionOnTarget;

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate byte CanUseActionOnTargetDelegate(uint actionId, nint targetAddress);

    public bool CanAttackAvailable => canUseActionOnTarget != null;

    public NativeGameFunctions(PluginServices services)
    {
        this.services = services;
        try
        {
            var address = services.SigScanner.ScanText(CanUseActionOnTargetSignature);
            canUseActionOnTarget = Marshal.GetDelegateForFunctionPointer<CanUseActionOnTargetDelegate>(address);
        }
        catch (Exception ex)
        {
            services.Log.Warning(ex, "[0xPvpPlugin] CanUseActionOnTarget signature unavailable; target scan and radar are disabled.");
        }
    }

    public bool CanAttack(IPlayerCharacter player)
    {
        if (canUseActionOnTarget == null || player.Address == nint.Zero) return false;
        try
        {
            // Preserve the original plugin's attackability probe and action id.
            return canUseActionOnTarget(142, player.Address) != 0;
        }
        catch (Exception ex)
        {
            services.Log.Warning(ex, "[0xPvpPlugin] CanUseActionOnTarget call failed.");
            return false;
        }
    }

}
