namespace OPP.Interop;

internal static class MovementSpeedLayout
{
    // Direct read of Control.BaseMoveSpeed, verified against the local 7.57 CN
    // executable. Resolve the RIP operand itself, with no legacy +20 adjustment.
    internal const string BaseSpeedSignature =
        "F3 0F 10 35 ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 0F 44 0F 28 C0 F3 44 0F 59 C6";
    internal const string MoveControlSignature =
        "E8 ?? ?? ?? ?? 48 ?? ?? 74 ?? 83 ?? ?? 75 ?? 0F ?? ?? ?? 66";
    internal const int BaseSpeedOffset = 0x7118;
    internal const int AnimationSpeedOffset = 8;

    internal static bool MatchesControl(nint baseSpeed, nint control)
        => baseSpeed != 0 && control != 0 && baseSpeed == control + BaseSpeedOffset;
}
