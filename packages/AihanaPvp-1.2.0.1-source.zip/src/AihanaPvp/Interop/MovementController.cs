using Dalamud;
using Dalamud.Game.ClientState.Conditions;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using OPP.Core;

namespace OPP.Interop;

internal sealed unsafe class MovementController
{
    private readonly PluginServices services;
    private readonly MovementSpeedPatch patch;
    private nint globalSpeedAddress;
    private nint moveControlFunction;
    private bool resolutionAttempted;
    private float requestedMultiplier = 1f;
    private long nextUpdateAt;
    private bool recoveryPending;
    private string lastReportedError = string.Empty;

    public bool SpeedAvailable { get; private set; }
    public string SpeedStatus { get; private set; } = "使用默认移速";
    public float? AppliedMultiplier { get; private set; }
    public float? AppliedBaseSpeed => patch.AppliedBaseSpeed;

    public MovementController(PluginServices services)
    {
        this.services = services;
        patch = new MovementSpeedPatch(new NativeSpeedMemory());
    }

    // UI callbacks only record intent. Native calls and writes run on Framework.Update.
    public void RequestSpeedMultiplier(float multiplier)
    {
        requestedMultiplier = float.IsFinite(multiplier) ? Math.Clamp(multiplier, 0.1f, 10f) : 1f;
        nextUpdateAt = 0;
        if (!SpeedAvailable) resolutionAttempted = false;
        AppliedMultiplier = null;
        SpeedStatus = requestedMultiplier == 1f ? "等待恢复默认移速" : "已保存，等待应用";
    }

    public void Update()
    {
        var now = Environment.TickCount64;
        if (now < nextUpdateAt) return;
        nextUpdateAt = now + 250;
        var local = services.Objects.LocalPlayer;
        var ready = services.ClientState.IsLoggedIn && local is { Address: not 0, IsDead: false, CurrentHp: > 0 }
            && !services.Condition[ConditionFlag.BetweenAreas] && !services.Condition[ConditionFlag.BetweenAreas51];
        if (requestedMultiplier == 1f || !ready || recoveryPending)
        {
            if (!patch.Restore(out var restoreError)) { Fail(restoreError); return; }
            recoveryPending = false;
            AppliedMultiplier = null;
            if (requestedMultiplier == 1f) { SpeedStatus = "使用默认移速"; return; }
            if (!ready) { SpeedStatus = "已保存，等待角色或区域加载完成"; return; }
        }
        if (!ResolveSpeedAddresses()) return;
        try
        {
            // MoveControl is native EXD row 1. Resolve it again after zoning or a
            // data-cache reload; never persist a raw row pointer across updates.
            var row = ((delegate* unmanaged<uint, nint>)moveControlFunction)(1);
            if (row == 0)
            {
                if (!patch.Restore(out var restoreError)) { Fail(restoreError); return; }
                AppliedMultiplier = null;
                SpeedStatus = "已保存，等待移动数据加载";
                return;
            }
            if (!patch.Apply(globalSpeedAddress, row + MovementSpeedLayout.AnimationSpeedOffset, requestedMultiplier, out var error))
            {
                recoveryPending = true;
                Fail(error);
                return;
            }
            AppliedMultiplier = requestedMultiplier;
            SpeedStatus = $"已应用 {requestedMultiplier:0.0} 倍（写入值已回读确认）";
            lastReportedError = string.Empty;
        }
        catch (Exception exception)
        {
            recoveryPending = true;
            Fail("移速应用发生错误，请查看日志", exception);
        }
    }

    private bool ResolveSpeedAddresses()
    {
        if (resolutionAttempted) return SpeedAvailable;
        resolutionAttempted = true;
        try
        {
            if (!services.SigScanner.TryGetStaticAddressFromSig(MovementSpeedLayout.BaseSpeedSignature, out var baseSpeed))
            {
                Fail("未找到当前客户端的移动速度字段，可点击重新应用重试");
                return false;
            }
            if (!services.SigScanner.TryScanText(MovementSpeedLayout.MoveControlSignature, out var resolvedMoveControl))
            {
                Fail("未找到当前客户端的移动动画数据入口，可点击重新应用重试");
                return false;
            }
            if (!MovementSpeedLayout.MatchesControl(baseSpeed, (nint)Control.Instance()))
            {
                Fail("移速字段与当前客户端布局不一致，已停止写入");
                return false;
            }
            globalSpeedAddress = baseSpeed;
            moveControlFunction = resolvedMoveControl;
            SpeedAvailable = moveControlFunction != 0;
            if (!SpeedAvailable) { Fail("移动动画数据入口无效"); return false; }
            services.Log.Information("[AihanaPvp] 移速字段解析成功，Control+0x{Offset:X}，动画字段+0x{AnimationOffset:X}",
                MovementSpeedLayout.BaseSpeedOffset, MovementSpeedLayout.AnimationSpeedOffset);
            return true;
        }
        catch (Exception exception)
        {
            Fail("移速地址解析失败，可点击重新应用重试", exception);
            return false;
        }
    }

    private void Fail(string reason, Exception? exception = null)
    {
        AppliedMultiplier = null;
        SpeedStatus = "未应用：" + reason;
        if (reason == lastReportedError) return;
        lastReportedError = reason;
        if (exception != null) services.Log.Warning(exception, "[AihanaPvp] {Reason}", reason);
        else services.Log.Warning("[AihanaPvp] {Reason}", reason);
    }

    public bool TryMoveVertical(float delta)
    {
        var local = services.Objects.LocalPlayer;
        if (local == null || local.Address == 0) return false;
        try
        {
            var gameObject = (GameObject*)local.Address;
            var position = local.Position;
            gameObject->SetPosition(position.X, position.Y + delta, position.Z);
            return true;
        }
        catch (Exception exception)
        {
            services.Log.Warning(exception, "[AihanaPvp] Failed to move player vertically.");
            return false;
        }
    }

    public void RestoreDefaultSpeed()
    {
        if (!patch.Restore(out var error)) Fail(error);
        AppliedMultiplier = null;
    }

    private sealed class NativeSpeedMemory : ISpeedMemory
    {
        public bool Read(nint address, out float value) => SafeMemory.Read(address, out value);
        public bool Write(nint address, float value) => SafeMemory.Write(address, value);
    }
}
