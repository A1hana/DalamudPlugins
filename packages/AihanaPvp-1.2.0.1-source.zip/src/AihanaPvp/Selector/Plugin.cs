using System;
using Dalamud.Plugin;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;
using ECommons;
using PvpAutoLb.Core;
using PvpAutoLb.Windows;
namespace PvpAutoLb;
public sealed class Plugin : IDisposable
{
    internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    internal static ITextureProvider TextureProvider => ECommons.DalamudServices.Svc.Texture;
    internal Configuration Configuration { get; }
    internal WindowSystem WindowSystem { get; } = new("IntegratedSelector");
    internal AutoLbController Controller { get; }
    private readonly PresetIpc presetIpc;
    private readonly NinjaTenchuProtector ninjaTenchuProtector;
    private readonly ConfigWindow configWindow;
    private readonly MainWindow mainWindow;
    private readonly AboutWindow aboutWindow;
    public Plugin(IDalamudPluginInterface pluginInterface, IDalamudPlugin owner, Configuration configuration, Action save)
    {
        PluginInterface = pluginInterface;

        Configuration = configuration;
        Configuration.Persist = save;
        try
        {
        ECommonsMain.Init(pluginInterface, owner);
        Configuration.MigrateIfNeeded();
        Controller = new AutoLbController(Configuration);
        ninjaTenchuProtector = new NinjaTenchuProtector(Configuration);
        presetIpc = new PresetIpc(Configuration);
        configWindow = new ConfigWindow(this);
        mainWindow = new MainWindow(this);
        aboutWindow = new AboutWindow();
        WindowSystem.AddWindow(configWindow);
        WindowSystem.AddWindow(mainWindow);
        WindowSystem.AddWindow(aboutWindow);
        } catch { Dispose(); throw; }
    }
    public void Draw() => WindowSystem.Draw();
    public void ToggleConfigUi() => configWindow.Toggle();
    public void ToggleMainUi() => mainWindow.Toggle();
    public void ToggleAboutUi() => aboutWindow.Toggle();
    public void Dispose()
    {
        WindowSystem.RemoveAllWindows();
        configWindow?.Dispose(); mainWindow?.Dispose(); aboutWindow?.Dispose();
        presetIpc?.Dispose(); ninjaTenchuProtector?.Dispose(); Controller?.Dispose();
        Configuration.Persist = null;
        ECommonsMain.Dispose();
    }
}
