using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility.Raii;
using PvpAutoLb.Core;

namespace PvpAutoLb.Windows.Components;

internal static class StatusPill
{
    public static (Vector4 Color, string Text) Resolve(bool firing, bool wouldFire, LbReadyReason readiness, bool enabled)
    {
        if (firing)    return (Styling.AccentGreen, "SELECTED");
        if (wouldFire) return (Styling.BadgeWouldFire, "WAITING");
        if (!enabled)  return (Styling.TextMuted, "DISABLED");
        return readiness switch
        {
            LbReadyReason.Ready      => (Styling.AccentOrange, "ARMED"),
            LbReadyReason.OutOfRange => (Styling.AccentAmber, "OUT OF RANGE"),
            _                        => (Styling.TextMuted, "GAUGE LOW"),
        };
    }

    public static void Draw(bool firing, bool wouldFire, LbReadyReason readiness, bool enabled)
    {
        var (color, text) = Resolve(firing, wouldFire, readiness, enabled);
        using (ImRaii.PushColor(ImGuiCol.Text, color))
            ImGui.TextUnformatted(text);
    }

    public static void DrawSupport(string text)
    {
        using (ImRaii.PushColor(ImGuiCol.Text, Styling.AccentAmber))
            ImGui.TextUnformatted(text);
    }

    public static float MeasureWidth(string text) => ImGui.CalcTextSize(text).X;
}
