using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Interface;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Utility.Raii;
using ECommons.DalamudServices;
using PvpAutoLb.Core;

namespace PvpAutoLb.Windows.Components;

internal static class HeroCard
{
    public static void Draw(IBattleChara target, bool below, Configuration cfg, LbDrawState state,
        float? percentOverride = null)
    {
        var selected = Svc.Targets.Target?.GameObjectId == target.GameObjectId;
        var border = ResolveBorder(below, cfg.Enabled, state.CanLock, selected);

        using (Card.Begin("##hero", Layout.HeroCardHeight * ImGuiHelpers.GlobalScale, Styling.CardBgHero, border, 1.5f))
        {
            ImGui.SetWindowFontScale(1.22f);
            ImGui.TextUnformatted(target.Name.TextValue);
            ImGui.SetWindowFontScale(1.0f);

            var distLabel = $"{Geo.DistanceToPlayer(target):F1} y";
            var distWidth = ImGui.CalcTextSize(distLabel).X;
            Styling.SameLineRightAligned(distWidth);
            using (ImRaii.PushColor(ImGuiCol.Text, Styling.TextDim))
                ImGui.TextUnformatted(distLabel);

            HpBar.Draw(target.CurrentHp, target.MaxHp, HpMath.ShieldHp(target), selected, cfg, state.JobId,
                Layout.HpBarHeightHero, percentOverride);

            ImGui.Spacing();
            DrawStatusBadge(below, selected, cfg, state, percentOverride);
        }
    }

    private static Vector4 ResolveBorder(bool below, bool enabled, bool canLock, bool selected)
    {
        if (selected) return Styling.AccentGreen;
        if (below && canLock) return Styling.BorderWouldFire;
        if (below) return Styling.AccentAmber;
        if (enabled) return Styling.AccentOrange;
        return Styling.CardBorderDim;
    }

    private static void DrawStatusBadge(bool below, bool selected, Configuration cfg, LbDrawState state,
        float? percentOverride)
    {
        FontAwesomeIcon icon;
        Vector4 color;
        string text;
        if (selected)
        {
            icon = FontAwesomeIcon.Crosshairs;
            color = Styling.AccentGreen;
            text = "Target selected — automatic scanning paused";
        }
        else if (below && !cfg.Enabled)
        {
            icon = FontAwesomeIcon.Pause;
            color = Styling.BadgeWouldFire;
            text = "Eligible target — auto-target is paused";
        }
        else if (below && state.IsSupport)
        {
            icon = FontAwesomeIcon.InfoCircle;
            color = Styling.AccentAmber;
            text = state.ModeBlurb;
        }
        else if (below && !state.ActionReady)
        {
            icon = FontAwesomeIcon.Hourglass;
            color = Styling.AccentAmber;
            text = "Eligible target — waiting for LB to be ready";
        }
        else if (cfg.Enabled)
        {
            icon = FontAwesomeIcon.Hourglass;
            color = Styling.AccentOrange;
            text = below
                ? "Eligible target — ready to lock"
                : percentOverride is { } percent
                    ? $"Waiting — current HP must drop below {percent:F0}%"
                    : cfg.FormatEffective(state.JobId, "Waiting — drop below ");
        }
        else
        {
            icon = FontAwesomeIcon.Pause;
            color = Styling.TextMuted;
            text = "Plugin disabled";
        }

        using (ImRaii.PushFont(UiBuilder.IconFont))
        using (ImRaii.PushColor(ImGuiCol.Text, color))
            ImGui.TextUnformatted(icon.ToIconString());
        ImGui.SameLine();
        using (ImRaii.PushColor(ImGuiCol.Text, color))
            ImGui.TextUnformatted(text);
    }
}
