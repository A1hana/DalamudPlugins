using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Utility.Raii;
using ECommons.DalamudServices;
using PvpAutoLb.Core;

namespace PvpAutoLb.Windows.Components;

// One glanceable line answering "what is the plugin about to do?" — and, just as importantly, "why is
// nothing happening?" (not in PvP, this duty turned off, no LB on this job). The HeroCard never sees those
// cases because it only draws when there are candidates, so this is the window-level anchor.
internal static class StatusLine
{
    private readonly record struct Status(FontAwesomeIcon Icon, Vector4 Color, string Text, bool Pulse);

    public static void Draw(Configuration cfg, AutoLbController ctrl, LbDrawState state)
    {
        var s = Resolve(cfg, ctrl, state);
        var bg = Vector4.Lerp(Styling.CardBgSoft, s.Color, 0.10f);
        var height = ImGui.GetTextLineHeight() + 16f * ImGuiHelpers.GlobalScale;

        using (Card.Begin("##statusline", height, bg, s.Color, s.Pulse ? 1.5f : 1f))
        {
            using (ImRaii.PushFont(UiBuilder.IconFont))
            using (ImRaii.PushColor(ImGuiCol.Text, s.Color))
                ImGui.TextUnformatted(s.Icon.ToIconString());
            ImGui.SameLine();
            using (ImRaii.PushColor(ImGuiCol.Text, s.Color))
                ImGui.TextUnformatted(s.Text);
        }
    }

    private static Status Resolve(Configuration cfg, AutoLbController ctrl, LbDrawState state)
    {
        if (!cfg.Enabled)
            return new(FontAwesomeIcon.Pause, Styling.TextMuted, "Auto-target is off — your target will not be changed.", false);

        if (state.JobId == 0)
            return new(FontAwesomeIcon.Hourglass, Styling.TextDim, "Standing by — waiting for your character.", false);

        var duty = DutyDetector.Current();
        if (duty == DutyMask.None)
            return new(FontAwesomeIcon.Satellite, Styling.TextDim, "Not in a PvP duty — standing by.", false);

        if ((cfg.EnabledDuties & duty) == 0)
            return new(FontAwesomeIcon.Filter, Styling.AccentAmber,
                $"Off for {DutyName(duty)} — see Filters in Settings.", false);

        if (state.ActionId == 0)
            return new(FontAwesomeIcon.Ban, Styling.TextDim, "This job has no PvP Limit Break.", false);

        if (state.IsSupport)
            return new(FontAwesomeIcon.InfoCircle, Styling.AccentAmber, state.ModeBlurb + ".", false);

        if (Svc.Targets.Target is { } hardTarget)
        {
            var targetName = hardTarget is Dalamud.Game.ClientState.Objects.Types.IBattleChara battle
                ? Truncate(battle.Name.TextValue, 18)
                : "current target";

            if (state.JobId == PvpAutoLbConstants.NinjaJobId
                && cfg.PreventUnsafeNinjaTenchu
                && hardTarget is Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter playerTarget)
            {
                var protectedHpPct = playerTarget.MaxHp == 0
                    ? 0f
                    : 100f * playerTarget.CurrentHp / playerTarget.MaxHp;
                if (!HpMath.IsCurrentHpBelowPercent(playerTarget,
                        PvpAutoLbConstants.NinjaExecuteThresholdPercent))
                    return new(FontAwesomeIcon.Lock, Styling.AccentAmber,
                        $"Seiton Tenchu protected: {targetName} is at {protectedHpPct:F0}% current HP.", false);

                if (StatusFilter.IsImmuneToLb(playerTarget))
                    return new(FontAwesomeIcon.Lock, Styling.AccentAmber,
                        StatusFilter.IsCovered(playerTarget)
                            ? $"Seiton Tenchu protected: {targetName} is Covered by Paladin Guardian."
                            : $"Seiton Tenchu protected: {targetName} cannot currently be executed.", false);
            }

            return cfg.AutoFireLb
                ? new(FontAwesomeIcon.BoltLightning, Styling.AccentGreen,
                    $"Target selected: {targetName} — automatic LB use is enabled.", false)
                : new(FontAwesomeIcon.Crosshairs, Styling.AccentGreen,
                    $"Target selected: {targetName} — automatic scanning paused.", false);
        }

        var target = ctrl.LastResolvedTarget;
        var percentOverride = ctrl.ActiveThresholdPercentOverride;
        var threshold = percentOverride is { } percent
            ? $"{percent:F0}% current HP"
            : cfg.FormatEffective(state.JobId, string.Empty).Trim();

        if (target == null || target.IsDead)
            return new(FontAwesomeIcon.Bullseye, Styling.AccentOrange,
                ctrl.IsNinjaChainScanning
                    ? $"Ninja chain scanning — waiting for a hostile below {threshold}."
                    : $"Scanning — waiting for a hostile below {threshold}.", false);

        var name = Truncate(target.Name.TextValue, 18);
        var hpPct = target.MaxHp == 0 ? 0f : target.CurrentHp * 100f / target.MaxHp;

        if (!HpMath.IsBelowThreshold(target, cfg, state.JobId, percentOverride,
                ctrl.ActiveThresholdIgnoresShields))
            return new(FontAwesomeIcon.Hourglass, Styling.AccentOrange,
                $"Watching {name} ({hpPct:F0}%) — locks below {threshold}.", false);

        if (!state.ActionReady || !ctrl.LastCandidateReady)
        {
            var why = state.Readiness == LbReadyReason.OutOfRange ? "out of range" : "gauge not full";
            return new(FontAwesomeIcon.Hourglass, Styling.AccentAmber,
                $"Candidate {name} found — waiting for LB ({why}).", false);
        }

        return new(FontAwesomeIcon.BoltLightning,
            Styling.PulseColor(Styling.AccentRed, Styling.AccentRedBright, Styling.PulseFast),
            $"Locking {name} at {hpPct:F0}%.", true);
    }

    private static string DutyName(DutyMask duty) => duty switch
    {
        DutyMask.CrystallineConflict => "Crystalline Conflict",
        DutyMask.Frontline => "Frontline",
        DutyMask.RivalWings => "Rival Wings",
        DutyMask.CustomMatch => "Custom Match",
        _ => "this mode",
    };

    private static string Truncate(string name, int max)
        => name.Length <= max ? name : name[..(max - 1)] + "…";
}
