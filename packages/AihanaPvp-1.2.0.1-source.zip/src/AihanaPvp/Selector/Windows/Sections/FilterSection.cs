using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility.Raii;
using PvpAutoLb.Core;
using PvpAutoLb.Windows.Components;

namespace PvpAutoLb.Windows.Sections;

internal static class FilterSection
{
    public static void Draw(Configuration cfg)
    {
        var protectNinja = cfg.PreventUnsafeNinjaTenchu;
        if (SettingsRow.Toggle("##protectninja", "Prevent unsafe Seiton Tenchu",
                "Checks every frame and blocks both the initial and Unsealed Seiton Tenchu when the target is at 50% HP or higher, invulnerable, unkillable, or protected by Paladin's Guardian. Shields and Guard do not count.",
                ref protectNinja))
        {
            cfg.PreventUnsafeNinjaTenchu = protectNinja;
            cfg.Save();
        }

        var guarded = cfg.SkipGuardedTargets;
        if (SettingsRow.Toggle("##skipguarded", "Skip targets using Guard",
                "Guarded targets are skipped for jobs whose LB is reduced by Guard. Ninja's Seiton Tenchu ignores this filter.",
                ref guarded))
        {
            cfg.SkipGuardedTargets = guarded;
            cfg.Save();
        }

        var immune = cfg.SkipInvulnerableTargets;
        if (SettingsRow.Toggle("##skipinvuln", "Skip targets immune to your LB",
                "Skips Paladin Hallowed Ground, Dark Knight Undead Redemption, and party members protected by Paladin Guardian (Covered). Ninja safety always applies these checks while its protection option is enabled.",
                ref immune))
        {
            cfg.SkipInvulnerableTargets = immune;
            cfg.Save();
        }

        DrawDutyMask(cfg);
    }

    private static void DrawDutyMask(Configuration cfg)
    {
        SettingsRow.DrawTitle("Allowed duties");
        SettingsRow.DrawHelper("Auto-target only runs in the PvP modes you tick here.");
        ImGui.Spacing();

        var mask = cfg.EnabledDuties;
        var changed = false;

        changed |= DrawDutyToggle(ref mask, DutyMask.CrystallineConflict, "Crystalline Conflict");
        ImGui.SameLine();
        changed |= DrawDutyToggle(ref mask, DutyMask.Frontline, "Frontline");

        changed |= DrawDutyToggle(ref mask, DutyMask.RivalWings, "Rival Wings");
        ImGui.SameLine();
        changed |= DrawDutyToggle(ref mask, DutyMask.CustomMatch, "Custom Match");

        changed |= DrawDutyToggle(ref mask, DutyMask.Other, "Other PvP");

        if (changed)
        {
            cfg.EnabledDuties = mask;
            cfg.Save();
        }
    }

    private static bool DrawDutyToggle(ref DutyMask mask, DutyMask flag, string label)
    {
        var on = (mask & flag) != 0;
        if (!ImGui.Checkbox(label, ref on)) return false;
        mask = on ? mask | flag : mask & ~flag;
        return true;
    }
}
