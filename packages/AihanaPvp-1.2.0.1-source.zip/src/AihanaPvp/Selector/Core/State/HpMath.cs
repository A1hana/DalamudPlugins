using Dalamud.Game.ClientState.Objects.Types;

namespace PvpAutoLb.Core;

internal static class HpMath
{
    // ShieldPercentage is 0–100 (% of MaxHp).
    public static uint ShieldHp(IBattleChara t)
        => (uint)((ulong)t.MaxHp * t.ShieldPercentage / 100UL);

    public static uint EffectiveHp(IBattleChara t)
        => t.CurrentHp + ShieldHp(t);

    public static bool IsCurrentHpBelowPercent(IBattleChara t, float percent)
        => t.MaxHp != 0 && 100d * t.CurrentHp / t.MaxHp < percent;

    public static bool IsBelowThreshold(IBattleChara t, Configuration cfg, uint jobId,
        float? currentHpPercentOverride = null, bool ignoreShields = false)
    {
        if (currentHpPercentOverride is { } percent)
            return IsCurrentHpBelowPercent(t, percent);

        var hp = ignoreShields ? t.CurrentHp : EffectiveHp(t);
        var th = cfg.EffectiveThresholdFor(jobId);
        if (th.Mode == ThresholdMode.Absolute)
            return hp < th.Absolute;
        if (t.MaxHp == 0) return false;
        return 100f * hp / t.MaxHp < th.Percent;
    }
}
