namespace PvpAutoLb.Core;

internal static class PvpAutoLbConstants
{
    public const string LogPrefix = "[PvpAutoLb]";

    // FFXIV's "no target" sentinel for ActionManager.
    public const ulong NoTargetEntityId = 0xE000_0000UL;

    public const int TickThrottleMs = 33;
    public const int SaveThrottleMs = 250;

    // Seiton Tenchu can become usable again after a kill without a full LB gauge.
    // The game shortens later ready windows, so this is only an upper bound; the
    // action-status check remains the authority before a target is selected.
    public const int NinjaChainWindowMs = 8000;
    public const int NinjaRetargetDelayMs = 100;
    public const float NinjaExecuteThresholdPercent = 50f;
    public const uint NinjaJobId = 30;
    public const uint PaladinJobId = 19;
    public const uint NinjaSeitonTenchuActionId = 29515;
    public const uint NinjaUnsealedSeitonTenchuActionId = 29516;

    // Fallback AoE radius (yalms) when EffectRange is 0.
    public const float UnknownAoeFallbackYalms = 5f;

    public const float DefaultThresholdPercent = 30f;
    public const uint DefaultThresholdAbsolute = 7000;
    public const float DefaultAutoSelectRangeYalms = 30f;

    public const float DefaultAllyHpPercent = 50f;
    public const int DefaultAllyCountNear = 2;
    public const float DefaultAllyRadiusYalms = 15f;
    public const int DefaultEnemyCountNear = 1;
    public const float DefaultEnemyRadiusYalms = 20f;

    public const uint LimitBreakCategoryId = 15;

    public const int PresetApiVersion = 1;

    public static class Ipc
    {
        public const string ApiVersion = "PvpAutoLb.Presets.ApiVersion";
        public const string GetVersion = "PvpAutoLb.Presets.GetVersion";
        public const string Apply = "PvpAutoLb.Presets.Apply";
    }

    public static class ThrottleKeys
    {
        public const string Tick = "PvpAutoLb.Tick";
        public const string Save = "PvpAutoLb.ConfigSave";
        public const string NinjaBlockLog = "PvpAutoLb.NinjaBlockLog";
        public const string AutoFireLog = "PvpAutoLb.AutoFireLog";
    }

    public static class StatusIds
    {
        // PvP Guard (action 29053): heavy damage reduction + CC immunity while up.
        public const uint Guard = 3054;

        // Paladin LB Phalanx (action 29069) grants Hallowed Ground to self: impervious to most attacks, 10s.
        public const uint HallowedGround = 1302;

        // Dark Knight LB Eventide grants Undead Redemption: HP cannot drop below 1, 10s.
        public const uint UndeadRedemption = 3039;

        // Paladin Guardian redirects all damage intended for the protected party member.
        public const uint Covered = 1301;
    }
}
