using System;
using System.Collections.Generic;
using Dalamud.Game.ClientState.Objects.Types;
using ECommons.GameFunctions;
using ECommons.GameHelpers;

namespace PvpAutoLb.Core;

internal sealed record FireDecision(IBattleChara HardTarget, int EnemiesAffected);

internal readonly record struct TargetingOverrides(float? CurrentHpPercentThreshold, bool IgnoreGuard,
    bool IgnoreShields);

internal static class FireDecisionMaker
{
    public static bool IsEligibleOffensiveTarget(LbTargetingProfile profile, Configuration cfg,
        IBattleChara target, TargetingOverrides overrides)
    {
        if (!Player.Available || profile.ActionId == 0) return false;
        if (target.IsDead || !target.IsTargetable || !target.IsHostile()) return false;

        var jobId = Player.Object!.ClassJob.RowId;
        if (!HpMath.IsBelowThreshold(target, cfg, jobId, overrides.CurrentHpPercentThreshold,
                overrides.IgnoreShields))
            return false;
        if (cfg.SkipGuardedTargets && !overrides.IgnoreGuard && StatusFilter.IsGuarded(target)) return false;
        if (jobId == PvpAutoLbConstants.NinjaJobId
            && cfg.PreventUnsafeNinjaTenchu
            && StatusFilter.IsImmuneToLb(target)) return false;
        if (cfg.SkipInvulnerableTargets && StatusFilter.IsImmuneToLb(target)) return false;

        var range = profile.Shape is LbCastShape.CircleAroundCaster
            or LbCastShape.GroundCircle
            or LbCastShape.Donut
            ? EffectiveAoeRadius(profile)
            : EffectiveCastRange(profile, cfg);
        return Geo.DistanceToPlayer(target) <= range;
    }

    public static FireDecision? Decide(LbTargetingProfile profile, LbRule rule, Configuration cfg,
        IReadOnlyList<IBattleChara> hostiles, IReadOnlyList<IBattleChara> allies,
        TargetingOverrides overrides = default)
    {
        if (!Player.Available || profile.ActionId == 0) return null;

        return rule.Mode switch
        {
            LbFireMode.Defensive => DecideDefensive(rule, hostiles, allies),
            LbFireMode.Utility => DecideUtility(rule, hostiles, allies),
            _ => DecideOffensive(profile, cfg, hostiles, overrides),
        };
    }

    private static FireDecision? DecideDefensive(LbRule rule, IReadOnlyList<IBattleChara> hostiles, IReadOnlyList<IBattleChara> allies)
    {
        if (CountWithin(hostiles, rule.EnemyRadiusYalms) < rule.EnemyCountNear) return null;

        var hurt = 0;
        for (var i = 0; i < allies.Count; i++)
        {
            var a = allies[i];
            if (Geo.DistanceToPlayer(a) > rule.AllyRadiusYalms) continue;
            if (a.MaxHp == 0) continue;
            if (100f * HpMath.EffectiveHp(a) / a.MaxHp < rule.AllyHpPercent) hurt++;
        }
        if (hurt < rule.AllyCountNear) return null;

        return new FireDecision(Player.Object!, hurt);
    }

    private static FireDecision? DecideUtility(LbRule rule, IReadOnlyList<IBattleChara> hostiles, IReadOnlyList<IBattleChara> allies)
    {
        if (CountWithin(hostiles, rule.EnemyRadiusYalms) < rule.EnemyCountNear) return null;
        var alliesNear = CountWithin(allies, rule.AllyRadiusYalms);
        if (alliesNear < rule.AllyCountNear) return null;

        return new FireDecision(Player.Object!, alliesNear);
    }

    private static int CountWithin(IReadOnlyList<IBattleChara> list, float radius)
    {
        var n = 0;
        for (var i = 0; i < list.Count; i++)
            if (Geo.DistanceToPlayer(list[i]) <= radius) n++;
        return n;
    }

    private static FireDecision? DecideOffensive(LbTargetingProfile profile, Configuration cfg,
        IReadOnlyList<IBattleChara> hostiles, TargetingOverrides overrides)
    {
        if (hostiles.Count == 0) return null;

        var jobId = Player.Object!.ClassJob.RowId;
        var below = FilterBelowThreshold(hostiles, cfg, jobId, overrides.CurrentHpPercentThreshold,
            overrides.IgnoreShields);
        if (below.Count == 0) return null;

        if (cfg.SkipGuardedTargets && !overrides.IgnoreGuard) below = FilterGuarded(below);
        if (below.Count == 0) return null;

        if ((jobId == PvpAutoLbConstants.NinjaJobId && cfg.PreventUnsafeNinjaTenchu)
            || cfg.SkipInvulnerableTargets) below = FilterImmune(below);
        if (below.Count == 0) return null;

        return profile.Shape switch
        {
            LbCastShape.CircleAroundCaster
                or LbCastShape.GroundCircle
                or LbCastShape.Donut
                => DecidePbAoe(profile, below, overrides.IgnoreShields),

            LbCastShape.CircleAroundTarget
                => DecideCircleAroundTarget(profile, cfg, below, overrides.IgnoreShields),

            _ => DecideSingleTarget(profile, cfg, below, overrides.IgnoreShields),
        };
    }

    private static FireDecision? DecideSingleTarget(LbTargetingProfile profile, Configuration cfg,
        IReadOnlyList<IBattleChara> below, bool ignoreShields)
    {
        var range = EffectiveCastRange(profile, cfg);
        IBattleChara? pick = null;
        var bestHp = uint.MaxValue;
        for (var i = 0; i < below.Count; i++)
        {
            var c = below[i];
            if (Geo.DistanceToPlayer(c) > range) continue;
            var hp = ComparableHp(c, ignoreShields);
            if (hp < bestHp) { pick = c; bestHp = hp; }
        }
        return pick == null ? null : new FireDecision(pick, 1);
    }

    private static FireDecision? DecidePbAoe(LbTargetingProfile profile, IReadOnlyList<IBattleChara> below,
        bool ignoreShields)
    {
        var radius = EffectiveAoeRadius(profile);
        IBattleChara? pick = null;
        var bestHp = uint.MaxValue;
        var count = 0;
        for (var i = 0; i < below.Count; i++)
        {
            var c = below[i];
            if (Geo.DistanceToPlayer(c) > radius) continue;
            count++;
            var hp = ComparableHp(c, ignoreShields);
            if (hp < bestHp) { pick = c; bestHp = hp; }
        }
        return pick == null ? null : new FireDecision(pick, count);
    }

    private static FireDecision? DecideCircleAroundTarget(LbTargetingProfile profile, Configuration cfg,
        IReadOnlyList<IBattleChara> below, bool ignoreShields)
    {
        var castRange = EffectiveCastRange(profile, cfg);
        var aoeRadius = EffectiveAoeRadius(profile);

        IBattleChara? best = null;
        var bestScore = 0;
        var bestHp = uint.MaxValue;

        for (var i = 0; i < below.Count; i++)
        {
            var candidate = below[i];
            if (Geo.DistanceToPlayer(candidate) > castRange) continue;

            var score = 0;
            for (var j = 0; j < below.Count; j++)
            {
                if (Geo.Distance2D(below[j], candidate) <= aoeRadius) score++;
            }

            var comparableHp = ComparableHp(candidate, ignoreShields);
            if (score > bestScore || (score == bestScore && comparableHp < bestHp))
            {
                best = candidate;
                bestScore = score;
                bestHp = comparableHp;
            }
        }

        return best == null ? null : new FireDecision(best, bestScore);
    }

    private static List<IBattleChara> FilterBelowThreshold(IReadOnlyList<IBattleChara> hostiles,
        Configuration cfg, uint jobId, float? percentOverride, bool ignoreShields)
    {
        var result = new List<IBattleChara>(hostiles.Count);
        for (var i = 0; i < hostiles.Count; i++)
        {
            if (HpMath.IsBelowThreshold(hostiles[i], cfg, jobId, percentOverride, ignoreShields))
                result.Add(hostiles[i]);
        }
        return result;
    }

    private static List<IBattleChara> FilterGuarded(List<IBattleChara> below)
    {
        var result = new List<IBattleChara>(below.Count);
        for (var i = 0; i < below.Count; i++)
        {
            if (StatusFilter.IsGuarded(below[i])) continue;
            result.Add(below[i]);
        }
        return result;
    }

    private static List<IBattleChara> FilterImmune(List<IBattleChara> below)
    {
        var result = new List<IBattleChara>(below.Count);
        for (var i = 0; i < below.Count; i++)
        {
            if (StatusFilter.IsImmuneToLb(below[i])) continue;
            result.Add(below[i]);
        }
        return result;
    }

    private static float EffectiveCastRange(LbTargetingProfile profile, Configuration cfg)
        => profile.Range > 0
            ? Math.Min(profile.Range, cfg.AutoSelectRangeYalms)
            : cfg.AutoSelectRangeYalms;

    private static float EffectiveAoeRadius(LbTargetingProfile profile)
        => profile.EffectRange > 0 ? profile.EffectRange : PvpAutoLbConstants.UnknownAoeFallbackYalms;

    private static uint ComparableHp(IBattleChara target, bool ignoreShields)
        => ignoreShields ? target.CurrentHp : HpMath.EffectiveHp(target);
}
