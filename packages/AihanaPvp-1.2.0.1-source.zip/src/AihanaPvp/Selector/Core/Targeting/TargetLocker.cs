using Dalamud.Game.ClientState.Objects.Types;
using ECommons.DalamudServices;

namespace PvpAutoLb.Core;

internal enum TargetOwnershipState
{
    NoTarget,
    ManualTarget,
    OwnedTarget,
    OwnedTargetLost,
}

internal sealed class TargetLocker
{
    private ulong ownedTargetId;

    public TargetOwnershipState Observe()
    {
        var current = Svc.Targets.Target;
        if (ownedTargetId == 0)
            return current == null ? TargetOwnershipState.NoTarget : TargetOwnershipState.ManualTarget;

        if (current == null)
        {
            ownedTargetId = 0;
            return TargetOwnershipState.OwnedTargetLost;
        }

        if (current.GameObjectId != ownedTargetId)
        {
            ownedTargetId = 0;
            return TargetOwnershipState.ManualTarget;
        }

        if (current is not IBattleChara battle || battle.IsDead || !battle.IsTargetable)
        {
            // Only clear a target that this instance selected. A manual target is never
            // modified, even when it is dead or otherwise invalid.
            Svc.Targets.Target = null;
            if (Svc.Targets.Target != null) return TargetOwnershipState.OwnedTarget;

            ownedTargetId = 0;
            return TargetOwnershipState.OwnedTargetLost;
        }

        return TargetOwnershipState.OwnedTarget;
    }

    public bool TryLock(IBattleChara target)
    {
        if (target.IsDead || !target.IsTargetable) return false;
        if (Svc.Targets.Target != null) return false;

        Svc.Targets.Target = target;
        if (Svc.Targets.Target?.GameObjectId != target.GameObjectId) return false;

        ownedTargetId = target.GameObjectId;
        return true;
    }

    public void ForgetOwnership() => ownedTargetId = 0;
}
