using System;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Hooking;
using ECommons.DalamudServices;
using ECommons.GameFunctions;
using ECommons.GameHelpers;
using ECommons.Throttlers;
using FFXIVClientStructs.FFXIV.Client.Game;

namespace PvpAutoLb.Core;

internal sealed unsafe class NinjaTenchuProtector : IDisposable
{
    private const string IsActionIdReplaceableSignature =
        "40 53 48 83 EC 20 8B D9 48 8B 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 85 C0 74 1F";

    private delegate ulong IsActionIdReplaceableDelegate(uint actionId);

    private readonly Configuration cfg;
    private Hook<ActionManager.Delegates.UseAction>? useActionHook;
    private Hook<ActionManager.Delegates.GetActionStatus>? getActionStatusHook;
    private Hook<ActionManager.Delegates.GetAdjustedActionId>? getAdjustedActionHook;
    private Hook<IsActionIdReplaceableDelegate>? isActionIdReplaceableHook;
    private uint unavailableActionId;

    public NinjaTenchuProtector(Configuration cfg)
    {
        this.cfg = cfg;

        try
        {
            _ = LbCatalog.ResolveActionIds(PvpAutoLbConstants.NinjaJobId).Count;
            unavailableActionId = ResolveUnavailableActionId();

            getAdjustedActionHook = Svc.Hook.HookFromAddress<ActionManager.Delegates.GetAdjustedActionId>(
                ActionManager.Addresses.GetAdjustedActionId.Value, GetAdjustedActionIdDetour);
            getActionStatusHook = Svc.Hook.HookFromAddress<ActionManager.Delegates.GetActionStatus>(
                ActionManager.Addresses.GetActionStatus.Value, GetActionStatusDetour);
            useActionHook = Svc.Hook.HookFromAddress<ActionManager.Delegates.UseAction>(
                ActionManager.Addresses.UseAction.Value, UseActionDetour);

            if (Svc.SigScanner.TryScanText(IsActionIdReplaceableSignature, out var replaceableAddress))
            {
                isActionIdReplaceableHook = Svc.Hook.HookFromAddress<IsActionIdReplaceableDelegate>(
                    replaceableAddress, IsActionIdReplaceableDetour);
                isActionIdReplaceableHook.Enable();
            }
            else
            {
                Svc.Log.Warning($"{PvpAutoLbConstants.LogPrefix} action-replacement eligibility function was not found");
            }

            getAdjustedActionHook.Enable();
            getActionStatusHook.Enable();
            useActionHook.Enable();
            Svc.Log.Info($"{PvpAutoLbConstants.LogPrefix} Ninja Seiton Tenchu protection online; replacement action {unavailableActionId}");
        }
        catch (Exception ex)
        {
            Svc.Log.Error(ex, $"{PvpAutoLbConstants.LogPrefix} could not initialize Ninja Seiton Tenchu protection");
            useActionHook?.Dispose();
            getActionStatusHook?.Dispose();
            getAdjustedActionHook?.Dispose();
            isActionIdReplaceableHook?.Dispose();
            useActionHook = null;
            getActionStatusHook = null;
            getAdjustedActionHook = null;
            isActionIdReplaceableHook = null;
        }
    }

    public void Dispose()
    {
        useActionHook?.Disable();
        getActionStatusHook?.Disable();
        getAdjustedActionHook?.Disable();
        isActionIdReplaceableHook?.Disable();
        useActionHook?.Dispose();
        getActionStatusHook?.Dispose();
        getAdjustedActionHook?.Dispose();
        isActionIdReplaceableHook?.Dispose();
        useActionHook = null;
        getActionStatusHook = null;
        getAdjustedActionHook = null;
        isActionIdReplaceableHook = null;
    }

    private ulong IsActionIdReplaceableDetour(uint actionId)
    {
        if (cfg.Enabled
            && cfg.PreventUnsafeNinjaTenchu
            && Player.Available
            && Player.Object!.ClassJob.RowId == PvpAutoLbConstants.NinjaJobId
            && IsSeitonTenchuAction(actionId))
            return 1;

        return isActionIdReplaceableHook!.Original(actionId);
    }

    private uint GetAdjustedActionIdDetour(ActionManager* actionManager, uint actionId)
    {
        var adjustedActionId = getAdjustedActionHook!.Original(actionManager, actionId);

        try
        {
            if (ShouldProtectAction(actionId, adjustedActionId,
                    ResolveTarget(PvpAutoLbConstants.NoTargetEntityId), false))
            {
                if (EzThrottler.Throttle(PvpAutoLbConstants.ThrottleKeys.NinjaBlockLog, 1000))
                    Svc.Log.Debug($"{PvpAutoLbConstants.LogPrefix} replaced unsafe Seiton Tenchu {adjustedActionId} with {unavailableActionId}");
                return unavailableActionId;
            }
        }
        catch (Exception ex)
        {
            // Fail open so icon adjustment errors cannot affect unrelated actions.
            Svc.Log.Error(ex, $"{PvpAutoLbConstants.LogPrefix} Ninja Seiton Tenchu replacement check failed");
        }

        return adjustedActionId;
    }

    // The hotbar asks GetActionStatus on every UI update. Hooking this path makes the
    // manual-use mode re-evaluate live HP and statuses continuously instead of relying
    // only on an icon replacement that may be cached across the Unsealed follow-up.
    private uint GetActionStatusDetour(ActionManager* actionManager, ActionType actionType, uint actionId,
        ulong targetId, bool checkRecastActive, bool checkCastingActive, uint* outOptExtraInfo)
    {
        try
        {
            if (actionType == ActionType.Action)
            {
                var adjustedActionId = getAdjustedActionHook?.Original(actionManager, actionId) ?? actionId;
                if (ShouldProtectAction(actionId, adjustedActionId, ResolveTarget(targetId), true))
                {
                    var blockedStatus = unavailableActionId == 0
                        ? 1u
                        : getActionStatusHook!.Original(actionManager, actionType, unavailableActionId, targetId,
                            checkRecastActive, checkCastingActive, outOptExtraInfo);
                    return blockedStatus == 0 ? 1u : blockedStatus;
                }
            }
        }
        catch (Exception ex)
        {
            // UseAction remains the final live check if the presentation/status path fails.
            Svc.Log.Error(ex, $"{PvpAutoLbConstants.LogPrefix} Ninja Seiton Tenchu action-status check failed");
        }

        return getActionStatusHook!.Original(actionManager, actionType, actionId, targetId,
            checkRecastActive, checkCastingActive, outOptExtraInfo);
    }

    private bool UseActionDetour(ActionManager* actionManager, ActionType actionType, uint actionId,
        ulong targetId, uint extraParam, ActionManager.UseActionMode mode, uint comboRouteId, bool* outOptAreaTargeted)
    {
        try
        {
            if (actionType == ActionType.Action && ShouldBlock(actionManager, actionId, targetId))
            {
                if (EzThrottler.Throttle(PvpAutoLbConstants.ThrottleKeys.NinjaBlockLog, 1000))
                    Svc.Log.Debug($"{PvpAutoLbConstants.LogPrefix} blocked unsafe Seiton Tenchu action request");
                return false;
            }
        }
        catch (Exception ex)
        {
            // Fail open: a protection error must never interfere with unrelated actions.
            Svc.Log.Error(ex, $"{PvpAutoLbConstants.LogPrefix} Ninja Seiton Tenchu protection check failed");
        }

        return useActionHook!.Original(actionManager, actionType, actionId, targetId, extraParam, mode,
            comboRouteId, outOptAreaTargeted);
    }

    private bool ShouldBlock(ActionManager* actionManager, uint actionId, ulong targetId)
    {
        var adjustedActionId = getAdjustedActionHook?.Original(actionManager, actionId) ?? actionId;
        return ShouldProtectAction(actionId, adjustedActionId, ResolveTarget(targetId), true);
    }

    private bool ShouldProtectAction(uint actionId, uint adjustedActionId, IPlayerCharacter? target,
        bool includeReplacementAction)
    {
        if (!cfg.Enabled || !cfg.PreventUnsafeNinjaTenchu) return false;
        if (!Player.Available || Player.Object!.ClassJob.RowId != PvpAutoLbConstants.NinjaJobId) return false;
        if (!IsSeitonTenchuAction(actionId)
            && !IsSeitonTenchuAction(adjustedActionId)
            && !(includeReplacementAction && unavailableActionId != 0 && actionId == unavailableActionId))
            return false;
        if (target == null || target.IsDead || target.CurrentHp == 0 || target.MaxHp == 0
            || !target.IsTargetable || !target.IsHostile()) return true;

        return !HpMath.IsCurrentHpBelowPercent(target, PvpAutoLbConstants.NinjaExecuteThresholdPercent)
            || StatusFilter.IsImmuneToLb(target);
    }

    private static bool IsSeitonTenchuAction(uint actionId)
        => actionId is PvpAutoLbConstants.NinjaSeitonTenchuActionId
            or PvpAutoLbConstants.NinjaUnsealedSeitonTenchuActionId
            || LbCatalog.ContainsAction(PvpAutoLbConstants.NinjaJobId, actionId);

    private static IPlayerCharacter? ResolveTarget(ulong targetId)
    {
        if (targetId is not 0 && targetId != PvpAutoLbConstants.NoTargetEntityId
            && Svc.Objects.SearchById(targetId) is IPlayerCharacter explicitTarget)
            return explicitTarget;

        return Svc.Targets.Target as IPlayerCharacter;
    }

    private static uint ResolveUnavailableActionId()
    {
        var ids = LbCatalog.ResolveActionIds(PvpAutoLbConstants.PaladinJobId);
        return ids.Count > 0 ? ids[0] : 0u;
    }
}
