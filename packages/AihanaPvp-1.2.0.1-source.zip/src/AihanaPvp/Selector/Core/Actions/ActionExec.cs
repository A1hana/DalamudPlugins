using FFXIVClientStructs.FFXIV.Client.Game;

namespace PvpAutoLb.Core;

internal static unsafe class ActionExec
{
    public static bool TryUse(uint actionId, ulong targetId = PvpAutoLbConstants.NoTargetEntityId)
    {
        if (actionId == 0) return false;
        var am = ActionManager.Instance();
        return am != null && am->UseAction(ActionType.Action, actionId, targetId);
    }

    public static bool IsReady(uint actionId, ulong targetId = PvpAutoLbConstants.NoTargetEntityId)
    {
        if (actionId == 0) return false;
        var am = ActionManager.Instance();
        return am != null && am->GetActionStatus(ActionType.Action, actionId, targetId) == 0;
    }

    public static bool TryFindReady(uint jobId, ulong targetId, out uint actionId)
    {
        var actionIds = LbCatalog.ResolveActionIds(jobId);
        for (var i = 0; i < actionIds.Count; i++)
        {
            if (!IsReady(actionIds[i], targetId)) continue;
            actionId = actionIds[i];
            return true;
        }

        actionId = 0;
        return false;
    }
}
