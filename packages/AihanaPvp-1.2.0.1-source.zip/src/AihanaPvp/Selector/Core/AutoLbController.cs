using System;
using System.Collections.Generic;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using ECommons.DalamudServices;
using ECommons.GameHelpers;
using ECommons.Throttlers;

namespace PvpAutoLb.Core;

internal sealed class AutoLbController : IDisposable
{
    private static readonly IReadOnlyList<IBattleChara> EmptyAllies = Array.Empty<IBattleChara>();

    private readonly Configuration cfg;
    private readonly TargetLocker targetLocker = new();
    private DateTime ninjaChainUntilUtc = DateTime.MinValue;
    private DateTime ninjaRetargetAfterUtc = DateTime.MinValue;

    public IBattleChara? LastResolvedTarget { get; private set; }
    public LbTargetingProfile LastProfile { get; private set; } = LbTargetingProfile.None;
    public int LastEnemiesAffected { get; private set; }
    public bool LastCandidateReady { get; private set; }
    public bool IsNinjaChainScanning { get; private set; }
    public bool ActiveThresholdIgnoresShields => Player.Available
        && Player.Object!.ClassJob.RowId == PvpAutoLbConstants.NinjaJobId;
    public float? ActiveThresholdPercentOverride => IsNinjaChainScanning
        ? PvpAutoLbConstants.NinjaExecuteThresholdPercent
        : null;

    public AutoLbController(Configuration cfg)
    {
        this.cfg = cfg;
        Svc.Framework.Update += OnTick;
        Svc.Log.Info(PvpAutoLbConstants.LogPrefix + " controller online — build " + typeof(AutoLbController).Assembly.GetName().Version);
    }

    public void Dispose()
    {
        Svc.Framework.Update -= OnTick;
    }

    private void OnTick(IFramework _)
    {
        try
        {
            Tick();
        }
        catch (Exception ex)
        {
            Svc.Log.Error(ex, $"{PvpAutoLbConstants.LogPrefix} tick failed");
        }
    }

    private void Tick()
    {
        if (!cfg.Enabled) { ResetState(); return; }
        if (!Player.Available) { ResetState(); return; }
        if (!Svc.ClientState.IsPvP || Player.Object!.ClassJob.RowId != PvpAutoLbConstants.NinjaJobId) { ResetState(); return; }
        if (!IsDutyAllowed()) { ResetState(); return; }
        if (!EzThrottler.Throttle(PvpAutoLbConstants.ThrottleKeys.Tick, PvpAutoLbConstants.TickThrottleMs)) return;

        var jobId = Player.Object!.ClassJob.RowId;
        var profile = LbCatalog.ResolveProfile(jobId);
        LastProfile = profile;
        if (profile.ActionId == 0) { ResetState(); return; }

        var rule = cfg.EffectiveRuleFor(jobId);

        // Defensive and utility rules are retained for configuration compatibility, but
        // target selection and optional automatic use remain offensive-only.
        if (rule.Mode != LbFireMode.Offensive)
        {
            ResetState();
            return;
        }

        var ownership = targetLocker.Observe();
        if (ownership == TargetOwnershipState.ManualTarget)
        {
            EndNinjaChain();
            TickCurrentTarget(jobId, profile);
            return;
        }

        if (ownership == TargetOwnershipState.OwnedTarget)
        {
            IsNinjaChainScanning = jobId == PvpAutoLbConstants.NinjaJobId
                && DateTime.UtcNow < ninjaChainUntilUtc;
            TickCurrentTarget(jobId, profile);
            return;
        }

        if (ownership == TargetOwnershipState.OwnedTargetLost)
        {
            if (jobId == PvpAutoLbConstants.NinjaJobId)
                BeginNinjaChain();
            else
                EndNinjaChain();
        }
        else if (jobId != PvpAutoLbConstants.NinjaJobId)
        {
            EndNinjaChain();
        }

        var now = DateTime.UtcNow;
        IsNinjaChainScanning = jobId == PvpAutoLbConstants.NinjaJobId && now < ninjaChainUntilUtc;
        if (IsNinjaChainScanning && now < ninjaRetargetAfterUtc)
        {
            ClearDisplayState();
            IsNinjaChainScanning = true;
            return;
        }
        if (!IsNinjaChainScanning) EndNinjaChain();

        var hostiles = TargetSelector.ScanHostiles(cfg.AutoSelectRangeYalms);

        if (cfg.AutoSelectLowestHp)
            TickAutoSelect(jobId, profile, rule, hostiles);
        else
            ResetState();
    }

    private void TickAutoSelect(uint jobId, LbTargetingProfile profile, LbRule rule, IReadOnlyList<IBattleChara> hostiles)
    {
        var overrides = BuildTargetingOverrides(jobId);
        var decision = FireDecisionMaker.Decide(profile, rule, cfg, hostiles, EmptyAllies, overrides);
        LastResolvedTarget = decision?.HardTarget;
        LastEnemiesAffected = decision?.EnemiesAffected ?? 0;
        LastCandidateReady = false;
        if (decision == null) return;
        if (BlocklistFilter.IsBlocked(decision.HardTarget, cfg.NameBlocklist)) return;

        LastCandidateReady = ActionExec.TryFindReady(jobId, decision.HardTarget.EntityId, out var readyActionId);
        if (!LastCandidateReady) return;

        if (targetLocker.TryLock(decision.HardTarget))
        {
            var mode = IsNinjaChainScanning ? "Ninja chain" : "normal";
            Svc.Log.Debug($"{PvpAutoLbConstants.LogPrefix} locked {mode} target 0x{decision.HardTarget.EntityId:X}");
            TryAutoFire(jobId, decision.HardTarget, readyActionId);
        }
    }

    private void TickCurrentTarget(uint jobId, LbTargetingProfile profile)
    {
        CaptureCurrentTarget(jobId);
        if (!cfg.AutoFireLb || LastResolvedTarget == null) return;

        var target = LastResolvedTarget;
        var overrides = BuildTargetingOverrides(jobId);
        if (!FireDecisionMaker.IsEligibleOffensiveTarget(profile, cfg, target, overrides)) return;
        if (BlocklistFilter.IsBlocked(target, cfg.NameBlocklist)) return;

        TryAutoFire(jobId, target);
    }

    private void CaptureCurrentTarget(uint jobId)
    {
        LastResolvedTarget = Svc.Targets.Target as IBattleChara;
        LastEnemiesAffected = 0;
        LastCandidateReady = LastResolvedTarget != null
            && ActionExec.TryFindReady(jobId, LastResolvedTarget.EntityId, out _);
    }

    private void TryAutoFire(uint jobId, IBattleChara target, uint readyActionId = 0)
    {
        if (!cfg.AutoFireLb) return;
        if (jobId == PvpAutoLbConstants.NinjaJobId
            && cfg.PreventUnsafeNinjaTenchu
            && (!HpMath.IsCurrentHpBelowPercent(target, PvpAutoLbConstants.NinjaExecuteThresholdPercent)
                || StatusFilter.IsImmuneToLb(target))) return;

        if (readyActionId == 0
            && !ActionExec.TryFindReady(jobId, target.EntityId, out readyActionId))
            return;

        LastCandidateReady = true;
        if (!ActionExec.TryUse(readyActionId, target.EntityId)) return;

        if (EzThrottler.Throttle(PvpAutoLbConstants.ThrottleKeys.AutoFireLog, 1000))
            Svc.Log.Debug($"{PvpAutoLbConstants.LogPrefix} auto-fire submitted {readyActionId} on 0x{target.EntityId:X}");
    }

    private TargetingOverrides BuildTargetingOverrides(uint jobId)
    {
        var isNinja = jobId == PvpAutoLbConstants.NinjaJobId;
        return new TargetingOverrides(
            IsNinjaChainScanning ? PvpAutoLbConstants.NinjaExecuteThresholdPercent : null,
            IgnoreGuard: isNinja,
            IgnoreShields: isNinja);
    }

    private void BeginNinjaChain()
    {
        var now = DateTime.UtcNow;
        ninjaRetargetAfterUtc = now.AddMilliseconds(PvpAutoLbConstants.NinjaRetargetDelayMs);
        ninjaChainUntilUtc = now.AddMilliseconds(PvpAutoLbConstants.NinjaChainWindowMs);
        IsNinjaChainScanning = true;
        Svc.Log.Debug($"{PvpAutoLbConstants.LogPrefix} Ninja target lost — checking for a ready Seiton Tenchu follow-up");
    }

    private void EndNinjaChain()
    {
        ninjaRetargetAfterUtc = DateTime.MinValue;
        ninjaChainUntilUtc = DateTime.MinValue;
        IsNinjaChainScanning = false;
    }

    private bool IsDutyAllowed()
    {
        var current = DutyDetector.Current();
        if (current == DutyMask.None) return true;
        return (cfg.EnabledDuties & current) != 0;
    }

    private void ClearDisplayState()
    {
        LastResolvedTarget = null;
        LastEnemiesAffected = 0;
        LastCandidateReady = false;
    }

    private void ResetState()
    {
        ClearDisplayState();
        EndNinjaChain();
        targetLocker.ForgetOwnership();
    }
}
