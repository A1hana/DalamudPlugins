using Dalamud.Configuration;
using Newtonsoft.Json;
using TyniaPVPRadar;

namespace OPP;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    public bool AutoSelect;
    public int SelectDistance = 20;
    public int SelectInterval = 50;
    public bool XDTZ = true;
    public bool TD = true;
    public bool MS = true;
    public bool DarkKnightAutoAim = true;
    public float DarkKnightMaxHeight = 5f;
    public float Dspeed = 1f;
    public int upDistance;
    public int downDistance;
    public int downDistanceAll;
    public PluginConfig Radar { get; set; } = new();
    public PvpAutoLb.Configuration? Selector { get; set; }

    [NonSerialized] private Action<Configuration>? save;

    internal void Initialize(Action<Configuration> persist) => save = persist;

    internal void Normalize()
    {
        SelectDistance = Math.Clamp(SelectDistance, 5, 30);
        SelectInterval = Math.Clamp(SelectInterval, 20, 1000);
        Dspeed = float.IsFinite(Dspeed) ? Math.Clamp(Dspeed, 0.1f, 10f) : 1f;
        DarkKnightMaxHeight = float.IsFinite(DarkKnightMaxHeight) ? Math.Clamp(DarkKnightMaxHeight, 0.5f, 30f) : 5f;
        Radar ??= new PluginConfig();
        Radar.ContextMenuItemsOrder ??= new List<string>();
        Radar.Initialize();
    }

    public void Save()
    {
        // Every module saves the same root. Temporary radar lines remain in memory only.
        var liveLines = Radar.Lines;
        try
        {
            Radar.Lines = liveLines.Where(line => !line.IsTemporary).ToList();
            save?.Invoke(this);
        }
        finally
        {
            Radar.Lines = liveLines;
        }
    }
}
