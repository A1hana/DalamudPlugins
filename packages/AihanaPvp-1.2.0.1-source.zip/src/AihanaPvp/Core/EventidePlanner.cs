using System.Numerics;

namespace OPP.Core;

internal readonly record struct EventideEnemy(Vector2 Offset, float Radius);
internal readonly record struct EventidePlan(float Rotation, int Hits);

// Eventide is a rectangle centred on the caster: 15m each way, 6m total width.
// Search every change in coverage, rather than aiming only at enemy centres or
// using a fixed angle step (both can miss the optimum between two enemies).
internal static class EventidePlanner
{
    internal const double HalfLength = 15;
    internal const double HalfWidth = 3;
    private const double Pi = Math.PI;
    private const double Epsilon = 0.00001;
    private static readonly double CornerDistance = Math.Sqrt(HalfLength * HalfLength + HalfWidth * HalfWidth);

    internal static EventidePlan? FindBest(IReadOnlyList<EventideEnemy> source, float currentRotation)
    {
        if (!float.IsFinite(currentRotation)) return null;
        var enemies = source.Where(Valid).ToArray();
        if (enemies.Length == 0) return null;
        var boundaries = new List<double> { 0 };
        foreach (var enemy in enemies)
        {
            var x = (double)enemy.Offset.X;
            var z = (double)enemy.Offset.Y;
            var distance = Math.Sqrt(x * x + z * z);
            if (distance < Epsilon) continue;
            var bearing = Math.Atan2(x, z);
            AddCosineRoots(bearing, (HalfLength + enemy.Radius) / distance);
            AddCosineRoots(bearing - Pi / 2, (HalfWidth + enemy.Radius) / distance);

            // A hitbox may touch a rounded corner as well as a straight edge.
            // Intersect the target's circle about the caster with each corner arc.
            var cosine = (distance * distance + CornerDistance * CornerDistance - enemy.Radius * enemy.Radius)
                / (2 * distance * CornerDistance);
            foreach (var along in new[] { -HalfLength, HalfLength })
            foreach (var side in new[] { -HalfWidth, HalfWidth })
                AddCosineRoots(bearing - Math.Atan2(side, along), cosine);
        }
        boundaries.Sort();
        var angles = new List<double>(boundaries.Count);
        foreach (var angle in boundaries)
            if (angles.Count == 0 || angle - angles[^1] > 1e-10) angles.Add(angle);

        var best = new EventidePlan(currentRotation, Count(enemies, currentRotation));
        var bestIsInterior = true;
        var bestTurn = 0d;
        for (var i = 0; i < angles.Count; i++)
        {
            Consider(angles[i], false);
            var end = i + 1 < angles.Count ? angles[i + 1] : Pi;
            Consider((angles[i] + end) / 2, true);
        }
        return best.Hits > 0 ? best : null;

        void AddCosineRoots(double centre, double cosine)
        {
            if (cosine < -1 - Epsilon || cosine > 1 + Epsilon) return;
            var delta = Math.Acos(Math.Clamp(cosine, -1, 1));
            boundaries.Add(NormalizeAxis(centre - delta));
            boundaries.Add(NormalizeAxis(centre + delta));
        }

        void Consider(double axis, bool interior)
        {
            // The two facings separated by pi cover exactly the same rectangle.
            var turn = Math.IEEERemainder(axis - currentRotation, Pi);
            var rotation = (float)Math.IEEERemainder(currentRotation + turn, 2 * Pi);
            var hits = Count(enemies, rotation);
            var magnitude = Math.Abs(turn);
            if (hits < best.Hits) return;
            if (hits == best.Hits)
            {
                if (bestTurn < 1e-10) return; // Keep current facing when already optimal.
                if (bestIsInterior && !interior) return;
                if (bestIsInterior == interior && magnitude >= bestTurn) return;
            }
            best = new(rotation, hits);
            bestIsInterior = interior;
            bestTurn = magnitude;
        }
    }

    internal static int Count(IReadOnlyList<EventideEnemy> enemies, float rotation)
    {
        if (!float.IsFinite(rotation)) return 0;
        var sin = Math.Sin(rotation);
        var cos = Math.Cos(rotation);
        var count = 0;
        foreach (var enemy in enemies)
            if (Valid(enemy) && Intersects(enemy, sin, cos)) count++;
        return count;
    }

    internal static bool Hits(EventideEnemy enemy, float rotation)
    {
        if (!Valid(enemy) || !float.IsFinite(rotation)) return false;
        return Intersects(enemy, Math.Sin(rotation), Math.Cos(rotation));
    }

    private static bool Intersects(EventideEnemy enemy, double sin, double cos)
    {
        var along = Math.Abs(enemy.Offset.X * sin + enemy.Offset.Y * cos);
        var side = Math.Abs(enemy.Offset.X * cos - enemy.Offset.Y * sin);
        var outsideLength = Math.Max(along - HalfLength, 0);
        var outsideWidth = Math.Max(side - HalfWidth, 0);
        // Disc/rectangle intersection, without extending the corner to a square.
        return outsideLength * outsideLength + outsideWidth * outsideWidth
            <= Math.Pow(enemy.Radius + Epsilon, 2);
    }

    private static bool Valid(EventideEnemy enemy)
        => float.IsFinite(enemy.Offset.X) && float.IsFinite(enemy.Offset.Y)
            && float.IsFinite(enemy.Radius) && enemy.Radius >= 0
            && (double)enemy.Offset.X * enemy.Offset.X + (double)enemy.Offset.Y * enemy.Offset.Y
                <= Math.Pow(CornerDistance + enemy.Radius + Epsilon, 2);

    private static double NormalizeAxis(double rotation)
    {
        var value = rotation % Pi;
        return value < 0 ? value + Pi : value;
    }
}
