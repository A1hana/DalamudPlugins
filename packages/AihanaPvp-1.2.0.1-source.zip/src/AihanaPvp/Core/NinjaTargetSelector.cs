using Dalamud.Game.ClientState.Objects.SubKinds;
using OPP.Interop;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPP.Core;

internal sealed class NinjaTargetSelector
{
    private const uint PaladinJobId = 19;
    private const uint DarkKnightJobId = 32;
    private const uint ProtectedStatusId = 1301;

    private readonly PluginServices services;
    private readonly Configuration configuration;
    private readonly NativeGameFunctions native;
    private long lastSelectionAt;

    public NinjaTargetSelector(PluginServices services, Configuration configuration, NativeGameFunctions native)
    {
        this.services = services;
        this.configuration = configuration;
        this.native = native;
    }

    public void Update()
    {
        var local = services.Objects.LocalPlayer;
        if (local == null || !native.CanAttackAvailable ||
            !JobActionPolicy.NinjaEnabled(configuration.AutoSelect, services.ClientState.IsPvP,
                local.ClassJob.RowId, !local.IsDead && local.CurrentHp > 0)) return;

        var now = Environment.TickCount64;
        if (now - lastSelectionAt < Math.Clamp(configuration.SelectInterval, 20, 1000)) return;
        lastSelectionAt = now;

        var enemies = new List<IPlayerCharacter>(32);
        foreach (var gameObject in services.Objects.PlayerObjects)
        {
            if (gameObject is not IPlayerCharacter player) continue;
            if (player.GameObjectId == local.GameObjectId || player.Address == nint.Zero) continue;
            if (!native.CanAttack(player)) continue;
            if (player.ClassJob.RowId is PaladinJobId or DarkKnightJobId) continue;
            enemies.Add(player);
        }

        // Preserve the old behavior: the current player target is inserted first, but
        // another matching target can still overwrite a manual target.
        if (services.Targets.Target is IPlayerCharacter current &&
            current.CurrentHp != 0 &&
            current.GameObjectId != local.GameObjectId && native.CanAttack(current) &&
            current.ClassJob.RowId is not PaladinJobId and not DarkKnightJobId)
        {
            enemies.Insert(0, current);
        }

        foreach (var enemy in enemies)
        {
            if (!MatchesLegacyRule(local, enemy)) continue;
            services.Targets.Target = enemy;
            break;
        }
    }

    private bool MatchesLegacyRule(IPlayerCharacter local, IPlayerCharacter enemy)
    {
        if (enemy.CurrentHp == 0 || enemy.MaxHp == 0) return false;

        // The requested legacy rule is raw HP strictly below 50%; shields are ignored.
        if ((ulong)enemy.CurrentHp * 2UL >= enemy.MaxHp) return false;
        if (enemy.StatusList.Any(status => status.StatusId == ProtectedStatusId)) return false;

        var dx = enemy.Position.X - local.Position.X;
        var dz = enemy.Position.Z - local.Position.Z;
        var legacyDistance = MathF.Sqrt(dx * dx + dz * dz) - 6f;
        return legacyDistance <= configuration.SelectDistance;
    }
}
