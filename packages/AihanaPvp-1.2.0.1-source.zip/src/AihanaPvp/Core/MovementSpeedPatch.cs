namespace OPP.Core;

internal interface ISpeedMemory
{
    bool Read(nint address, out float value);
    bool Write(nint address, float value);
}

// Two independent cells control physical movement and its animation. Retain the
// original values, verify each write, and roll back partial application.
internal sealed class MovementSpeedPatch(ISpeedMemory memory)
{
    private sealed record Cell(float Original, float? LastWritten);
    private readonly Dictionary<nint, Cell> cells = new();
    internal bool HasChanges => cells.Values.Any(cell => cell.LastWritten.HasValue);
    internal float? AppliedBaseSpeed { get; private set; }

    internal bool Apply(nint movement, nint animation, float multiplier, out string error)
    {
        error = string.Empty;
        AppliedBaseSpeed = null;
        if (movement == 0 || animation == 0 || movement == animation ||
            !float.IsFinite(multiplier) || multiplier < 0.1f || multiplier > 10f)
        {
            error = "移速地址或倍率无效";
            return false;
        }
        // Never write an old EXD row after the game's row allocation changes.
        foreach (var stale in cells.Keys.Where(address => address != movement && address != animation).ToArray())
            cells.Remove(stale);

        var addresses = new[] { movement, animation };
        var before = new Dictionary<nint, float>();
        var prior = new Dictionary<nint, Cell>();
        foreach (var address in addresses)
        {
            if (!memory.Read(address, out var value) || !ValidSpeed(value))
            {
                error = address == movement ? "移动速度数据尚未就绪或读取失败" : "移动动画数据尚未就绪或读取失败";
                return false;
            }
            before[address] = value;
            if (!cells.ContainsKey(address)) cells[address] = new(value, null);
            prior[address] = cells[address];
        }

        foreach (var address in addresses)
        {
            var cell = cells[address];
            var desired = cell.Original * multiplier;
            if (!float.IsFinite(desired) || desired <= 0 || desired > 1000)
            {
                error = "计算出的移速超出有效范围";
                Rollback(before, prior);
                return false;
            }
            if (Same(before[address], desired)) continue;
            // Track attempted writes as well: a failing native write may have
            // written its bytes before returning failure.
            cells[address] = cell with { LastWritten = desired };
            if (!memory.Write(address, desired) || !memory.Read(address, out var actual) || !Same(actual, desired))
            {
                error = address == movement ? "移动速度写入或回读失败" : "移动动画写入或回读失败";
                if (!Rollback(before, prior)) error += "；回退未完成，将继续尝试恢复";
                return false;
            }
        }
        AppliedBaseSpeed = cells[movement].Original * multiplier;
        return true;
    }

    internal bool Restore(out string error)
    {
        error = string.Empty;
        AppliedBaseSpeed = null;
        var complete = true;
        foreach (var pair in cells.ToArray())
        {
            if (pair.Value.LastWritten is not { } written) { cells.Remove(pair.Key); continue; }
            if (!memory.Read(pair.Key, out var current)) { complete = false; continue; }
            // A game update or another plugin already changed this cell. Do not
            // overwrite its value on reset/unload.
            if (!Same(current, written)) { cells.Remove(pair.Key); continue; }
            if (!memory.Write(pair.Key, pair.Value.Original) || !memory.Read(pair.Key, out var restored)
                || !Same(restored, pair.Value.Original)) { complete = false; continue; }
            cells.Remove(pair.Key);
        }
        if (!complete) error = "部分移速数据暂时无法恢复，等待数据就绪";
        return complete;
    }

    private bool Rollback(Dictionary<nint, float> before, Dictionary<nint, Cell> prior)
    {
        var complete = true;
        foreach (var pair in before)
        {
            var cell = cells[pair.Key];
            if (cell.LastWritten is not { } attempted) continue;
            if (!memory.Read(pair.Key, out var current)) { complete = false; continue; }
            if (!Same(current, attempted)) { cells[pair.Key] = prior[pair.Key]; continue; }
            if (!memory.Write(pair.Key, pair.Value) || !memory.Read(pair.Key, out var restored)
                || !Same(restored, pair.Value)) { complete = false; continue; }
            cells[pair.Key] = prior[pair.Key];
        }
        return complete;
    }

    private static bool ValidSpeed(float value) => float.IsFinite(value) && value > 0 && value <= 1000;
    private static bool Same(float a, float b) => float.IsFinite(a) && float.IsFinite(b) && MathF.Abs(a - b) <= 0.0001f;
}
