using System.Numerics;

namespace OPP.Core;

internal readonly record struct EventidePlayer(ulong Id, uint Job, bool IsPvP, bool Alive, Vector3 Position, float Rotation);
internal readonly record struct EventideTargets(ulong Hard, ulong Soft);

internal interface IEventideRuntime
{
    bool TryGetPlayer(out EventidePlayer player);
    bool IsReady(ulong playerId);
    IReadOnlyList<EventideEnemy> CaptureEnemies(Vector3 origin);
    EventideTargets CaptureTargets();
    void ClearTargets();
    void SetFacing(ulong playerId, float rotation);
    void RestoreTargets(EventideTargets targets);
    void ReportError(Exception exception);
}

internal sealed class EventideAimController(IEventideRuntime runtime)
{
    internal int? LastHitCount { get; private set; }

    // The only dispatcher is the original action request intercepted by the hook.
    // Nothing here schedules, retries, or generates a new action.
    internal bool Execute(uint type, uint id, ulong targetId, bool enabled, Func<ulong, bool, bool> dispatch)
    {
        PreparedAim? prepared = null;
        if (enabled && type == JobActionPolicy.ActionType && id == JobActionPolicy.Eventide)
            prepared = Prepare(type, id);

        bool used;
        try
        {
            used = dispatch(prepared?.Player.Id ?? targetId, prepared != null);
        }
        catch
        {
            if (prepared is { } failed) Restore(failed);
            throw; // Never retry an original call that might already have sent an action.
        }
        if (prepared is { } aim)
        {
            if (used) LastHitCount = aim.Plan.Hits;
            else Restore(aim);
        }
        return used;
    }

    private PreparedAim? Prepare(uint type, uint id)
    {
        PreparedAim? state = null;
        try
        {
            if (!runtime.TryGetPlayer(out var player)
                || !JobActionPolicy.EventideEnabled(true, player.IsPvP, player.Job, player.Alive, type, id)
                || !runtime.IsReady(player.Id)) return null;
            var plan = EventidePlanner.FindBest(runtime.CaptureEnemies(player.Position), player.Rotation);
            if (plan is not { } best) return null; // Still allow defensive, zero-hit use.

            state = new(player, runtime.CaptureTargets(), best);
            runtime.ClearTargets();
            runtime.SetFacing(player.Id, best.Rotation);
            return state;
        }
        catch (Exception exception)
        {
            if (state is { } partial) Restore(partial);
            runtime.ReportError(exception);
            return null;
        }
    }

    private void Restore(PreparedAim state)
    {
        try { runtime.SetFacing(state.Player.Id, state.Player.Rotation); }
        catch (Exception exception) { runtime.ReportError(exception); }
        try { runtime.RestoreTargets(state.Targets); }
        catch (Exception exception) { runtime.ReportError(exception); }
    }

    private readonly record struct PreparedAim(EventidePlayer Player, EventideTargets Targets, EventidePlan Plan);
}
