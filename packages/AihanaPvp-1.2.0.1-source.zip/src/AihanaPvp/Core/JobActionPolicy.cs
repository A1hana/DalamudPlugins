namespace OPP.Core;

internal static class JobActionPolicy
{
    internal const uint Ninja = 30;
    internal const uint DarkKnight = 32;
    internal const uint Eventide = 29097;
    internal const uint ActionType = 1;

    internal static bool NinjaEnabled(bool enabled, bool pvp, uint job, bool alive)
        => enabled && pvp && alive && job == Ninja;

    internal static bool EventideEnabled(bool enabled, bool pvp, uint job, bool alive, uint type, uint action)
        => enabled && pvp && alive && job == DarkKnight && type == ActionType && action == Eventide;
}
