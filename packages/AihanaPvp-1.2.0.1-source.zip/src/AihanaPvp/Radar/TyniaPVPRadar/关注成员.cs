#nullable disable warnings
using System;

namespace TyniaPVPRadar;

[Serializable]
public class 关注成员
{
	public ulong CID { get; set; }

	public string Name { get; set; } = string.Empty;

	public string ServerName { get; set; } = string.Empty;
}
