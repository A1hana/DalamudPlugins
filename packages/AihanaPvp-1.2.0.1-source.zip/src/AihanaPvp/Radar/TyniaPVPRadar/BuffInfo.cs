#nullable disable warnings
namespace TyniaPVPRadar;

public class BuffInfo
{
	public uint StatusId { get; set; }

	public uint IconId { get; set; }

	public string Name { get; set; } = string.Empty;

	public int StackCount { get; set; }

	public float RemainingTime { get; set; }
}
