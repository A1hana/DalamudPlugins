using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using OmenTools;
using OmenTools.Interop.Game.AddonEvent;
using TyniaPVPRadar.Services;

namespace TyniaPVPRadar;

// An owned module, not a second Dalamud plugin entry point.
public sealed class TyniaPVPRadar : IDisposable
{
    private readonly IDalamudPluginInterface pluginInterface;
    private readonly Action saveRootConfig;
    private readonly Action openSettings;
    private readonly Func<bool> isSettingsOpen;
    private readonly bool previousAutomaticUiHide;
    private readonly bool previousCutsceneUiHide;
    private bool disposed;
    private bool configDirty;
    private long lastConfigSaveTick;
    private long lastWindowStateTick;

    public PluginConfig Config { get; }
    public WindowSystem WindowSystem { get; } = new("AihanaPvpRadar");
    public MainWindow MainWindow { get; private set; } = null!;
    public AllPlayersWindow AllPlayersWindow { get; private set; } = null!;
    public MarkerPanel MarkerPanel { get; private set; } = null!;
    public TargetSelectWindow TargetSelectWindow { get; private set; } = null!;
    public SettingsWindow SettingsWindow { get; private set; } = null!;
    public LineListWindow LineListWindow { get; private set; } = null!;
    public WatchListWindow WatchListWindow { get; private set; } = null!;
    public PlayerManager PlayerManager { get; private set; } = null!;
    public OverlayRenderer OverlayRenderer { get; private set; } = null!;
    public MapOverlayRenderer MapOverlayRenderer { get; private set; } = null!;
    public MarkerService MarkerService { get; private set; } = null!;
    public UsedNameIntegration UsedNameIntegration { get; private set; } = null!;
    public TargetInfoModifier TargetInfoModifier { get; private set; } = null!;

    public TyniaPVPRadar(IDalamudPluginInterface pluginInterface, PluginConfig config,
        Action saveRootConfig, Action openSettings, Func<bool> isSettingsOpen)
    {
        this.pluginInterface = pluginInterface;
        this.saveRootConfig = saveRootConfig;
        this.openSettings = openSettings;
        this.isSettingsOpen = isSettingsOpen;
        Config = config;
        previousAutomaticUiHide = pluginInterface.UiBuilder.DisableAutomaticUiHide;
        previousCutsceneUiHide = pluginInterface.UiBuilder.DisableCutsceneUiHide;
        try
        {
            // Retain the local radar's fix: initialize no unrelated Omen native hooks.
            DService.Init(pluginInterface, () => new DServiceInitOptions().DisableAllServices());
            if (pluginInterface.Create<Service>() == null)
                throw new InvalidOperationException("雷达服务注入失败。");
            PlayerManager = new PlayerManager(this);
            MarkerService = new MarkerService(this);
            UsedNameIntegration = new UsedNameIntegration(pluginInterface);
            OverlayRenderer = new OverlayRenderer(this);
            MapOverlayRenderer = new MapOverlayRenderer(this);
            TargetInfoModifier = new TargetInfoModifier(this);
            MainWindow = new MainWindow(this);
            AllPlayersWindow = new AllPlayersWindow(this);
            MarkerPanel = new MarkerPanel(this);
            TargetSelectWindow = new TargetSelectWindow(this);
            SettingsWindow = new SettingsWindow(this);
            LineListWindow = new LineListWindow(this);
            WatchListWindow = new WatchListWindow(this);
            WindowSystem.AddWindow(MainWindow);
            WindowSystem.AddWindow(AllPlayersWindow);
            WindowSystem.AddWindow(MarkerPanel);
            WindowSystem.AddWindow(TargetSelectWindow);
            WindowSystem.AddWindow(LineListWindow);
            WindowSystem.AddWindow(WatchListWindow);

            if (Config.SaveWindowStates)
            {
                MainWindow.IsOpen = Config.MainWindowIsOpen;
                AllPlayersWindow.IsOpen = Config.AllPlayersWindowIsOpen;
                MarkerPanel.IsOpen = Config.MarkerPanelIsOpen;
                TargetSelectWindow.IsOpen = Config.TargetSelectWindowIsOpen;
                LineListWindow.IsOpen = Config.LineListWindowIsOpen;
                WatchListWindow.IsOpen = Config.WatchListWindowIsOpen;
            }
            Service.ClientState.TerritoryChanged += TerritoryChanged;
            Service.ClientState.Login += OnLogin;
            Service.ClientState.Logout += OnLogout;
            pluginInterface.UiBuilder.DisableAutomaticUiHide = true;
            pluginInterface.UiBuilder.DisableCutsceneUiHide = true;
            ApplyCurrentTerritoryWindowState();
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    public void OpenSettings() => openSettings();
    public void SaveConfig() => configDirty = true;

    public void Update()
    {
        if (disposed) return;
        PlayerManager.Update();
        var now = Environment.TickCount64;
        if (configDirty && now - lastConfigSaveTick >= 2000)
        {
            saveRootConfig();
            configDirty = false;
            lastConfigSaveTick = now;
        }
        if (Config.AutoConfirmYesNo && PlayerManager.IsInPvpZone)
            AddonSelectYesnoEvent.ClickYes("确定要回到");
    }

    public void Draw()
    {
        if (disposed) return;
        WindowSystem.Draw();
        OverlayRenderer.Draw();
        MapOverlayRenderer.Draw();
        if (Config.SaveWindowStates && Environment.TickCount64 - lastWindowStateTick > 500)
        {
            CaptureWindowStates();
            lastWindowStateTick = Environment.TickCount64;
        }
    }

    private void TerritoryChanged(uint territoryId)
    {
        var wasInPvp = PlayerManager.IsInPvpZone;
        PlayerManager.OnTerritoryChanged(territoryId);
        if (Config.Lines.RemoveAll(line => line.IsTemporary) > 0) SaveConfig();
        if (Config.AutoResetMarkerPanelOnTerritoryChange) MarkerPanel.ResetOnTerritoryChange();
        if (Config.AutoResetLineListOnTerritoryChange) LineListWindow.ResetOnTerritoryChange();
        if (PlayerManager.IsInPvpZone && !wasInPvp) OpenPvpWindows();
        if (!PlayerManager.IsInPvpZone && !Config.SaveWindowStates && !Config.EnableOnAllMaps)
            CloseManagedWindows();
    }

    private void OpenPvpWindows()
    {
        if (Config.AutoOpenMainWindowOnPvp) MainWindow.IsOpen = true;
        if (Config.AutoOpenAllPlayersWindowOnPvp) AllPlayersWindow.IsOpen = true;
        if (Config.AutoOpenMarkerPanelOnPvp) MarkerPanel.IsOpen = true;
    }

    private void ApplyCurrentTerritoryWindowState()
    {
        PlayerManager.OnTerritoryChanged(Service.ClientState.TerritoryType);
        if (Config.SaveWindowStates) return;
        if (PlayerManager.IsInPvpZone) OpenPvpWindows();
        else CloseManagedWindows();
    }

    private void OnLogin() => ApplyCurrentTerritoryWindowState();
    private void OnLogout(int type, int code) => CloseManagedWindows();

    private void CloseManagedWindows()
    {
        foreach (var window in WindowSystem.Windows) window.IsOpen = false;
    }

    private void CaptureWindowStates()
    {
        if (WatchListWindow == null) return;
        var changed = Config.MainWindowIsOpen != MainWindow.IsOpen
            || Config.AllPlayersWindowIsOpen != AllPlayersWindow.IsOpen
            || Config.MarkerPanelIsOpen != MarkerPanel.IsOpen
            || Config.TargetSelectWindowIsOpen != TargetSelectWindow.IsOpen
            || Config.LineListWindowIsOpen != LineListWindow.IsOpen
            || Config.WatchListWindowIsOpen != WatchListWindow.IsOpen
            || Config.SettingsWindowIsOpen != isSettingsOpen();
        Config.MainWindowIsOpen = MainWindow.IsOpen;
        Config.AllPlayersWindowIsOpen = AllPlayersWindow.IsOpen;
        Config.MarkerPanelIsOpen = MarkerPanel.IsOpen;
        Config.TargetSelectWindowIsOpen = TargetSelectWindow.IsOpen;
        Config.LineListWindowIsOpen = LineListWindow.IsOpen;
        Config.WatchListWindowIsOpen = WatchListWindow.IsOpen;
        Config.SettingsWindowIsOpen = isSettingsOpen();
        if (changed) SaveConfig();
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        // Save the open state before closing windows, including when unloading immediately.
        if (Config.SaveWindowStates) Cleanup(CaptureWindowStates, "记录窗口状态");
        if (Service.ClientState != null)
        {
            Service.ClientState.TerritoryChanged -= TerritoryChanged;
            Service.ClientState.Login -= OnLogin;
            Service.ClientState.Logout -= OnLogout;
        }
        Cleanup(() => TargetInfoModifier?.Dispose(), "释放目标信息事件");
        Cleanup(() => OverlayRenderer?.Dispose(), "释放 3D 雷达");
        Cleanup(() => MapOverlayRenderer?.Dispose(), "释放地图雷达");
        Cleanup(() => PlayerManager?.Dispose(), "释放玩家列表");
        Cleanup(saveRootConfig, "保存统一配置");
        CloseManagedWindows();
        WindowSystem.RemoveAllWindows();
        Cleanup(DService.Uninit, "释放 OmenTools");
        pluginInterface.UiBuilder.DisableAutomaticUiHide = previousAutomaticUiHide;
        pluginInterface.UiBuilder.DisableCutsceneUiHide = previousCutsceneUiHide;
    }

    private static void Cleanup(Action action, string operation)
    {
        try { action(); }
        catch (Exception exception) { Service.Log?.Error(exception, "[AihanaPvp] {Operation}失败", operation); }
    }
}
