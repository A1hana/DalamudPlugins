#nullable disable warnings
using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using OmenTools.Extensions;
using OmenTools.Info.Game.Data;

namespace TyniaPVPRadar;

public class MapOverlayRenderer : IDisposable
{
	private readonly TyniaPVPRadar _plugin;

	public MapOverlayRenderer(TyniaPVPRadar plugin)
	{
		_plugin = plugin;
	}

	public void Dispose()
	{
	}

	public unsafe void Draw()
	{
		if (!_plugin.PlayerManager.IsInPvpZone && !_plugin.Config.EnableOnAllMaps)
		{
			return;
		}
		AtkUnitBase* areaMap = Addons.AreaMap;
		if (areaMap == null)
		{
			return;
		}
		AddonAreaMap* ptr = (AddonAreaMap*)areaMap;
		if (ptr == null)
		{
			return;
		}
		Atk2DAreaMap* ptr2 = &ptr->AreaMap;
		if (ptr2 == null)
		{
			return;
		}
		AtkComponentNode* playerPin = ptr2->PlayerPin;
		if (playerPin == null)
		{
			return;
		}
		AtkResNode* ptr3 = &playerPin->AtkResNode;
		if (ptr3 == null)
		{
			return;
		}
		Vector2 vector = ptr3->GetPosition() + new Vector2((float)(int)ptr3->Width / 2f, (float)(int)ptr3->Height / 2f);
		float num = ptr2->MapScale * ptr2->SavedMarkerRadiusScale;
		IPlayerCharacter localPlayer = Service.ObjectTable.LocalPlayer;
		if (localPlayer == null || ((IGameObject)localPlayer).Address == (IntPtr)IntPtr.Zero)
		{
			return;
		}
		Vector3 position;
		ulong gameObjectId;
		try
		{
			position = ((IGameObject)localPlayer).Position;
			gameObjectId = ((IGameObject)localPlayer).GameObjectId;
		}
		catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
		{
			return;
		}
		AtkResNode* rootNode = ptr->AtkUnitBase.RootNode;
		Vector2 position2 = rootNode->GetPosition();
		Vector2 mapBoundsMin = position2 + new Vector2(10f, 30f);
		Vector2 mapBoundsMax = position2 + new Vector2((int)rootNode->Width, (int)rootNode->Height) - new Vector2(10f, 10f);
		if (_plugin.Config.ShowMapLines)
		{
			float mapLineThickness = _plugin.Config.MapLineThickness;
			float mapLineOpacity = _plugin.Config.MapLineOpacity;
			foreach (连线数据 line in _plugin.Config.Lines)
			{
				if (_plugin.PlayerManager.PlayersByCID.TryGetValue(line.TargetCID, out PlayerInfo value) && value != null && value.Object != null && ((IGameObject)value.Object).Address != (IntPtr)IntPtr.Zero && IsAlive((IGameObject)(object)value.Object))
				{
					Vector3 position3;
					try
					{
						position3 = ((IGameObject)value.Object).Position;
					}
					catch (Exception ex2) when (((ex2 is AccessViolationException || ex2 is NullReferenceException) ? 1 : 0) != 0)
					{
						continue;
					}
					float num2 = position3.X - position.X;
					float num3 = position3.Z - position.Z;
					float x = num2 * num;
					float y = num3 * num;
					Vector2 vector2 = vector + new Vector2(x, y);
					Vector4 vector3 = (value.IsHostile ? _plugin.Config.EnemyMapLineColor : _plugin.Config.MapLineColor);
					vector3.W = mapLineOpacity;
					Vector2 start = vector;
					Vector2 end = vector2;
					if (ClipLineToBounds(ref start, ref end, mapBoundsMin, mapBoundsMax))
					{
						ImDrawListPtr foregroundDrawList = ImGui.GetForegroundDrawList();
						foregroundDrawList.AddLine(start, end, ImGui.GetColorU32(vector3), mapLineThickness);
					}
				}
			}
		}
		if (_plugin.Config.ShowSelfMapDot && IsInBounds(vector))
		{
			if (_plugin.Config.MapUseArrowInsteadOfDot)
			{
				float rotation;
				try
				{
					rotation = ((IGameObject)localPlayer).Rotation;
				}
				catch (Exception ex3) when (((ex3 is AccessViolationException || ex3 is NullReferenceException) ? 1 : 0) != 0)
				{
					rotation = 0f;
				}
				Vector4 selfDotColor = _plugin.Config.SelfDotColor;
				selfDotColor.W = _plugin.Config.MapDotOpacity;
				DrawArrow(vector, _plugin.Config.MapDotSize, rotation, selfDotColor);
			}
			else
			{
				Vector4 selfDotColor2 = _plugin.Config.SelfDotColor;
				selfDotColor2.W = _plugin.Config.MapDotOpacity;
				DrawCircle(vector, _plugin.Config.MapDotSize, selfDotColor2);
			}
		}
		if (!_plugin.PlayerManager.IsInPvpZone)
		{
			_ = 1;
		}
		else
			_ = Service.ClientState.TerritoryType == 250;
		foreach (PlayerInfo allPlayer in _plugin.PlayerManager.AllPlayers)
		{
			if (allPlayer.Object == null || ((IGameObject)allPlayer.Object).Address == (IntPtr)IntPtr.Zero)
			{
				continue;
			}
			try
			{
				if (((IGameObject)allPlayer.Object).GameObjectId == gameObjectId)
				{
					continue;
				}
			}
			catch (Exception ex4) when (((ex4 is AccessViolationException || ex4 is NullReferenceException) ? 1 : 0) != 0)
			{
				continue;
			}
			if (!IsAlive((IGameObject)(object)allPlayer.Object))
			{
				continue;
			}
			Vector3 position4;
			try
			{
				position4 = ((IGameObject)allPlayer.Object).Position;
			}
			catch (Exception ex5) when (((ex5 is AccessViolationException || ex5 is NullReferenceException) ? 1 : 0) != 0)
			{
				continue;
			}
			float num4 = position4.X - position.X;
			float num5 = position4.Z - position.Z;
			float x2 = num4 * num;
			float y2 = num5 * num;
			Vector2 pos = vector + new Vector2(x2, y2);
			if (!IsInBounds(pos))
			{
				continue;
			}
			Vector4 color = ((!allPlayer.IsHostile && _plugin.Config.FriendlyDotsUseSelfColor) ? _plugin.Config.SelfDotColor : GetAllianceColor(allPlayer.阵营, _plugin));
			color.W = _plugin.Config.MapDotOpacity;
			if (allPlayer.IsHostile && _plugin.Config.ShowEnemyMapDots)
			{
				if (_plugin.Config.MapUseArrowInsteadOfDot)
				{
					float rotation2;
					try
					{
						rotation2 = ((IGameObject)allPlayer.Object).Rotation;
					}
					catch (Exception ex6) when (((ex6 is AccessViolationException || ex6 is NullReferenceException) ? 1 : 0) != 0)
					{
						rotation2 = 0f;
					}
					DrawArrow(pos, _plugin.Config.MapDotSize, rotation2, color);
				}
				else
				{
					DrawCircle(pos, _plugin.Config.MapDotSize, color);
				}
			}
			else
			{
				if (allPlayer.IsHostile || !_plugin.Config.ShowFriendlyMapDots)
				{
					continue;
				}
				if (_plugin.Config.MapUseArrowInsteadOfDot)
				{
					float rotation3;
					try
					{
						rotation3 = ((IGameObject)allPlayer.Object).Rotation;
					}
					catch (Exception ex7) when (((ex7 is AccessViolationException || ex7 is NullReferenceException) ? 1 : 0) != 0)
					{
						rotation3 = 0f;
					}
					DrawArrow(pos, _plugin.Config.MapDotSize, rotation3, color);
				}
				else
				{
					DrawCircle(pos, _plugin.Config.MapDotSize, color);
				}
			}
		}
		bool IsInBounds(Vector2 vector4)
		{
			if (vector4.X >= mapBoundsMin.X && vector4.X <= mapBoundsMax.X && vector4.Y >= mapBoundsMin.Y)
			{
				return vector4.Y <= mapBoundsMax.Y;
			}
			return false;
		}
	}

	private static Vector4 GetAllianceColor(阵营类型 alliance, TyniaPVPRadar plugin)
	{
		return alliance switch
		{
			阵营类型.黑涡团 => plugin.Config.MaelstromColor, 
			阵营类型.双蛇党 => plugin.Config.TwinAdderColor, 
			阵营类型.恒辉队 => plugin.Config.ImmortalFlamesColor, 
			_ => Vector4.One, 
		};
	}

	private static void DrawCircle(Vector2 pos, float radius, Vector4 color)
	{
		ImDrawListPtr foregroundDrawList = ImGui.GetForegroundDrawList();
		foregroundDrawList.AddCircleFilled(pos, radius, ImGui.GetColorU32(color));
	}

	private static void DrawArrow(Vector2 pos, float dotSize, float rotation, Vector4 color)
	{
		float num = dotSize * 2.5f;
		float num2 = dotSize * 1f;
		float num3 = dotSize * 1.2f;
		Vector2 vector = pos + new Vector2(MathF.Sin(rotation) * num, MathF.Cos(rotation) * num);
		Vector2 vector2 = pos - new Vector2(MathF.Sin(rotation) * num2, MathF.Cos(rotation) * num2);
		Vector2 vector3 = vector2 + new Vector2((0f - MathF.Cos(rotation)) * num3, MathF.Sin(rotation) * num3);
		Vector2 vector4 = vector2 + new Vector2(MathF.Cos(rotation) * num3, (0f - MathF.Sin(rotation)) * num3);
		ImDrawListPtr foregroundDrawList = ImGui.GetForegroundDrawList();
		foregroundDrawList.AddTriangleFilled(vector3, vector4, vector, ImGui.GetColorU32(color));
	}

	private static bool ClipLineToBounds(ref Vector2 start, ref Vector2 end, Vector2 boundsMin, Vector2 boundsMax)
	{
		float num = start.X;
		float num2 = start.Y;
		float num3 = end.X;
		float num4 = end.Y;
		float x = boundsMin.X;
		float y = boundsMin.Y;
		float x2 = boundsMax.X;
		float y2 = boundsMax.Y;
		int num5 = ComputeOutCode(num, num2, x, y, x2, y2);
		int num6 = ComputeOutCode(num3, num4, x, y, x2, y2);
		while (true)
		{
			if ((num5 | num6) == 0)
			{
				start = new Vector2(num, num2);
				end = new Vector2(num3, num4);
				return true;
			}
			if ((num5 & num6) != 0)
			{
				break;
			}
			float num7 = 0f;
			float num8 = 0f;
			int num9 = ((num5 != 0) ? num5 : num6);
			if ((num9 & 1) != 0)
			{
				num7 = x;
				num8 = num2 + (num4 - num2) * (x - num) / (num3 - num);
			}
			else if ((num9 & 2) != 0)
			{
				num7 = x2;
				num8 = num2 + (num4 - num2) * (x2 - num) / (num3 - num);
			}
			else if ((num9 & 4) != 0)
			{
				num8 = y;
				num7 = num + (num3 - num) * (y - num2) / (num4 - num2);
			}
			else if ((num9 & 8) != 0)
			{
				num8 = y2;
				num7 = num + (num3 - num) * (y2 - num2) / (num4 - num2);
			}
			if (num9 == num5)
			{
				num = num7;
				num2 = num8;
				num5 = ComputeOutCode(num, num2, x, y, x2, y2);
			}
			else
			{
				num3 = num7;
				num4 = num8;
				num6 = ComputeOutCode(num3, num4, x, y, x2, y2);
			}
		}
		return false;
	}

	private static int ComputeOutCode(float x, float y, float xMin, float yMin, float xMax, float yMax)
	{
		int num = 0;
		if (x < xMin)
		{
			num |= 1;
		}
		if (x > xMax)
		{
			num |= 2;
		}
		if (y < yMin)
		{
			num |= 4;
		}
		if (y > yMax)
		{
			num |= 8;
		}
		return num;
	}

	private static bool IsAlive(IGameObject obj)
	{
		if (obj.Address == (IntPtr)IntPtr.Zero)
		{
			return false;
		}
		try
		{
			if (obj.IsDead)
			{
				return false;
			}
			ICharacter val = (ICharacter)(object)((obj is ICharacter) ? obj : null);
			if (val != null && val.CurrentHp == 0)
			{
				return false;
			}
		}
		catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
		{
			return false;
		}
		return true;
	}
}
