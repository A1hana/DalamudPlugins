#nullable disable warnings
using System;

namespace TyniaPVPRadar;

[Serializable]
public class 标记配置
{
	public MarkerType 标记类型 { get; set; }

	public ulong? 玩家CID { get; set; }

	public string 玩家名称 { get; set; } = string.Empty;

	public string 服务器名称 { get; set; } = string.Empty;

	public bool 清除模式 { get; set; }
}
