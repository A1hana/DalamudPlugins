#nullable disable warnings
namespace TyniaPVPRadar;

public enum 战意等级
{
	战意5 = 5,
	战意4 = 4,
	战意3 = 3,
	战意2 = 2,
	战意1 = 1,
	无战意 = 0
}
