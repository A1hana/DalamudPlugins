#nullable disable warnings
using System;
using System.Collections.Generic;
using Dalamud.Game.Addon.Lifecycle;
using Dalamud.Game.Addon.Lifecycle.AddonArgTypes;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Memory;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Component.GUI;
using Lumina.Excel.Sheets;
using OmenTools;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;
using OmenTools.Interop.Game.Lumina;
using ICharacter = OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.ICharacter;
using IGameObject = Dalamud.Game.ClientState.Objects.Types.IGameObject;

namespace TyniaPVPRadar;

public class TargetInfoModifier : IDisposable
{
	private const int MinTargetInfoNodeCount = 13;

	private const int MainTargetNameNodeIndex = 8;

	private const int FocusTargetNameNodeIndex = 10;

	private const int MergedTargetNameNodeIndex = 39;

	private static readonly HashSet<uint> EnabledTerritoryIds = new HashSet<uint> { 431u, 554u, 729u, 791u, 888u, 1273u, 1313u };

	private static readonly Dictionary<uint, (string JobName, string JobNameFemale)> JobNameCache = new Dictionary<uint, (string, string)>();

	private readonly TyniaPVPRadar _plugin;

	public TargetInfoModifier(TyniaPVPRadar plugin)
	{
		_plugin = plugin;
		DService.Instance().AddonLifecycle.RegisterListener((AddonEvent)2, "_TargetInfo", OnTargetInfoPreUpdate);
		DService.Instance().AddonLifecycle.RegisterListener((AddonEvent)2, "_TargetInfoMainTarget", OnTargetInfoMainTargetPreUpdate);
		DService.Instance().AddonLifecycle.RegisterListener((AddonEvent)2, "_FocusTargetInfo", OnFocusTargetPreUpdate);
	}

	private unsafe void OnTargetInfoPreUpdate(AddonEvent type, AddonArgs args)
	{
		if (!_plugin.Config.ShowPlayerNameInTargetInfo || !IsEnabledTerritory())
		{
			return;
		}
		AtkUnitBase* address = (AtkUnitBase*)args.Addon.Address;
		if (address == null || !address->IsVisible)
		{
			return;
		}
		AtkUldManager uldManager = address->UldManager;
		if (uldManager.NodeListCount < 40)
		{
			return;
		}
		AtkResNode* ptr = uldManager.NodeList[39];
		if (ptr == null)
		{
			return;
		}
		AtkTextNode* asAtkTextNode = ptr->GetAsAtkTextNode();
		if (asAtkTextNode != null)
		{
			string text = MemoryHelper.ReadStringNullTerminated((IntPtr)(nint)asAtkTextNode->GetText().Value);
			if (!string.IsNullOrWhiteSpace(text))
			{
				TryAppendPlayerName(asAtkTextNode, text, Service.TargetManager.Target);
			}
		}
	}

	private unsafe void OnTargetInfoMainTargetPreUpdate(AddonEvent type, AddonArgs args)
	{
		if (_plugin.Config.ShowPlayerNameInTargetInfo && IsEnabledTerritory() && TryGetTargetNameNode(args, 8, out AtkTextNode* targetNameNode, out string displayedText))
		{
			TryAppendPlayerName(targetNameNode, displayedText, Service.TargetManager.Target);
		}
	}

	private unsafe void OnFocusTargetPreUpdate(AddonEvent type, AddonArgs args)
	{
		if (_plugin.Config.ShowPlayerNameInFocusTargetInfo && IsEnabledTerritory() && TryGetTargetNameNode(args, 10, out AtkTextNode* targetNameNode, out string displayedText))
		{
			TryAppendPlayerName(targetNameNode, displayedText, Service.TargetManager.FocusTarget);
		}
	}

	private unsafe static bool TryGetTargetNameNode(AddonArgs args, int nameNodeIndex, out AtkTextNode* targetNameNode, out string displayedText)
	{
		targetNameNode = null;
		displayedText = string.Empty;
		AtkUnitBase* address = (AtkUnitBase*)args.Addon.Address;
		if (address == null || !address->IsVisible)
		{
			return false;
		}
		AtkUldManager uldManager = address->UldManager;
		if (uldManager.NodeListCount < 13)
		{
			return false;
		}
		AtkResNode* ptr = uldManager.NodeList[nameNodeIndex];
		if (ptr == null)
		{
			return false;
		}
		targetNameNode = ptr->GetAsAtkTextNode();
		if (targetNameNode == null)
		{
			return false;
		}
		displayedText = MemoryHelper.ReadStringNullTerminated((IntPtr)(nint)targetNameNode->GetText().Value);
		if (string.IsNullOrWhiteSpace(displayedText))
		{
			return false;
		}
		return true;
	}

	private unsafe static void TryAppendPlayerName(AtkTextNode* targetNameNode, string displayedText, IGameObject? target)
	{
		if (target == null || (int)target.ObjectKind != 1)
		{
			return;
		}
		string textValue = target.Name.TextValue;
		if (!string.IsNullOrWhiteSpace(textValue) && !displayedText.EndsWith(" " + textValue, StringComparison.Ordinal))
		{
			uint classJobId = GetClassJobId(target);
			if (classJobId != 0 && TryExtractBracketedText(displayedText, out string result) && IsJobNameOrAbbreviation(classJobId, result))
			{
				targetNameNode->SetText(displayedText + " " + textValue);
			}
		}
	}

	private static uint GetClassJobId(IGameObject target)
	{
		try
		{
			if (DService.Instance().ObjectTable.SearchByID(target.GameObjectId) is ICharacter { ClassJob: var classJob } character && classJob.IsValid)
			{
				return character.ClassJob.RowId;
			}
		}
		catch
		{
		}
		return 0u;
	}

	private static bool TryExtractBracketedText(string text, out string result)
	{
		result = string.Empty;
		int num = text.IndexOf('[');
		int num2 = text.IndexOf(']');
		if (num < 0 || num2 < 0 || num2 <= num)
		{
			return false;
		}
		result = text.Substring(num + 1, num2 - num - 1);
		return true;
	}

	private static bool IsJobNameOrAbbreviation(uint classJobId, string bracketedText)
	{
		try
		{
			if (!JobNameCache.TryGetValue(classJobId, out (string, string) value))
			{
				if (!LuminaGetter.TryGetRow<ClassJob>(classJobId, out ClassJob item))
				{
					return false;
				}
				value = (((object)item.Name/*cast due to constrained. prefix*/).ToString(), ((object)item.NameFemale/*cast due to constrained. prefix*/).ToString());
				JobNameCache[classJobId] = value;
			}
			if (bracketedText.Equals(value.Item1, StringComparison.Ordinal) || bracketedText.Equals(value.Item2, StringComparison.Ordinal))
			{
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	private static bool IsEnabledTerritory()
	{
		return EnabledTerritoryIds.Contains(Service.ClientState.TerritoryType);
	}

	public void Dispose()
	{
		DService.Instance().AddonLifecycle.UnregisterListener(OnTargetInfoPreUpdate);
		DService.Instance().AddonLifecycle.UnregisterListener(OnTargetInfoMainTargetPreUpdate);
		DService.Instance().AddonLifecycle.UnregisterListener(OnFocusTargetPreUpdate);
		JobNameCache.Clear();
	}
}
