#nullable disable warnings
namespace TyniaPVPRadar;

public enum 阵营类型
{
	双蛇党 = 1,
	恒辉队 = 2,
	黑涡团 = 3,
	未知 = 0
}
