#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace TyniaPVPRadar;

public class WatchListWindow : Window
{
	private readonly TyniaPVPRadar _plugin;

	private string _newCollectionNameInput = string.Empty;

	private Vector4 _newCollectionColor = new Vector4(1f, 1f, 0f, 1f);

	private int _editingCollectionIndex = -1;

	private string _editNameInput = string.Empty;

	private Vector4 _editColor;

	private List<(Vector2 Pos, Vector4 Color, float Radius)> _pendingDotDraws = new List<(Vector2, Vector4, float)>();

	private bool _collectionStateDirty;

	public WatchListWindow(TyniaPVPRadar plugin)
		: base("关注列表")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Size = new Vector2(_plugin.Config.WatchListWindowWidth, _plugin.Config.WatchListWindowHeight);
		((Window)this).SizeCondition = (ImGuiCond)4;
	}

	public override void Draw()
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		float num = ImGui.CalcTextSize((ImU8String)("创建"), false, -1f).X + style.FramePadding.X * 2f;
		float frameHeight = ImGui.GetFrameHeight();
		float y = ImGui.GetContentRegionAvail().X - frameHeight - num - style.ItemSpacing.X * 2f;
		float frameHeight2 = ImGui.GetFrameHeight();
		float x = ImGui.CalcTextSize((ImU8String)("按住 Ctrl 删除玩家"), false, -1f).X;
		float num2 = frameHeight2 + style.ItemInnerSpacing.X + x;
		ImGui.Text((ImU8String)("创建新列表:"));
		ImGui.SameLine();
		ImGui.SetCursorPosX(ImGui.GetContentRegionMax().X - num2);
		bool requireCtrlToDeleteWatchMember = _plugin.Config.RequireCtrlToDeleteWatchMember;
		if (ImGui.Checkbox((ImU8String)("##RequireCtrlToDelete"), ref requireCtrlToDeleteWatchMember))
		{
			_plugin.Config.RequireCtrlToDeleteWatchMember = requireCtrlToDeleteWatchMember;
			_plugin.SaveConfig();
		}
		ImGui.SameLine();
		ImGui.Text((ImU8String)("按住 Ctrl 删除玩家"));
		ImGui.SetNextItemWidth(MathF.Max(80f, y));
		ImGui.InputText((ImU8String)("##NewCollectionName"), ref _newCollectionNameInput, 32, (ImGuiInputTextFlags)0, (ImGui.ImGuiInputTextCallbackDelegate?)null);
		ImGui.SameLine();
		ImGui.ColorEdit4((ImU8String)("##NewCollectionColor"), ref _newCollectionColor, (ImGuiColorEditFlags)32);
		ImGui.SameLine();
		if (ImGui.Button((ImU8String)("创建"), new Vector2(num, 0f)) && !string.IsNullOrWhiteSpace(_newCollectionNameInput))
		{
			string uniqueCollectionName = GetUniqueCollectionName(_newCollectionNameInput.Trim());
			_plugin.Config.WatchCollections.Add(new 关注列表
			{
				Name = uniqueCollectionName,
				BorderColorHex = ColorToHex(_newCollectionColor),
				IsOpen = true,
				Members = new List<关注成员>()
			});
			_newCollectionNameInput = string.Empty;
			_plugin.SaveConfig();
		}
		ImGui.Text((ImU8String)("关注框粗细:"));
		ImGui.SetNextItemWidth(ImGui.GetContentRegionAvail().X);
		float watchMemberBorderThickness = _plugin.Config.WatchMemberBorderThickness;
		if (ImGui.SliderFloat((ImU8String)("##WatchMemberBorderThickness"), ref watchMemberBorderThickness, 0.5f, 10f, (ImU8String)("%.1f"), (ImGuiSliderFlags)0))
		{
			_plugin.Config.WatchMemberBorderThickness = watchMemberBorderThickness;
		}
		if (ImGui.IsItemDeactivatedAfterEdit())
		{
			_plugin.SaveConfig();
		}
		Vector4 vector = new Vector4(0.5f, 0.5f, 0.5f, 1f);
		ImGui.TextColored(ref vector, (ImU8String)("右键点击列表标题，可编辑或删除列表。"));
		ImGui.Separator();
		if (_plugin.Config.WatchCollections.Count == 0)
		{
			ImGui.TextDisabled((ImU8String)("暂无关注列表"));
			DrawPendingDots();
			return;
		}
		List<关注列表> list = new List<关注列表>();
		List<(string, string, ulong)> list2 = new List<(string, string, ulong)>();
		bool flag = false;
		bool requireCtrlToDeleteWatchMember2 = _plugin.Config.RequireCtrlToDeleteWatchMember;
		ImU8String val2 = default(ImU8String);
		ImU8String val3 = default(ImU8String);
		ImU8String val5 = default(ImU8String);
		ImU8String val6 = default(ImU8String);
		ImU8String val7 = default(ImU8String);
		ImU8String val9 = default(ImU8String);
		for (int i = 0; i < _plugin.Config.WatchCollections.Count; i++)
		{
			关注列表 关注列表2 = _plugin.Config.WatchCollections[i];
			Vector4 vector2 = ParseHexColor(关注列表2.BorderColorHex);
			ImGui.PushID((IntPtr)i);
			string obj = $"   {关注列表2.Name}  ({关注列表2.Members.Count}人)";
			ImGuiTreeNodeFlags val = (ImGuiTreeNodeFlags)(关注列表2.IsOpen ? 32 : 0);
			bool flag2 = ImGui.CollapsingHeader((ImU8String)(obj), val);
			if (flag2 != 关注列表2.IsOpen)
			{
				关注列表2.IsOpen = flag2;
				_collectionStateDirty = true;
			}
			if (ImGui.IsItemVisible())
			{
				Vector2 itemRectMin = ImGui.GetItemRectMin();
				float num3 = ImGui.GetItemRectMax().Y - itemRectMin.Y;
				float fontSize = ImGui.GetFontSize();
				float y2 = itemRectMin.Y + num3 * 0.55f;
				float treeNodeToLabelSpacing = ImGui.GetTreeNodeToLabelSpacing();
				float x2 = itemRectMin.X + treeNodeToLabelSpacing * 1.25f;
				_pendingDotDraws.Add((new Vector2(x2, y2), vector2, fontSize * 0.35f));
			}
			if (ImGui.IsItemClicked((ImGuiMouseButton)1))
			{
				val2 = new ImU8String(18, 1);
				val2.AppendLiteral("CollectionContext_");
				val2.AppendFormatted<int>(i);
				ImGui.OpenPopup(val2, (ImGuiPopupFlags)0);
			}
			val3 = new ImU8String(18, 1);
			val3.AppendLiteral("CollectionContext_");
			val3.AppendFormatted<int>(i);
			if (ImGui.BeginPopup(val3, (ImGuiWindowFlags)0))
			{
				if (ImGui.MenuItem((ImU8String)("编辑列表"), false, true))
				{
					_editingCollectionIndex = i;
					_editNameInput = 关注列表2.Name;
					_editColor = vector2;
				}
				if (ImGui.MenuItem((ImU8String)("删除列表"), false, true))
				{
					if (_editingCollectionIndex == i)
					{
						_editingCollectionIndex = -1;
						_editNameInput = string.Empty;
					}
					list.Add(关注列表2);
				}
				ImGui.EndPopup();
			}
			if (_editingCollectionIndex == i)
			{
				bool num4 = i > 0;
				bool flag3 = i < _plugin.Config.WatchCollections.Count - 1;
				ImGuiStylePtr style2 = ImGui.GetStyle();
				float frameHeight3 = ImGui.GetFrameHeight();
				float num5 = ImGui.CalcTextSize((ImU8String)("确定"), false, -1f).X + style2.FramePadding.X * 2f;
				float num6 = ImGui.CalcTextSize((ImU8String)("取消"), false, -1f).X + style2.FramePadding.X * 2f;
				float frameHeight4 = ImGui.GetFrameHeight();
				float y3 = ImGui.GetContentRegionAvail().X - frameHeight3 - frameHeight3 - frameHeight4 - num5 - num6 - style2.ItemSpacing.X * 5f;
				ImGui.BeginDisabled(!num4);
				if (ImGui.ArrowButton((ImU8String)("##editMoveUp"), (ImGuiDir)2))
				{
					MoveCollection(i, i - 1);
				}
				ImGui.EndDisabled();
				ImGui.SameLine();
				ImGui.BeginDisabled(!flag3);
				if (ImGui.ArrowButton((ImU8String)("##editMoveDown"), (ImGuiDir)3))
				{
					MoveCollection(i, i + 1);
				}
				ImGui.EndDisabled();
				ImGui.SameLine();
				ImGui.SetNextItemWidth(MathF.Max(80f, y3));
				ImGui.InputText((ImU8String)("##editName"), ref _editNameInput, 32, (ImGuiInputTextFlags)0, (ImGui.ImGuiInputTextCallbackDelegate?)null);
				ImGui.SameLine();
				ImGui.ColorEdit4((ImU8String)("##editColor"), ref _editColor, (ImGuiColorEditFlags)32);
				ImGui.SameLine();
				if (ImGui.Button((ImU8String)("确定##editOk"), new Vector2(num5, 0f)))
				{
					ConfirmEdit(i);
				}
				ImGui.SameLine();
				if (ImGui.Button((ImU8String)("取消##editCancel"), new Vector2(num6, 0f)))
				{
					_editingCollectionIndex = -1;
					_editNameInput = string.Empty;
				}
			}
			if (flag2)
			{
				ImGui.Indent(20f);
				if (关注列表2.Members.Count == 0)
				{
					ImGui.TextDisabled((ImU8String)("  （空）"));
				}
				else
				{
					List<关注成员> list3 = new List<关注成员>();
					ImGuiListClipper val4 = default(ImGuiListClipper);
					val4.Begin(关注列表2.Members.Count);
					while (val4.Step())
					{
						for (int num7 = val4.DisplayStart; num7 < val4.DisplayEnd; num7++)
						{
							关注成员 关注成员2 = 关注列表2.Members[num7];
							string text = $"MoveMember_{关注列表2.Id}_{关注成员2.CID}";
							float x3 = ImGui.CalcTextSize((ImU8String)("移动"), false, -1f).X;
							ImGuiStylePtr style3 = ImGui.GetStyle();
							float num8 = x3 + style3.FramePadding.X * 2f;
							float x4 = ImGui.CalcTextSize((ImU8String)("删除"), false, -1f).X;
							style3 = ImGui.GetStyle();
							float num9 = x4 + style3.FramePadding.X * 2f;
							val5 = new ImU8String(2, 1);
							val5.AppendLiteral("  ");
							val5.AppendFormatted<string>(关注成员2.Name);
							ImGui.Text(val5);
							if (!string.IsNullOrEmpty(关注成员2.ServerName))
							{
								ImGui.SameLine();
								vector = new Vector4(0.7f, 0.7f, 0.7f, 1f);
								val6 = new ImU8String(2, 1);
								val6.AppendLiteral("- ");
								val6.AppendFormatted<string>(关注成员2.ServerName);
								ImGui.TextColored(ref vector, val6);
							}
							float num10 = ImGui.GetContentRegionMax().X - num8 - num9;
							style3 = ImGui.GetStyle();
							ImGui.SameLine(num10 - style3.ItemSpacing.X);
							val7 = new ImU8String(5, 2);
							val7.AppendLiteral("移动##");
							val7.AppendFormatted<string>(关注列表2.Id);
							val7.AppendLiteral("_");
							val7.AppendFormatted<ulong>(关注成员2.CID);
							if (ImGui.Button(val7, new Vector2(num8, 0f)))
							{
								ImGui.OpenPopup((ImU8String)(text), (ImGuiPopupFlags)0);
							}
							if (ImGui.BeginPopup((ImU8String)(text), (ImGuiWindowFlags)0))
							{
								bool flag4 = false;
								foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
								{
									if (!(watchCollection.Id == 关注列表2.Id))
									{
										flag4 = true;
										ImU8String val8 = new ImU8String(4, 1);
										val8.AppendLiteral("移动到 ");
										val8.AppendFormatted<string>(watchCollection.Name);
										if (ImGui.MenuItem(val8, false, true))
										{
											list2.Add((关注列表2.Id, watchCollection.Id, 关注成员2.CID));
										}
									}
								}
								if (!flag4)
								{
									ImGui.TextDisabled((ImU8String)("暂无其他合集"));
								}
								ImGui.EndPopup();
							}
							ImGui.SameLine();
							val9 = new ImU8String(5, 2);
							val9.AppendLiteral("删除##");
							val9.AppendFormatted<string>(关注列表2.Id);
							val9.AppendLiteral("_");
							val9.AppendFormatted<ulong>(关注成员2.CID);
							if (ImGui.Button(val9, new Vector2(num9, 0f)))
							{
								if (requireCtrlToDeleteWatchMember2)
								{
									ImGuiIOPtr iO = ImGui.GetIO();
									if (!iO.KeyCtrl)
									{
										goto IL_0a40;
									}
								}
								list3.Add(关注成员2);
							}
							goto IL_0a40;
							IL_0a40:
							if (requireCtrlToDeleteWatchMember2 && ImGui.IsItemHovered())
							{
								ImGui.SetTooltip((ImU8String)("按住 Ctrl 删除该玩家"));
							}
						}
					}
					val4.End();
					if (list3.Count > 0)
					{
						foreach (关注成员 item in list3)
						{
							关注列表2.Members.Remove(item);
						}
						flag = true;
					}
				}
				ImGui.Unindent(20f);
			}
			ImGui.PopID();
		}
		DrawPendingDots();
		bool flag5 = flag;
		if (list.Count > 0)
		{
			foreach (关注列表 item2 in list)
			{
				_plugin.Config.WatchCollections.Remove(item2);
			}
			flag5 = true;
		}
		if (list2.Count > 0)
		{
			foreach (var (sourceCollectionId, targetCollectionId, cid) in list2)
			{
				MoveMemberToCollection(sourceCollectionId, targetCollectionId, cid, saveConfig: false);
			}
			flag5 = true;
		}
		if (flag5)
		{
			_plugin.SaveConfig();
		}
	}

	public override void OnClose()
	{
		if (_collectionStateDirty)
		{
			_plugin.SaveConfig();
			_collectionStateDirty = false;
		}
		base.OnClose();
	}

	private void DrawPendingDots()
	{
		if (_pendingDotDraws.Count == 0)
		{
			return;
		}
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		foreach (var (vector, vector2, num) in _pendingDotDraws)
		{
			windowDrawList.AddCircleFilled(vector, num + 1f, 4278190080u);
			windowDrawList.AddCircleFilled(vector, num, ImGui.ColorConvertFloat4ToU32(vector2));
		}
		_pendingDotDraws.Clear();
	}

	private void ConfirmEdit(int index)
	{
		关注列表 关注列表2 = _plugin.Config.WatchCollections[index];
		if (!string.IsNullOrWhiteSpace(_editNameInput))
		{
			关注列表2.Name = GetUniqueCollectionName(_editNameInput.Trim(), index);
		}
		关注列表2.BorderColorHex = ColorToHex(_editColor);
		_editingCollectionIndex = -1;
		_editNameInput = string.Empty;
		_plugin.SaveConfig();
	}

	private void MoveCollection(int fromIndex, int toIndex)
	{
		if (fromIndex >= 0 && fromIndex < _plugin.Config.WatchCollections.Count && toIndex >= 0 && toIndex < _plugin.Config.WatchCollections.Count && fromIndex != toIndex)
		{
			关注列表 item = _plugin.Config.WatchCollections[fromIndex];
			_plugin.Config.WatchCollections.RemoveAt(fromIndex);
			_plugin.Config.WatchCollections.Insert(toIndex, item);
			_editingCollectionIndex = toIndex;
			_plugin.SaveConfig();
		}
	}

	private void MoveMemberToCollection(string sourceCollectionId, string targetCollectionId, ulong cid, bool saveConfig = true)
	{
		if (sourceCollectionId == targetCollectionId)
		{
			return;
		}
		关注列表 关注列表2 = _plugin.Config.WatchCollections.Find((关注列表 c) => c.Id == sourceCollectionId);
		关注列表 关注列表3 = _plugin.Config.WatchCollections.Find((关注列表 c) => c.Id == targetCollectionId);
		if (关注列表2 == null || 关注列表3 == null)
		{
			return;
		}
		关注成员 关注成员2 = 关注列表2.Members.Find((关注成员 m) => m.CID == cid);
		if (关注成员2 == null)
		{
			return;
		}
		关注成员 关注成员3 = 关注列表3.Members.Find((关注成员 m) => m.CID == cid);
		if (关注成员3 != null)
		{
			if (string.IsNullOrEmpty(关注成员3.ServerName) && !string.IsNullOrEmpty(关注成员2.ServerName))
			{
				关注成员3.ServerName = 关注成员2.ServerName;
			}
			关注列表2.Members.Remove(关注成员2);
			if (saveConfig)
			{
				_plugin.SaveConfig();
			}
		}
		else
		{
			关注列表2.Members.Remove(关注成员2);
			关注列表3.Members.Add(关注成员2);
			if (saveConfig)
			{
				_plugin.SaveConfig();
			}
		}
	}

	private string GetUniqueCollectionName(string desiredName, int skipIndex = -1)
	{
		bool flag = false;
		for (int i = 0; i < _plugin.Config.WatchCollections.Count; i++)
		{
			if (i != skipIndex && _plugin.Config.WatchCollections[i].Name == desiredName)
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return desiredName;
		}
		int num = 2;
		while (true)
		{
			bool flag2 = false;
			for (int j = 0; j < _plugin.Config.WatchCollections.Count; j++)
			{
				if (j != skipIndex && _plugin.Config.WatchCollections[j].Name == $"{desiredName}{num}")
				{
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				break;
			}
			num++;
		}
		return $"{desiredName}{num}";
	}

	private static string ColorToHex(Vector4 c)
	{
		return $"#{(int)(c.X * 255f):X2}{(int)(c.Y * 255f):X2}{(int)(c.Z * 255f):X2}";
	}

	private static Vector4 ParseHexColor(string hex)
	{
		try
		{
			if (hex.StartsWith("#"))
			{
				hex = hex.Substring(1);
			}
			if (hex.Length >= 6)
			{
				byte num = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
				byte b = byte.Parse(hex.Substring(2, 2), NumberStyles.HexNumber);
				return new Vector4(z: (float)(int)byte.Parse(hex.Substring(4, 2), NumberStyles.HexNumber) / 255f, x: (float)(int)num / 255f, y: (float)(int)b / 255f, w: 1f);
			}
		}
		catch
		{
		}
		return new Vector4(1f, 1f, 0f, 1f);
	}
}
