#nullable disable warnings
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Components;
using Dalamud.Interface.Windowing;

namespace TyniaPVPRadar;

public class SettingsWindow : Window
{
	private readonly TyniaPVPRadar _plugin;

	public SettingsWindow(TyniaPVPRadar plugin)
		: base("设置")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Size = new Vector2(_plugin.Config.SettingsWindowWidth, _plugin.Config.SettingsWindowHeight);
		((Window)this).SizeCondition = (ImGuiCond)4;
	}

	public override void Draw()
	{
		if (!ImGui.BeginTabBar((ImU8String)("SettingsTabs"), (ImGuiTabBarFlags)128))
		{
			return;
		}
		ImU8String val2 = default(ImU8String);
		if (ImGui.BeginTabItem((ImU8String)("主窗口"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("主窗口设置"));
			ImGui.Separator();
			float mainWindowButtonHeight = _plugin.Config.MainWindowButtonHeight;
			ImU8String val = (ImU8String)("主窗口按钮高度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val, ref mainWindowButtonHeight, 20f, 60f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.MainWindowButtonHeight = mainWindowButtonHeight;
				_plugin.SaveConfig();
			}
			bool showSettingsButtonInMainWindowTitleBar = _plugin.Config.ShowSettingsButtonInMainWindowTitleBar;
			if (ImGui.Checkbox((ImU8String)("显示设置按钮"), ref showSettingsButtonInMainWindowTitleBar))
			{
				_plugin.Config.ShowSettingsButtonInMainWindowTitleBar = showSettingsButtonInMainWindowTitleBar;
				_plugin.SaveConfig();
			}
			bool showLockButtonInMainWindowTitleBar = _plugin.Config.ShowLockButtonInMainWindowTitleBar;
			if (ImGui.Checkbox((ImU8String)("显示锁定按钮"), ref showLockButtonInMainWindowTitleBar))
			{
				_plugin.Config.ShowLockButtonInMainWindowTitleBar = showLockButtonInMainWindowTitleBar;
				_plugin.SaveConfig();
			}
			bool allowMainWindowMoveAndResize = _plugin.Config.AllowMainWindowMoveAndResize;
			if (ImGui.Checkbox((ImU8String)("允许主窗口移动和调整大小"), ref allowMainWindowMoveAndResize))
			{
				_plugin.Config.AllowMainWindowMoveAndResize = allowMainWindowMoveAndResize;
				_plugin.SaveConfig();
			}
			bool showWatchListInMain = _plugin.Config.ShowWatchListInMain;
			if (ImGui.Checkbox((ImU8String)("在主窗口中显示关注列表"), ref showWatchListInMain))
			{
				_plugin.Config.ShowWatchListInMain = showWatchListInMain;
				_plugin.SaveConfig();
			}
			bool showLineListInMain = _plugin.Config.ShowLineListInMain;
			if (ImGui.Checkbox((ImU8String)("在主窗口中显示连线列表"), ref showLineListInMain))
			{
				_plugin.Config.ShowLineListInMain = showLineListInMain;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			if (ImGui.Button((ImU8String)("打开关注列表"), new Vector2(GetAdaptiveButtonWidth("打开关注列表"), 0f)))
			{
				((Window)_plugin.WatchListWindow).IsOpen = !((Window)_plugin.WatchListWindow).IsOpen;
			}
			ImGui.Spacing();
			if (ImGui.Button((ImU8String)("打开连线列表"), new Vector2(GetAdaptiveButtonWidth("打开连线列表"), 0f)))
			{
				((Window)_plugin.LineListWindow).IsOpen = !((Window)_plugin.LineListWindow).IsOpen;
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((ImU8String)("3D世界雷达"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("圆点设置"));
			ImGui.Separator();
			float dotSize = _plugin.Config.DotSize;
			ImU8String val3 = (ImU8String)("圆点大小");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val3, ref dotSize, 1f, 30f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.DotSize = dotSize;
				_plugin.SaveConfig();
			}
			float dotOpacity = _plugin.Config.DotOpacity;
			ImU8String val4 = (ImU8String)("圆点透明度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val4, ref dotOpacity, 0.1f, 1f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.DotOpacity = dotOpacity;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			Vector4 maelstromColor = _plugin.Config.MaelstromColor;
			if (ImGui.ColorEdit4((ImU8String)("黑涡团颜色"), ref maelstromColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.MaelstromColor = maelstromColor;
				_plugin.SaveConfig();
			}
			Vector4 twinAdderColor = _plugin.Config.TwinAdderColor;
			if (ImGui.ColorEdit4((ImU8String)("双蛇党颜色"), ref twinAdderColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.TwinAdderColor = twinAdderColor;
				_plugin.SaveConfig();
			}
			Vector4 immortalFlamesColor = _plugin.Config.ImmortalFlamesColor;
			if (ImGui.ColorEdit4((ImU8String)("恒辉队颜色"), ref immortalFlamesColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.ImmortalFlamesColor = immortalFlamesColor;
				_plugin.SaveConfig();
			}
			Vector4 selfDotColor = _plugin.Config.SelfDotColor;
			if (ImGui.ColorEdit4((ImU8String)("自身圆点颜色"), ref selfDotColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.SelfDotColor = selfDotColor;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			bool friendlyDotsUseSelfColor = _plugin.Config.FriendlyDotsUseSelfColor;
			if (ImGui.Checkbox((ImU8String)("友方圆点使用自身圆点颜色（不启用时使用阵营颜色）"), ref friendlyDotsUseSelfColor))
			{
				_plugin.Config.FriendlyDotsUseSelfColor = friendlyDotsUseSelfColor;
				_plugin.SaveConfig();
			}
			bool showEnemyDots = _plugin.Config.ShowEnemyDots;
			if (ImGui.Checkbox((ImU8String)("显示敌对阵营圆点"), ref showEnemyDots))
			{
				_plugin.Config.ShowEnemyDots = showEnemyDots;
				_plugin.SaveConfig();
			}
			SameLineIfFits("显示友方圆点");
			bool showFriendlyDots = _plugin.Config.ShowFriendlyDots;
			if (ImGui.Checkbox((ImU8String)("显示友方圆点"), ref showFriendlyDots))
			{
				_plugin.Config.ShowFriendlyDots = showFriendlyDots;
				_plugin.SaveConfig();
			}
			SameLineIfFits("显示自身圆点");
			bool showSelfDot = _plugin.Config.ShowSelfDot;
			if (ImGui.Checkbox((ImU8String)("显示自身圆点"), ref showSelfDot))
			{
				_plugin.Config.ShowSelfDot = showSelfDot;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("3D世界连线设置"));
			ImGui.Separator();
			bool show3DLines = _plugin.Config.Show3DLines;
			if (ImGui.Checkbox((ImU8String)("显示3D世界连线"), ref show3DLines))
			{
				_plugin.Config.Show3DLines = show3DLines;
				_plugin.SaveConfig();
			}
			float lineThickness = _plugin.Config.LineThickness;
			ImU8String val5 = (ImU8String)("连线粗细");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val5, ref lineThickness, 0.1f, 20f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.LineThickness = lineThickness;
				_plugin.SaveConfig();
			}
			float lineOpacity = _plugin.Config.LineOpacity;
			ImU8String val6 = (ImU8String)("连线透明度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val6, ref lineOpacity, 0.1f, 1f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.LineOpacity = lineOpacity;
				_plugin.SaveConfig();
			}
			Vector4 lineColor = _plugin.Config.LineColor;
			if (ImGui.ColorEdit4((ImU8String)("友方连线颜色"), ref lineColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.LineColor = lineColor;
				_plugin.SaveConfig();
			}
			Vector4 enemyLineColor = _plugin.Config.EnemyLineColor;
			if (ImGui.ColorEdit4((ImU8String)("敌方连线颜色"), ref enemyLineColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.EnemyLineColor = enemyLineColor;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((ImU8String)("大地图雷达"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("大地图绘制设置"));
			ImGui.Separator();
			float mapDotSize = _plugin.Config.MapDotSize;
			ImU8String val7 = (ImU8String)("大地图圆点大小");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val7, ref mapDotSize, 1f, 20f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.MapDotSize = mapDotSize;
				_plugin.SaveConfig();
			}
			float mapDotOpacity = _plugin.Config.MapDotOpacity;
			ImU8String val8 = (ImU8String)("大地图圆点透明度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val8, ref mapDotOpacity, 0f, 1f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.MapDotOpacity = mapDotOpacity;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			bool showEnemyMapDots = _plugin.Config.ShowEnemyMapDots;
			if (ImGui.Checkbox((ImU8String)("大地图显示敌对阵营"), ref showEnemyMapDots))
			{
				_plugin.Config.ShowEnemyMapDots = showEnemyMapDots;
				_plugin.SaveConfig();
			}
			SameLineIfFits("大地图显示友方");
			bool showFriendlyMapDots = _plugin.Config.ShowFriendlyMapDots;
			if (ImGui.Checkbox((ImU8String)("大地图显示友方"), ref showFriendlyMapDots))
			{
				_plugin.Config.ShowFriendlyMapDots = showFriendlyMapDots;
				_plugin.SaveConfig();
			}
			SameLineIfFits("大地图显示自己");
			bool showSelfMapDot = _plugin.Config.ShowSelfMapDot;
			if (ImGui.Checkbox((ImU8String)("大地图显示自己"), ref showSelfMapDot))
			{
				_plugin.Config.ShowSelfMapDot = showSelfMapDot;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			bool mapUseArrowInsteadOfDot = _plugin.Config.MapUseArrowInsteadOfDot;
			if (ImGui.Checkbox((ImU8String)("大地图使用箭头代替圆点"), ref mapUseArrowInsteadOfDot))
			{
				_plugin.Config.MapUseArrowInsteadOfDot = mapUseArrowInsteadOfDot;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("大地图连线设置"));
			ImGui.Separator();
			bool showMapLines = _plugin.Config.ShowMapLines;
			if (ImGui.Checkbox((ImU8String)("显示大地图连线"), ref showMapLines))
			{
				_plugin.Config.ShowMapLines = showMapLines;
				_plugin.SaveConfig();
			}
			float mapLineThickness = _plugin.Config.MapLineThickness;
			ImU8String val9 = (ImU8String)("连线粗细");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val9, ref mapLineThickness, 0.1f, 20f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.MapLineThickness = mapLineThickness;
				_plugin.SaveConfig();
			}
			float mapLineOpacity = _plugin.Config.MapLineOpacity;
			ImU8String val10 = (ImU8String)("连线透明度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val10, ref mapLineOpacity, 0.1f, 1f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.MapLineOpacity = mapLineOpacity;
				_plugin.SaveConfig();
			}
			Vector4 mapLineColor = _plugin.Config.MapLineColor;
			if (ImGui.ColorEdit4((ImU8String)("友方连线颜色"), ref mapLineColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.MapLineColor = mapLineColor;
				_plugin.SaveConfig();
			}
			Vector4 enemyMapLineColor = _plugin.Config.EnemyMapLineColor;
			if (ImGui.ColorEdit4((ImU8String)("敌方连线颜色"), ref enemyMapLineColor, (ImGuiColorEditFlags)0))
			{
				_plugin.Config.EnemyMapLineColor = enemyMapLineColor;
				_plugin.SaveConfig();
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((ImU8String)("玩家窗口"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("所有玩家窗口设置"));
			ImGui.Separator();
			bool showPreviewButtonInAllPlayersWindowTitleBar = _plugin.Config.ShowPreviewButtonInAllPlayersWindowTitleBar;
			if (ImGui.Checkbox((ImU8String)("显示查看自适应和标记按钮"), ref showPreviewButtonInAllPlayersWindowTitleBar))
			{
				_plugin.Config.ShowPreviewButtonInAllPlayersWindowTitleBar = showPreviewButtonInAllPlayersWindowTitleBar;
				_plugin.SaveConfig();
			}
			bool showRefreshButtonInAllPlayersWindowTitleBar = _plugin.Config.ShowRefreshButtonInAllPlayersWindowTitleBar;
			if (ImGui.Checkbox((ImU8String)("显示刷新按钮"), ref showRefreshButtonInAllPlayersWindowTitleBar))
			{
				_plugin.Config.ShowRefreshButtonInAllPlayersWindowTitleBar = showRefreshButtonInAllPlayersWindowTitleBar;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("玩家窗口方格设置"));
			ImGui.Separator();
			float gridCellWidth = _plugin.Config.GridCellWidth;
			ImU8String val11 = (ImU8String)("方格宽度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val11, ref gridCellWidth, 50f, 300f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.GridCellWidth = gridCellWidth;
				_plugin.SaveConfig();
			}
			float gridCellHeight = _plugin.Config.GridCellHeight;
			ImU8String val12 = (ImU8String)("方格高度");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val12, ref gridCellHeight, 25f, 160f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.GridCellHeight = gridCellHeight;
				_plugin.SaveConfig();
			}
			int gridColumns = _plugin.Config.GridColumns;
			ImU8String val13 = (ImU8String)("列数");
			val2 = default(ImU8String);
			if (ImGui.SliderInt(val13, ref gridColumns, 4, 12, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.GridColumns = gridColumns;
				_plugin.SaveConfig();
			}
			bool enableLeftClickSelect = _plugin.Config.EnableLeftClickSelect;
			if (ImGui.Checkbox((ImU8String)("启用左键选中玩家"), ref enableLeftClickSelect))
			{
				_plugin.Config.EnableLeftClickSelect = enableLeftClickSelect;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("图标和文字设置"));
			ImGui.Separator();
			float iconScale = _plugin.Config.IconScale;
			ImU8String val14 = (ImU8String)("图标放大倍数");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val14, ref iconScale, 0.5f, 3f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.IconScale = iconScale;
				_plugin.SaveConfig();
			}
			float fontScale = _plugin.Config.FontScale;
			ImU8String val15 = (ImU8String)("字体放大倍数");
			val2 = default(ImU8String);
			if (ImGui.SliderFloat(val15, ref fontScale, 0.5f, 3f, val2, (ImGuiSliderFlags)0))
			{
				_plugin.Config.FontScale = fontScale;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			bool showJobIcon = _plugin.Config.ShowJobIcon;
			if (ImGui.Checkbox((ImU8String)("职业"), ref showJobIcon))
			{
				_plugin.Config.ShowJobIcon = showJobIcon;
				_plugin.SaveConfig();
			}
			SameLineIfFits("职能技能");
			bool showSkillIcon = _plugin.Config.ShowSkillIcon;
			ImGui.BeginDisabled(_plugin.Config.AutoMarkerSkillPriority);
			if (ImGui.Checkbox((ImU8String)("职能技能"), ref showSkillIcon))
			{
				if (_plugin.Config.AutoMarkerSkillPriority)
				{
					_plugin.SaveConfig();
					return;
				}
				_plugin.Config.ShowSkillIcon = showSkillIcon;
				if (showSkillIcon)
				{
					_plugin.Config.ShowMarkerIcon = false;
				}
				_plugin.SaveConfig();
			}
			SameLineIfFits("标记");
			bool showMarkerIcon = _plugin.Config.ShowMarkerIcon;
			if (ImGui.Checkbox((ImU8String)("标记"), ref showMarkerIcon))
			{
				if (_plugin.Config.AutoMarkerSkillPriority)
				{
					_plugin.SaveConfig();
					return;
				}
				_plugin.Config.ShowMarkerIcon = showMarkerIcon;
				if (showMarkerIcon)
				{
					_plugin.Config.ShowSkillIcon = false;
				}
				_plugin.SaveConfig();
			}
			ImGui.EndDisabled();
			SameLineIfFits("战意");
			bool showBattleLevelIcon = _plugin.Config.ShowBattleLevelIcon;
			if (ImGui.Checkbox((ImU8String)("战意"), ref showBattleLevelIcon))
			{
				_plugin.Config.ShowBattleLevelIcon = showBattleLevelIcon;
				_plugin.SaveConfig();
			}
			SameLineIfFits("自适应职能技能和标记");
			bool autoMarkerSkillPriority = _plugin.Config.AutoMarkerSkillPriority;
			if (ImGui.Checkbox((ImU8String)("自适应职能技能和标记"), ref autoMarkerSkillPriority))
			{
				if (autoMarkerSkillPriority && !_plugin.Config.AutoMarkerSkillPriority)
				{
					_plugin.Config.SavedSkillIconBeforeAuto = _plugin.Config.ShowSkillIcon;
					_plugin.Config.SavedMarkerIconBeforeAuto = _plugin.Config.ShowMarkerIcon;
					_plugin.Config.ShowSkillIcon = true;
					_plugin.Config.ShowMarkerIcon = true;
				}
				else if (!autoMarkerSkillPriority && _plugin.Config.AutoMarkerSkillPriority)
				{
					_plugin.Config.ShowSkillIcon = _plugin.Config.SavedSkillIconBeforeAuto;
					_plugin.Config.ShowMarkerIcon = _plugin.Config.SavedMarkerIconBeforeAuto;
				}
				_plugin.Config.AutoMarkerSkillPriority = autoMarkerSkillPriority;
				_plugin.SaveConfig();
			}
			ImGui.BeginDisabled(!_plugin.Config.Show3DLines && !_plugin.Config.ShowMapLines);
			ImGui.Spacing();
			bool showLinePrefixInAllPlayersWindow = _plugin.Config.ShowLinePrefixInAllPlayersWindow;
			if (ImGui.Checkbox((ImU8String)("启用连线提示显示"), ref showLinePrefixInAllPlayersWindow))
			{
				_plugin.Config.ShowLinePrefixInAllPlayersWindow = showLinePrefixInAllPlayersWindow;
				_plugin.SaveConfig();
			}
			bool flag = false;
			if (showLinePrefixInAllPlayersWindow)
			{
				ImGui.SameLine();
				flag = _plugin.Config.ShowLineBgHintInAllPlayersWindow;
				if (ImGui.Checkbox((ImU8String)("启用背景显示"), ref flag))
				{
					_plugin.Config.ShowLineBgHintInAllPlayersWindow = flag;
					_plugin.SaveConfig();
				}
			}
			if (showLinePrefixInAllPlayersWindow)
			{
				if (flag)
				{
					float lineBgHintAlpha = _plugin.Config.LineBgHintAlpha;
					ImU8String val16 = (ImU8String)("背景提示透明度");
					val2 = default(ImU8String);
					if (ImGui.SliderFloat(val16, ref lineBgHintAlpha, 0f, 1f, val2, (ImGuiSliderFlags)0))
					{
						_plugin.Config.LineBgHintAlpha = lineBgHintAlpha;
						_plugin.SaveConfig();
					}
				}
				else
				{
					float nextItemWidth = ImGui.GetFontSize() * 3f;
					ImGui.Text((ImU8String)("连线字符"));
					ImGui.SameLine();
					ImGui.SetNextItemWidth(nextItemWidth);
					string text = _plugin.Config.LinePermanentPrefixSymbol ?? string.Empty;
					if (ImGui.InputText((ImU8String)("##连线字符"), ref text, 24, (ImGuiInputTextFlags)0, (ImGui.ImGuiInputTextCallbackDelegate?)null))
					{
						string text2 = text ?? string.Empty;
						if (string.IsNullOrEmpty(text2))
						{
							text2 = "◆";
						}
						_plugin.Config.LinePermanentPrefixSymbol = text2;
						_plugin.SaveConfig();
					}
					if (!_plugin.Config.AutoResetLineListOnTerritoryChange)
					{
						ImGui.SameLine();
						ImGui.Text((ImU8String)("临时连线字符"));
						ImGui.SameLine();
						ImGui.SetNextItemWidth(nextItemWidth);
						string text3 = _plugin.Config.LineTempPrefixSymbol ?? string.Empty;
						if (ImGui.InputText((ImU8String)("##临时连线字符"), ref text3, 24, (ImGuiInputTextFlags)0, (ImGui.ImGuiInputTextCallbackDelegate?)null))
						{
							string text4 = text3 ?? string.Empty;
							if (string.IsNullOrEmpty(text4))
							{
								text4 = "◇";
							}
							_plugin.Config.LineTempPrefixSymbol = text4;
							_plugin.SaveConfig();
						}
					}
				}
			}
			ImGui.EndDisabled();
			ImGui.Spacing();
			ImGui.Text((ImU8String)("玩家自动清理设置"));
			ImGui.Separator();
			float playerAutoCleanupIntervalMinutes = _plugin.Config.PlayerAutoCleanupIntervalMinutes;
			if (ImGui.SliderFloat((ImU8String)("自动清理间隔（分钟）"), ref playerAutoCleanupIntervalMinutes, 0.5f, 10f, (ImU8String)("%.1f"), (ImGuiSliderFlags)0))
			{
				_plugin.Config.PlayerAutoCleanupIntervalMinutes = playerAutoCleanupIntervalMinutes;
				_plugin.SaveConfig();
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((ImU8String)("右键菜单"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("复制玩家名设置"));
			ImGui.Separator();
			bool showCopyNameMenuItem = _plugin.Config.ShowCopyNameMenuItem;
			if (ImGui.Checkbox((ImU8String)("显示复制玩家名按钮"), ref showCopyNameMenuItem))
			{
				_plugin.Config.ShowCopyNameMenuItem = showCopyNameMenuItem;
				_plugin.SaveConfig();
			}
			if (showCopyNameMenuItem)
			{
				ImGui.Indent();
				bool copyServerName = _plugin.Config.CopyServerName;
				if (ImGui.Checkbox((ImU8String)("包含服务器名"), ref copyServerName))
				{
					_plugin.Config.CopyServerName = copyServerName;
					_plugin.SaveConfig();
				}
				ImGui.Unindent();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("右键菜单显示顺序设置"));
			ImGui.Separator();
			List<int> list = new List<int>();
			for (int i = 0; i < _plugin.Config.ContextMenuItemsOrder.Count; i++)
			{
				string text5 = _plugin.Config.ContextMenuItemsOrder[i];
				if ((!(text5 == "NameHistory") && !(text5 == "ServerTransfer")) || _plugin.UsedNameIntegration.IsAvailable)
				{
					list.Add(i);
				}
			}
			for (int j = 0; j < list.Count; j++)
			{
				int num = list[j];
				string text6 = _plugin.Config.ContextMenuItemsOrder[num];
				val2 = new ImU8String(10, 1);
				val2.AppendLiteral("menu_item_");
				val2.AppendFormatted<int>(num);
				ImGui.PushID(val2);
				ImGuiStylePtr style;
				if (j > 0)
				{
					if (ImGuiComponents.IconButton((FontAwesomeIcon)61538))
					{
						int index = list[j - 1];
						string value = _plugin.Config.ContextMenuItemsOrder[num];
						_plugin.Config.ContextMenuItemsOrder[num] = _plugin.Config.ContextMenuItemsOrder[index];
						_plugin.Config.ContextMenuItemsOrder[index] = value;
						_plugin.SaveConfig();
					}
					ImGui.SameLine();
				}
				else
				{
					style = ImGui.GetStyle();
					ImGui.PushStyleVar((ImGuiStyleVar)0, style.Alpha * 0.5f);
					ImGuiComponents.IconButton((FontAwesomeIcon)61538);
					ImGui.PopStyleVar();
					ImGui.SameLine();
				}
				if (j < list.Count - 1)
				{
					if (ImGuiComponents.IconButton((FontAwesomeIcon)61539))
					{
						int index2 = list[j + 1];
						string value2 = _plugin.Config.ContextMenuItemsOrder[num];
						_plugin.Config.ContextMenuItemsOrder[num] = _plugin.Config.ContextMenuItemsOrder[index2];
						_plugin.Config.ContextMenuItemsOrder[index2] = value2;
						_plugin.SaveConfig();
					}
					ImGui.SameLine();
				}
				else
				{
					style = ImGui.GetStyle();
					ImGui.PushStyleVar((ImGuiStyleVar)0, style.Alpha * 0.5f);
					ImGuiComponents.IconButton((FontAwesomeIcon)61539);
					ImGui.PopStyleVar();
					ImGui.SameLine();
				}
				bool isVisible = GetIsVisible(text6);
				bool flag2 = text6 == "AddTempLine" && _plugin.Config.AutoResetLineListOnTerritoryChange;
				ImGui.BeginDisabled(flag2);
				if (ImGui.Checkbox((ImU8String)(GetDisplayName(text6)), ref isVisible))
				{
					if (flag2)
					{
						_plugin.SaveConfig();
					}
					else
					{
						SetIsVisible(text6, isVisible);
						_plugin.SaveConfig();
					}
				}
				ImGui.EndDisabled();
				ImGui.PopID();
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((ImU8String)("其他"), (ImGuiTabItemFlags)0))
		{
			ImGui.Text((ImU8String)("通用设置"));
			ImGui.Separator();
			bool showPlayerNameInTargetInfo = _plugin.Config.ShowPlayerNameInTargetInfo;
			if (ImGui.Checkbox((ImU8String)("在目标UI中显示玩家真实姓名"), ref showPlayerNameInTargetInfo))
			{
				_plugin.Config.ShowPlayerNameInTargetInfo = showPlayerNameInTargetInfo;
				_plugin.SaveConfig();
			}
			bool showPlayerNameInFocusTargetInfo = _plugin.Config.ShowPlayerNameInFocusTargetInfo;
			if (ImGui.Checkbox((ImU8String)("在焦点目标UI中显示玩家真实姓名"), ref showPlayerNameInFocusTargetInfo))
			{
				_plugin.Config.ShowPlayerNameInFocusTargetInfo = showPlayerNameInFocusTargetInfo;
				_plugin.SaveConfig();
			}
			bool enableOnAllMaps = _plugin.Config.EnableOnAllMaps;
			if (ImGui.Checkbox((ImU8String)("所有地图生效（不仅限于PVP地图）"), ref enableOnAllMaps))
			{
				_plugin.Config.EnableOnAllMaps = enableOnAllMaps;
				if (enableOnAllMaps)
				{
					_plugin.Config.SaveWindowStates = true;
				}
				else
				{
					_plugin.Config.SaveWindowStates = false;
				}
				_plugin.PlayerManager.RefreshForCurrentTerritory();
				_plugin.SaveConfig();
			}
			bool saveWindowStates = _plugin.Config.SaveWindowStates;
			if (ImGui.Checkbox((ImU8String)("保存窗口状态（切换地图时保持窗口打开/关闭状态）"), ref saveWindowStates))
			{
				_plugin.Config.SaveWindowStates = saveWindowStates;
				_plugin.SaveConfig();
			}
			bool autoResetMarkerPanelOnTerritoryChange = _plugin.Config.AutoResetMarkerPanelOnTerritoryChange;
			if (ImGui.Checkbox((ImU8String)("切换地图时自动重置标记面板"), ref autoResetMarkerPanelOnTerritoryChange))
			{
				_plugin.Config.AutoResetMarkerPanelOnTerritoryChange = autoResetMarkerPanelOnTerritoryChange;
				_plugin.SaveConfig();
			}
			bool autoResetLineListOnTerritoryChange = _plugin.Config.AutoResetLineListOnTerritoryChange;
			if (ImGui.Checkbox((ImU8String)("切换地图时自动重置连线列表"), ref autoResetLineListOnTerritoryChange))
			{
				_plugin.Config.AutoResetLineListOnTerritoryChange = autoResetLineListOnTerritoryChange;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("PVP地图自动打开窗口设置"));
			ImGui.Separator();
			bool autoOpenMainWindowOnPvp = _plugin.Config.AutoOpenMainWindowOnPvp;
			if (ImGui.Checkbox((ImU8String)("自动打开主窗口"), ref autoOpenMainWindowOnPvp))
			{
				_plugin.Config.AutoOpenMainWindowOnPvp = autoOpenMainWindowOnPvp;
				_plugin.SaveConfig();
			}
			bool autoOpenAllPlayersWindowOnPvp = _plugin.Config.AutoOpenAllPlayersWindowOnPvp;
			if (ImGui.Checkbox((ImU8String)("自动打开所有玩家窗口"), ref autoOpenAllPlayersWindowOnPvp))
			{
				_plugin.Config.AutoOpenAllPlayersWindowOnPvp = autoOpenAllPlayersWindowOnPvp;
				_plugin.SaveConfig();
			}
			bool autoOpenMarkerPanelOnPvp = _plugin.Config.AutoOpenMarkerPanelOnPvp;
			if (ImGui.Checkbox((ImU8String)("自动打开标记窗口"), ref autoOpenMarkerPanelOnPvp))
			{
				_plugin.Config.AutoOpenMarkerPanelOnPvp = autoOpenMarkerPanelOnPvp;
				_plugin.SaveConfig();
			}
			ImGui.Spacing();
			ImGui.Text((ImU8String)("自动确认设置"));
			ImGui.Separator();
			bool autoConfirmYesNo = _plugin.Config.AutoConfirmYesNo;
			if (ImGui.Checkbox((ImU8String)("返回时自动确定"), ref autoConfirmYesNo))
			{
				_plugin.Config.AutoConfirmYesNo = autoConfirmYesNo;
				_plugin.SaveConfig();
			}
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private void SameLineIfFits(string nextLabel)
	{
		float checkboxWidth = GetCheckboxWidth(nextLabel);
		if (ImGui.GetContentRegionAvail().X >= checkboxWidth)
		{
			ImGui.SameLine();
		}
	}

	private float GetCheckboxWidth(string label)
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		return ImGui.GetFrameHeight() + style.ItemInnerSpacing.X + ImGui.CalcTextSize((ImU8String)(label), false, -1f).X + style.FramePadding.X * 2f;
	}

	private float GetAdaptiveButtonWidth(string label)
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		return ImGui.CalcTextSize((ImU8String)(label), false, -1f).X + style.FramePadding.X * 2f;
	}

	private string GetDisplayName(string item)
	{
		return item switch
		{
			"Inspect" => "调查", 
			"AdventurerPlate" => "查看冒险者铭牌", 
			"NameHistory" => "改名查询", 
			"ServerTransfer" => "转服查询", 
			"AddLine" => "添加连线", 
			"AddTempLine" => "添加临时连线", 
			"AddWatch" => "添加关注", 
			_ => "未知项目", 
		};
	}

	private bool GetIsVisible(string item)
	{
		return item switch
		{
			"Inspect" => _plugin.Config.ShowInspectMenuItem, 
			"AdventurerPlate" => _plugin.Config.ShowAdventurerPlateMenuItem, 
			"NameHistory" => _plugin.Config.ShowNameHistoryMenuItem, 
			"ServerTransfer" => _plugin.Config.ShowServerTransferMenuItem, 
			"AddLine" => _plugin.Config.ShowAddLineMenuItem, 
			"AddTempLine" => _plugin.Config.ShowAddTempLineMenuItem, 
			"AddWatch" => _plugin.Config.ShowAddWatchMenuItem, 
			_ => false, 
		};
	}

	private void SetIsVisible(string item, bool value)
	{
		if (item == null)
		{
			return;
		}
		switch (item.Length)
		{
		case 7:
			switch (item[0])
			{
			case 'I':
				if (item == "Inspect")
				{
					_plugin.Config.ShowInspectMenuItem = value;
				}
				break;
			case 'A':
				if (item == "AddLine")
				{
					_plugin.Config.ShowAddLineMenuItem = value;
				}
				break;
			}
			break;
		case 11:
			switch (item[0])
			{
			case 'N':
				if (item == "NameHistory")
				{
					_plugin.Config.ShowNameHistoryMenuItem = value;
				}
				break;
			case 'A':
				if (item == "AddTempLine" && !_plugin.Config.AutoResetLineListOnTerritoryChange)
				{
					_plugin.Config.ShowAddTempLineMenuItem = value;
				}
				break;
			}
			break;
		case 15:
			if (item == "AdventurerPlate")
			{
				_plugin.Config.ShowAdventurerPlateMenuItem = value;
			}
			break;
		case 14:
			if (item == "ServerTransfer")
			{
				_plugin.Config.ShowServerTransferMenuItem = value;
			}
			break;
		case 8:
			if (item == "AddWatch")
			{
				_plugin.Config.ShowAddWatchMenuItem = value;
			}
			break;
		case 9:
		case 10:
		case 12:
		case 13:
			break;
		}
	}
}
