#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;

namespace TyniaPVPRadar;

public class TargetSelectWindow : Window
{
	private readonly TyniaPVPRadar _plugin;

	private MarkerType? _currentMarkerType;

	private Action<MarkerType, PlayerInfo?>? _onSelectCallback;

	private uint _lastListVersion;

	private List<KeyValuePair<阵营类型, List<PlayerInfo>>>? _cachedGroups;

	private readonly Dictionary<阵营类型, List<PlayerInfo>> _groupDict = new Dictionary<阵营类型, List<PlayerInfo>>();

	private readonly List<KeyValuePair<阵营类型, List<PlayerInfo>>> _groupList = new List<KeyValuePair<阵营类型, List<PlayerInfo>>>();

	private float _lastCellWidth;

	private bool _needsSizeReset = true;

	private uint _lastTerritoryId;

	private static readonly IReadOnlyDictionary<MarkerType, uint> MarkerIconIds = new Dictionary<MarkerType, uint>
	{
		[MarkerType.Attack1] = 61201u,
		[MarkerType.Attack2] = 61202u,
		[MarkerType.Attack3] = 61203u,
		[MarkerType.Attack4] = 61204u,
		[MarkerType.Attack5] = 61205u,
		[MarkerType.Attack6] = 61206u,
		[MarkerType.Attack7] = 61207u,
		[MarkerType.Attack8] = 61208u,
		[MarkerType.Bind1] = 61211u,
		[MarkerType.Bind2] = 61212u,
		[MarkerType.Bind3] = 61213u,
		[MarkerType.Ignore1] = 61221u,
		[MarkerType.Ignore2] = 61222u,
		[MarkerType.Square] = 61231u,
		[MarkerType.Circle] = 61232u,
		[MarkerType.Cross] = 61233u,
		[MarkerType.Triangle] = 61234u
	};

	public TargetSelectWindow(TyniaPVPRadar plugin)
		: base("选择目标")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Flags = (ImGuiWindowFlags)72;
	}

	public override void OnClose()
	{
		_needsSizeReset = true;
		base.OnClose();
	}

	public void Show(MarkerType markerType, Action<MarkerType, PlayerInfo?> onSelect)
	{
		_currentMarkerType = markerType;
		_onSelectCallback = onSelect;
		((Window)this).IsOpen = true;
	}

	public override void PreDraw()
	{
		uint playerListVersion = _plugin.PlayerManager.PlayerListVersion;
		bool flag = playerListVersion != _lastListVersion;
		if (flag)
		{
			_lastListVersion = playerListVersion;
			_cachedGroups = null;
		}
		uint territoryType = Service.ClientState.TerritoryType;
		if (territoryType != _lastTerritoryId)
		{
			_lastTerritoryId = territoryType;
			_needsSizeReset = true;
		}
		float scaledCellWidth = GetScaledCellWidth();
		if (_needsSizeReset)
		{
			_needsSizeReset = false;
			ImGui.SetNextWindowSize(new Vector2(240f, 105f), (ImGuiCond)1);
		}
		else if (_lastCellWidth != scaledCellWidth || flag)
		{
			_lastCellWidth = scaledCellWidth;
			List<KeyValuePair<阵营类型, List<PlayerInfo>>>? obj = _cachedGroups ?? (_cachedGroups = GroupPlayersByAlliance());
			ImGuiStylePtr style = ImGui.GetStyle();
			float x;
			if (obj.Count == 0)
			{
				x = MathF.Max(220f, scaledCellWidth * 2f) + 2f * style.WindowPadding.X;
			}
			else
			{
				int gridColumns = _plugin.Config.GridColumns;
				float num = (float)gridColumns * scaledCellWidth + (float)(gridColumns - 1) * style.ItemSpacing.X;
				if (num < 220f)
				{
					num = 220f;
				}
				x = num + 2f * style.WindowPadding.X;
			}
			ImGui.SetNextWindowSize(new Vector2(x, 0f), (ImGuiCond)1);
		}
		base.PreDraw();
	}

	public override void Draw()
	{
		if (!_currentMarkerType.HasValue || _onSelectCallback == null)
		{
			((Window)this).IsOpen = false;
			return;
		}
		uint playerListVersion = _plugin.PlayerManager.PlayerListVersion;
		if (playerListVersion != _lastListVersion)
		{
			_lastListVersion = playerListVersion;
			_cachedGroups = null;
		}
		List<KeyValuePair<阵营类型, List<PlayerInfo>>>? obj = _cachedGroups ?? (_cachedGroups = GroupPlayersByAlliance());
		if (obj.Count == 0)
		{
			if (_plugin.PlayerManager.IsInitialPvpScanPending)
			{
				DrawLoadingState();
			}
			else
			{
				DrawEmptyState();
			}
		}
		foreach (KeyValuePair<阵营类型, List<PlayerInfo>> item in obj)
		{
			DrawAllianceSection(item.Key, item.Value);
		}
		ImGui.Spacing();
		if (ImGui.Button((ImU8String)("取消"), new Vector2(-1f, 0f)))
		{
			_onSelectCallback?.Invoke(_currentMarkerType.Value, null);
			((Window)this).IsOpen = false;
		}
	}

	private float GetScaledCellWidth()
	{
		return _plugin.Config.GridCellWidth;
	}

	private float GetScaledCellHeight()
	{
		return _plugin.Config.GridCellHeight;
	}

	private float GetBannerHeight()
	{
		return GetScaledCellHeight() * 0.6f;
	}

	private List<KeyValuePair<阵营类型, List<PlayerInfo>>> GroupPlayersByAlliance()
	{
		foreach (KeyValuePair<阵营类型, List<PlayerInfo>> item in _groupDict)
		{
			item.Value.Clear();
		}
		_groupDict.Clear();
		_groupList.Clear();
		foreach (PlayerInfo allPlayer in _plugin.PlayerManager.AllPlayers)
		{
			if (!_groupDict.TryGetValue(allPlayer.阵营, out List<PlayerInfo> value))
			{
				value = new List<PlayerInfo>();
				_groupDict[allPlayer.阵营] = value;
			}
			value.Add(allPlayer);
		}
		阵营类型[] array = new 阵营类型[3]
		{
			阵营类型.黑涡团,
			阵营类型.双蛇党,
			阵营类型.恒辉队
		};
		foreach (阵营类型 key in array)
		{
			if (_groupDict.TryGetValue(key, out List<PlayerInfo> value2))
			{
				_groupList.Add(new KeyValuePair<阵营类型, List<PlayerInfo>>(key, value2));
			}
		}
		return _groupList;
	}

	private void DrawAllianceSection(阵营类型 alliance, List<PlayerInfo> players)
	{
		bool flag = !_plugin.PlayerManager.IsInPvpZone || Service.ClientState.TerritoryType == 250;
		Vector4 vector;
		ImGuiStylePtr style;
		if (!flag)
		{
			vector = new Vector4(GetAllianceBaseColor(alliance).X, GetAllianceBaseColor(alliance).Y, GetAllianceBaseColor(alliance).Z, 0.4f);
		}
		else
		{
			style = ImGui.GetStyle();
			vector = style.Colors[21];
		}
		Vector4 vector2 = vector;
		string text = (flag ? "附近玩家" : GetAllianceName(alliance));
		ImGui.PushStyleColor((ImGuiCol)21, vector2);
		ImGui.PushStyleColor((ImGuiCol)22, AdjustBrightness(vector2, 1.1f));
		ImGui.PushStyleColor((ImGuiCol)23, AdjustBrightness(vector2, 0.9f));
		ImGui.PushStyleColor((ImGuiCol)0, new Vector4(0f, 0f, 0f, 0f));
		float num = (float)_plugin.Config.GridColumns * GetScaledCellWidth();
		float num2 = _plugin.Config.GridColumns - 1;
		style = ImGui.GetStyle();
		float x = num + num2 * style.ItemSpacing.X;
		Vector2 vector3 = new Vector2(x, GetBannerHeight());
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		windowDrawList.AddRectFilled(cursorScreenPos, cursorScreenPos + vector3, ImGui.GetColorU32(new Vector4(10f / 51f, 10f / 51f, 10f / 51f, 1f)));
		ImGui.PushID((IntPtr)(nint)alliance);
		ImGui.Button((ImU8String)("##banner"), vector3);
		ImGui.PopID();
		ImU8String val = default(ImU8String);
		val = new ImU8String(3, 2);
		val.AppendFormatted<string>(text);
		val.AppendLiteral(" (");
		val.AppendFormatted<int>(players.Count);
		val.AppendLiteral(")");
		Vector2 vector4 = ImGui.CalcTextSize(val, false, -1f);
		Vector2 position = new Vector2(cursorScreenPos.X + (vector3.X - vector4.X) * 0.5f, cursorScreenPos.Y + (vector3.Y - vector4.Y) * 0.5f);
		DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), $"{text} ({players.Count})");
		ImGui.PopStyleColor(4);
		for (int i = 0; i < players.Count; i++)
		{
			bool placeOnSameLineAfter = (i + 1) % _plugin.Config.GridColumns != 0 && i < players.Count - 1;
			DrawPlayerCell(players[i], placeOnSameLineAfter, flag);
		}
	}

	private void DrawEmptyState()
	{
		ImGui.TextWrapped((ImU8String)((_plugin.PlayerManager.IsInPvpZone || _plugin.Config.EnableOnAllMaps) ? "当前没有可选择的目标。" : "当前不在PVP地图，没有可选择的目标。"));
		ImGui.Dummy(new Vector2(MathF.Max(220f, GetScaledCellWidth() * 2f), 12f));
	}

	private void DrawLoadingState()
	{
		ImGui.TextWrapped((ImU8String)("加载中..."));
		ImGui.Dummy(new Vector2(MathF.Max(220f, GetScaledCellWidth() * 2f), 12f));
	}

	private void DrawPlayerCell(PlayerInfo player, bool placeOnSameLineAfter, bool isNearbyMode)
	{
		Vector2 vector = new Vector2(GetScaledCellWidth(), GetScaledCellHeight());
		var (flag, text) = GetPlayerCollectionInfo(player.CID);
		ImGuiStylePtr style;
		Vector4 vector2;
		if (isNearbyMode)
		{
			style = ImGui.GetStyle();
			vector2 = style.Colors[21];
		}
		else
		{
			Vector4 allianceBaseColor = GetAllianceBaseColor(player.阵营);
			vector2 = new Vector4(allianceBaseColor.X, allianceBaseColor.Y, allianceBaseColor.Z, 0.4f);
		}
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		windowDrawList.AddRectFilled(cursorScreenPos, cursorScreenPos + vector, ImGui.GetColorU32(new Vector4(10f / 51f, 10f / 51f, 10f / 51f, 1f)));
		ImGui.PushStyleColor((ImGuiCol)21, vector2);
		ImGui.PushStyleColor((ImGuiCol)22, AdjustBrightness(vector2, 1.1f));
		ImGui.PushStyleColor((ImGuiCol)23, AdjustBrightness(vector2, 0.9f));
		style = ImGui.GetStyle();
		ImGui.PushStyleColor((ImGuiCol)0, style.Colors[0]);
		ImGui.PushID((IntPtr)(nint)player.CID);
		if (ImGui.Button((ImU8String)("##select"), vector))
		{
			_onSelectCallback?.Invoke(_currentMarkerType.Value, player);
			((Window)this).IsOpen = false;
		}
		ImGui.PopID();
		if (flag && !string.IsNullOrEmpty(text))
		{
			Vector2 itemRectMin = ImGui.GetItemRectMin();
			Vector2 itemRectMax = ImGui.GetItemRectMax();
			uint colorU = ImGui.GetColorU32(ParseColor(text));
			float watchMemberBorderThickness = _plugin.Config.WatchMemberBorderThickness;
			uint colorU2 = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 1f));
			float num = (watchMemberBorderThickness + 1f) * 0.5f;
			Vector2 vector3 = new Vector2(num, num);
			windowDrawList.AddRect(itemRectMin - vector3, itemRectMax + vector3, colorU2, 0f, (ImDrawFlags)0, 1f);
			windowDrawList.AddRect(itemRectMin, itemRectMax, colorU, 0f, (ImDrawFlags)0, watchMemberBorderThickness);
			windowDrawList.AddRect(itemRectMin + vector3, itemRectMax - vector3, colorU2, 0f, (ImDrawFlags)0, 1f);
		}
		ImDrawListPtr windowDrawList2 = ImGui.GetWindowDrawList();
		Vector2 itemRectMin2 = ImGui.GetItemRectMin();
		Vector2 itemRectSize = ImGui.GetItemRectSize();
		DrawPlayerName(player, itemRectMin2, itemRectSize);
		DrawPlayerIcon(player, windowDrawList2, itemRectMin2, itemRectSize);
		DrawBattleLevelIcon(player, windowDrawList2, itemRectMin2, itemRectSize);
		DrawMarkerIcon(player, windowDrawList2, itemRectMin2, itemRectSize);
		ImGui.PopStyleColor(4);
		if (placeOnSameLineAfter)
		{
			ImGui.SameLine();
		}
	}

	private Vector4 GetAllianceBaseColor(阵营类型 alliance)
	{
		return alliance switch
		{
			阵营类型.双蛇党 => _plugin.Config.TwinAdderColor, 
			阵营类型.恒辉队 => _plugin.Config.ImmortalFlamesColor, 
			阵营类型.黑涡团 => _plugin.Config.MaelstromColor, 
			_ => new Vector4(0.2f, 0.2f, 0.2f, 1f), 
		};
	}

	private Vector4 AdjustBrightness(Vector4 color, float factor)
	{
		return new Vector4(Math.Clamp(color.X * factor, 0f, 1f), Math.Clamp(color.Y * factor, 0f, 1f), Math.Clamp(color.Z * factor, 0f, 1f), color.W);
	}

	private string GetAllianceName(阵营类型 alliance)
	{
		return alliance switch
		{
			阵营类型.双蛇党 => "双蛇党", 
			阵营类型.恒辉队 => "恒辉队", 
			阵营类型.黑涡团 => "黑涡团", 
			_ => "未知", 
		};
	}

	private void DrawPlayerName(PlayerInfo player, Vector2 pos, Vector2 size)
	{
		float num = 4f;
		Vector2 position = new Vector2(pos.X + num + 2f, pos.Y + num - 2f);
		DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), player.Name);
	}

	private void DrawOutlinedText(Vector2 position, Vector4 textColor, string text)
	{
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		uint colorU = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 1f));
		uint colorU2 = ImGui.GetColorU32(textColor);
		float fontScale = _plugin.Config.FontScale;
		ImFontPtr font = ImGui.GetFont();
		float num = ImGui.GetFontSize() * _plugin.Config.FontScale;
		windowDrawList.AddText(font, num, position + new Vector2(0f - fontScale, 0f), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(fontScale, 0f), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(0f, 0f - fontScale), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(0f, fontScale), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position, colorU2, (ImU8String)(text), 0f);
	}

	private (bool isInCollection, string? colorHex) GetPlayerCollectionInfo(ulong cid)
	{
		foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
		{
			foreach (关注成员 member in watchCollection.Members)
			{
				if (member.CID == cid)
				{
					return (isInCollection: true, colorHex: watchCollection.BorderColorHex);
				}
			}
		}
		return (isInCollection: false, colorHex: null);
	}

	private Vector4 ParseColor(string? hexColor)
	{
		ImGuiStylePtr style;
		if (string.IsNullOrEmpty(hexColor))
		{
			style = ImGui.GetStyle();
			return style.Colors[0];
		}
		try
		{
			if (hexColor.StartsWith("#"))
			{
				hexColor = hexColor.Substring(1);
			}
			byte num = byte.Parse(hexColor.Substring(0, 2), NumberStyles.HexNumber);
			byte b = byte.Parse(hexColor.Substring(2, 2), NumberStyles.HexNumber);
			return new Vector4(z: (float)(int)byte.Parse(hexColor.Substring(4, 2), NumberStyles.HexNumber) / 255f, x: (float)(int)num / 255f, y: (float)(int)b / 255f, w: 1f);
		}
		catch
		{
			style = ImGui.GetStyle();
			return style.Colors[0];
		}
	}

	private void DrawPlayerIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 pos, Vector2 size)
	{
		if (!_plugin.Config.ShowJobIcon)
		{
			return;
		}
		float num = 4f;
		float num2 = 18f * _plugin.Config.IconScale;
		if (player.ClassJobId == 0)
		{
			return;
		}
		try
		{
			uint num3 = 62100 + player.ClassJobId;
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(num3);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(pos.X + num, pos.Y + size.Y - num2 - num);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num2), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch (Exception)
		{
		}
	}

	private void DrawBattleLevelIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 pos, Vector2 size)
	{
		if (!_plugin.Config.ShowBattleLevelIcon)
		{
			return;
		}
		float num = 4f;
		float num2 = 18f * _plugin.Config.IconScale;
		if (player.战意等级 == 战意等级.无战意)
		{
			return;
		}
		try
		{
			uint num3 = player.战意等级 switch
			{
				战意等级.战意1 => 61483u, 
				战意等级.战意2 => 61484u, 
				战意等级.战意3 => 61485u, 
				战意等级.战意4 => 61486u, 
				战意等级.战意5 => 61487u, 
				_ => 0u, 
			};
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(num3);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(pos.X + size.X - num2 - num, pos.Y + size.Y - num2 - num);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num2), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch (Exception)
		{
		}
	}

	private void DrawMarkerIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 pos, Vector2 size)
	{
		if (!player.CurrentMarker.HasValue)
		{
			return;
		}
		MarkerType value = player.CurrentMarker.Value;
		if (!MarkerIconIds.TryGetValue(value, out var value2))
		{
			return;
		}
		float num = 4f;
		float num2 = 18f * _plugin.Config.IconScale;
		try
		{
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(value2);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(pos.X + (size.X - num2) * 0.5f, pos.Y + size.Y - num2 - num);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num2), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch (Exception)
		{
		}
	}
}
