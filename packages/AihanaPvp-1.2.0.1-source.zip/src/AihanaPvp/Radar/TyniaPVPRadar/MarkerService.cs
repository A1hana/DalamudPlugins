#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game.UI;

namespace TyniaPVPRadar;

public class MarkerService(TyniaPVPRadar plugin)
{
	private const string ExecuteCommandComplexSignature = "E8 ?? ?? ?? ?? 80 7D ?? ?? 74 ?? 41 0F B6 45";

	private const uint SetObjectMarkerCommand = 301;

	private const int CooldownMs = 500;

	private const int ClearCooldownMs = 200;

	private readonly Dictionary<ulong, DateTime> _lastMarkTimes = new Dictionary<ulong, DateTime>();

	private readonly Dictionary<MarkerType, DateTime> _lastClearTimes = new Dictionary<MarkerType, DateTime>();

	private ExecuteCommandComplexDelegate? _executeCommandComplex;

	[return: MarshalAs(UnmanagedType.U1)]
	private delegate bool ExecuteCommandComplexDelegate(uint command, long target, uint param1, uint param2, uint param3, uint param4);

	private bool ExecuteSetObjectMarker(ulong objectId, uint markerIndex)
	{
		_executeCommandComplex ??= Marshal.GetDelegateForFunctionPointer<ExecuteCommandComplexDelegate>(
			Service.SigScanner.ScanText(ExecuteCommandComplexSignature));
		return _executeCommandComplex(SetObjectMarkerCommand, unchecked((long)objectId), markerIndex, 0, 0, 0);
	}

	public unsafe MarkerType? GetPlayerCurrentMarker(PlayerInfo player)
	{
		try
		{
			MarkingController* ptr = MarkingController.Instance();
			if (ptr == null)
			{
				return null;
			}
			IPlayerCharacter? obj = player.Object;
			ulong num = ((obj != null) ? ((IGameObject)obj).GameObjectId : 0);
			if (num == 0L)
			{
				return null;
			}
			for (int i = 0; i < 17; i++)
			{
				if (ptr->Markers[i].ObjectId == num)
				{
					return IndexToMarkerType(i);
				}
			}
		}
		catch (Exception ex)
		{
			Service.Log.Error("获取标记失败: " + ex.Message, Array.Empty<object>());
		}
		return null;
	}

	private MarkerType? IndexToMarkerType(int index)
	{
		return index switch
		{
			0 => MarkerType.Attack1, 
			1 => MarkerType.Attack2, 
			2 => MarkerType.Attack3, 
			3 => MarkerType.Attack4, 
			4 => MarkerType.Attack5, 
			5 => MarkerType.Bind1, 
			6 => MarkerType.Bind2, 
			7 => MarkerType.Bind3, 
			8 => MarkerType.Ignore1, 
			9 => MarkerType.Ignore2, 
			10 => MarkerType.Square, 
			11 => MarkerType.Circle, 
			12 => MarkerType.Cross, 
			13 => MarkerType.Triangle, 
			14 => MarkerType.Attack6, 
			15 => MarkerType.Attack7, 
			16 => MarkerType.Attack8, 
			_ => null, 
		};
	}

	public void MarkPlayer(PlayerInfo player, MarkerType type)
	{
		IPlayerCharacter? obj = player.Object;
		ulong num = ((obj != null) ? ((IGameObject)obj).GameObjectId : 0);
		if (num == 0L || (_lastMarkTimes.TryGetValue(num, out var value) && (DateTime.Now - value).TotalMilliseconds < 500.0))
		{
			return;
		}
		MarkerType? playerCurrentMarker = GetPlayerCurrentMarker(player);
		uint markerIndex;
		if (type == MarkerType.Clear)
		{
			if (!playerCurrentMarker.HasValue)
			{
				return;
			}
			markerIndex = GetMarkerIndex(playerCurrentMarker.Value);
		}
		else
		{
			if (playerCurrentMarker.HasValue && playerCurrentMarker.Value == type)
			{
				return;
			}
			markerIndex = GetMarkerIndex(type);
		}
		try
		{
			ExecuteSetObjectMarker(num, markerIndex);
			_lastMarkTimes[num] = DateTime.Now;
		}
		catch (Exception ex)
		{
			Service.Log.Error("MarkPlayer 调用失败: " + ex.Message, Array.Empty<object>());
		}
	}

	public unsafe void ClearMarkerType(MarkerType type)
	{
		try
		{
			if (_lastClearTimes.TryGetValue(type, out var value) && (DateTime.Now - value).TotalMilliseconds < 200.0)
			{
				return;
			}
			MarkingController* ptr = MarkingController.Instance();
			if (ptr == null)
			{
				return;
			}
			uint markerIndex = GetMarkerIndex(type);
			if (markerIndex < 17)
			{
				uint objectId = ptr->Markers[(int)markerIndex].ObjectId;
				if (objectId != 0)
				{
					ExecuteSetObjectMarker(objectId, markerIndex);
				}
				_lastClearTimes[type] = DateTime.Now;
			}
		}
		catch (Exception ex)
		{
			Service.Log.Error("ClearMarkerType 调用失败: " + ex.Message, Array.Empty<object>());
		}
	}

	public unsafe void ClearAllMarkersOnPlayer(PlayerInfo player)
	{
		try
		{
			IPlayerCharacter? obj = player.Object;
			ulong num = ((obj != null) ? ((IGameObject)obj).GameObjectId : 0);
			if (num == 0L || (_lastMarkTimes.TryGetValue(num, out var value) && (DateTime.Now - value).TotalMilliseconds < 500.0))
			{
				return;
			}
			MarkingController* ptr = MarkingController.Instance();
			if (ptr == null)
			{
				return;
			}
			bool flag = false;
			for (int i = 0; i < 17; i++)
			{
				if (ptr->Markers[i].ObjectId == num)
				{
					ExecuteSetObjectMarker(num, (uint)i);
					flag = true;
				}
			}
			if (flag)
			{
				_lastMarkTimes[num] = DateTime.Now;
			}
		}
		catch (Exception ex)
		{
			Service.Log.Error("ClearAllMarkersOnPlayer 调用失败: " + ex.Message, Array.Empty<object>());
		}
	}

	private static uint GetMarkerIndex(MarkerType type)
	{
		return type switch
		{
			MarkerType.Attack1 => 0u, 
			MarkerType.Attack2 => 1u, 
			MarkerType.Attack3 => 2u, 
			MarkerType.Attack4 => 3u, 
			MarkerType.Attack5 => 4u, 
			MarkerType.Attack6 => 14u, 
			MarkerType.Attack7 => 15u, 
			MarkerType.Attack8 => 16u, 
			MarkerType.Bind1 => 5u, 
			MarkerType.Bind2 => 6u, 
			MarkerType.Bind3 => 7u, 
			MarkerType.Ignore1 => 8u, 
			MarkerType.Ignore2 => 9u, 
			MarkerType.Square => 10u, 
			MarkerType.Circle => 11u, 
			MarkerType.Cross => 12u, 
			MarkerType.Triangle => 13u, 
			MarkerType.Clear => 18u, 
			_ => 18u, 
		};
	}
}
