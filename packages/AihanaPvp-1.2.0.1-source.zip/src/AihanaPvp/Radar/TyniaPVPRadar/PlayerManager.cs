#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Reflection;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.ClientState.Party;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using Lumina.Excel.Sheets;
using OmenTools;
using OmenTools.Dalamud.Services.Game.Abstractions;
using OmenTools.Dalamud.Services.Game.Object.Abstractions;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;
using OmenTools.Dalamud.Services.Game.Object.Enums;
using OmenTools.Interop.Game.Lumina;
using DalamudGameObject = Dalamud.Game.ClientState.Objects.Types.IGameObject;
using DalamudObjectTable = Dalamud.Plugin.Services.IObjectTable;
using DalamudPlayerCharacter = Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter;
using OmenCharacter = OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.ICharacter;
using OmenObjectTable = OmenTools.Dalamud.Services.Game.Object.Abstractions.IObjectTable;
using OmenPlayerCharacter = OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IPlayerCharacter;
using OmenBattleChara = OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IBattleChara;

namespace TyniaPVPRadar;

public class PlayerManager : IDisposable
{
	private const int FullScanIntervalMs = 500;

	private const int BuffScanIntervalMs = 1000;

	private readonly TyniaPVPRadar _plugin;

	private readonly DalamudObjectTable _objectTable;

	private readonly IClientState _clientState;

	private readonly IPartyList _partyList;

	private readonly IDataManager _dataManager;

	private readonly Dictionary<ulong, PlayerInfo> _persistentPlayers = new Dictionary<ulong, PlayerInfo>();

	private long _lastFullScanTick;

	private long _lastBuffScanTick;

	private uint _lastTerritoryId;

	private readonly Dictionary<MarkerType, ulong> _markerOwners = new Dictionary<MarkerType, ulong>();

	private readonly HashSet<ulong> _seenPlayersScratch = new HashSet<ulong>();

	private readonly Dictionary<ulong, PlayerInfo> _objectIdToPlayerScratch = new Dictionary<ulong, PlayerInfo>();

	private readonly HashSet<ulong> _activePlayerCidsScratch = new HashSet<ulong>();

	private readonly Dictionary<MarkerType, PlayerInfo> _currentAssignmentsScratch = new Dictionary<MarkerType, PlayerInfo>();

	private readonly HashSet<ulong> _currentMarkedActiveCidsScratch = new HashSet<ulong>();

	private readonly List<ulong> _cidsToRemoveScratch = new List<ulong>();

	private readonly List<PlayerInfo> _allPlayersScratch = new List<PlayerInfo>();

	private readonly List<PlayerInfo> _hostilePlayersScratch = new List<PlayerInfo>();

	private static PropertyInfo? _cachedContentIdProperty;

	private static PropertyInfo? _cachedAllianceProperty;

	private static PropertyInfo? _statusStackCountProp;

	private static PropertyInfo? _statusStacksProp;

	private static PropertyInfo? _statusRemainingTimeProp;

	private static PropertyInfo? _statusDurationProp;

	private static readonly Dictionary<uint, uint> _statusIconCache = new Dictionary<uint, uint>();

	private static readonly Dictionary<uint, string> _statusNameCache = new Dictionary<uint, string>();

	private static readonly Dictionary<uint, string> _classNameCache = new Dictionary<uint, string>();

	private static int _statusSheetInitState;

	private static object? _statusSheet;

	private static MethodInfo? _statusSheetGetRow;

	private static PropertyInfo? _statusRowIconProp;

	private static PropertyInfo? _statusRowNameProp;

	private static MethodInfo? _statusSeStringExtractText;

	private static readonly HashSet<uint> PvpTerritoryIds = new HashSet<uint>
	{
		431u, 554u, 729u, 791u, 888u, 1273u, 1313u, 250u, 1032u, 1033u,
		1034u, 1116u, 1138u, 1293u, 1357u, 1058u, 1059u, 1060u, 1117u, 1139u,
		1294u, 1358u
	};

	private 阵营类型 _cachedLocalAlliance;

	private long _lastLocalAllianceCheckTick;

	public List<PlayerInfo> AllPlayers { get; private set; } = new List<PlayerInfo>();

	public List<PlayerInfo> HostilePlayers { get; private set; } = new List<PlayerInfo>();

	public IReadOnlyDictionary<ulong, PlayerInfo> PlayersByCID => _persistentPlayers;

	public bool IsInPvpZone { get; private set; }

	public bool IsInitialPvpScanPending { get; private set; }

	public uint PlayerListVersion { get; private set; }

	private static void TryInitStatusSheet(IDataManager dm)
	{
		if (_statusSheetInitState != 0)
		{
			return;
		}
		try
		{
			Type type = Type.GetType("Lumina.Excel.GeneratedSheets.Status, Lumina");
			if (type == null)
			{
				_statusSheetInitState = 2;
				return;
			}
			MethodInfo method = ((object)dm).GetType().GetMethod("GetExcelSheet", Type.EmptyTypes);
			if (method == null || !method.IsGenericMethodDefinition)
			{
				_statusSheetInitState = 2;
				return;
			}
			_statusSheet = method.MakeGenericMethod(type).Invoke(dm, null);
			if (_statusSheet == null)
			{
				_statusSheetInitState = 2;
				return;
			}
			_statusSheetGetRow = _statusSheet.GetType().GetMethod("GetRow", new Type[1] { typeof(uint) });
			if (_statusSheetGetRow == null)
			{
				_statusSheetInitState = 2;
				return;
			}
			_statusRowIconProp = null;
			_statusRowNameProp = null;
			_statusSeStringExtractText = null;
			_statusSheetInitState = 1;
		}
		catch
		{
			_statusSheetInitState = 2;
		}
	}

	public PlayerManager(TyniaPVPRadar plugin)
	{
		_plugin = plugin;
		_objectTable = Service.ObjectTable;
		_clientState = Service.ClientState;
		_partyList = Service.PartyList;
		_dataManager = Service.DataManager;
		_lastTerritoryId = _clientState.TerritoryType;
		TryInitStatusSheet(_dataManager);
		OnTerritoryChanged(_lastTerritoryId);
	}

	public void OnTerritoryChanged(uint territoryId)
	{
		bool flag = territoryId != _lastTerritoryId;
		bool enableOnAllMaps = _plugin.Config.EnableOnAllMaps;
		if (territoryId == 0)
		{
			IsInPvpZone = false;
			IsInitialPvpScanPending = enableOnAllMaps;
			_lastTerritoryId = territoryId;
			ResetTrackedPlayers();
			return;
		}
		bool isInPvpZone = IsInPvpZone;
		IsInPvpZone = PvpTerritoryIds.Contains(territoryId);
		_lastTerritoryId = territoryId;
		bool flag2 = IsInPvpZone || enableOnAllMaps;
		IsInitialPvpScanPending = flag2 && (flag || _persistentPlayers.Count == 0);
		if (flag || !IsInPvpZone || (isInPvpZone && !IsInPvpZone))
		{
			ResetTrackedPlayers();
			_cachedLocalAlliance = 阵营类型.未知;
			_lastLocalAllianceCheckTick = 0L;
		}
		if (!IsInPvpZone && !enableOnAllMaps)
		{
			IsInitialPvpScanPending = false;
		}
	}

	public void RefreshForCurrentTerritory()
	{
		OnTerritoryChanged(_clientState.TerritoryType);
	}

	public void ForceRefreshPlayers()
	{
		uint territoryType = _clientState.TerritoryType;
		IsInPvpZone = PvpTerritoryIds.Contains(territoryType);
		_lastTerritoryId = territoryType;
		bool flag = IsInPvpZone || _plugin.Config.EnableOnAllMaps;
		ResetTrackedPlayers(clearOverlayCache: false);
		_cachedLocalAlliance = 阵营类型.未知;
		_lastLocalAllianceCheckTick = 0L;
		IsInitialPvpScanPending = flag;
		if (!flag || territoryType == 0)
		{
			IsInitialPvpScanPending = false;
			_plugin.OverlayRenderer?.ClearScreenPositionCache();
			return;
		}
		try
		{
			OmenObjectTable objectTable = DService.Instance().ObjectTable;
			bool num = FullScanPlayers(objectTable, shouldUpdateBuffs: true);
			_lastBuffScanTick = (_lastFullScanTick = Environment.TickCount64);
			if (num)
			{
				IsInitialPvpScanPending = false;
			}
		}
		catch
		{
			_plugin.OverlayRenderer?.ClearScreenPositionCache();
		}
	}

	public void Update()
	{
		if (!IsInPvpZone && !_plugin.Config.EnableOnAllMaps)
		{
			IsInitialPvpScanPending = false;
			if (AllPlayers.Count > 0)
			{
				AllPlayers.Clear();
				HostilePlayers.Clear();
				PlayerListVersion++;
			}
			return;
		}
		OmenObjectTable objectTable = DService.Instance().ObjectTable;
		try
		{
			UpdateRealtimePositions(objectTable);
		}
		catch
		{
			return;
		}
		long tickCount = Environment.TickCount64;
		if (tickCount - _lastFullScanTick < 500)
		{
			return;
		}
		try
		{
			bool flag = tickCount - _lastBuffScanTick >= 1000;
			bool flag2 = FullScanPlayers(objectTable, flag);
			_lastFullScanTick = tickCount;
			if ((IsInPvpZone || _plugin.Config.EnableOnAllMaps) && flag2)
			{
				IsInitialPvpScanPending = false;
			}
			if (flag)
			{
				_lastBuffScanTick = tickCount;
			}
		}
		catch
		{
		}
	}

	private void UpdateRealtimePositions(dynamic omenObjectTable)
	{
		ulong num = 0uL;
		try
		{
			OmenPlayerCharacter localPlayer = DService.Instance().ObjectTable.LocalPlayer;
			if (localPlayer != null)
			{
				num = GetPlayerCID((OmenCharacter)localPlayer);
			}
		}
		catch
		{
		}
		阵营类型 localAlliance = GetLocalAlliance();
		_seenPlayersScratch.Clear();
		bool flag = false;
		bool flag2 = false;
		foreach (object item in omenObjectTable)
		{
			if (!(item is OmenCharacter character))
			{
				continue;
			}
			ulong playerCID = GetPlayerCID(character);
			if (playerCID == 0L || !_persistentPlayers.TryGetValue(playerCID, out PlayerInfo value))
			{
				continue;
			}
			_seenPlayersScratch.Add(playerCID);
			DalamudPlayerCharacter val = null;
			DalamudPlayerCharacter val2 = value.Object;
			if (val2 != null && ((DalamudGameObject)val2).Address != (IntPtr)IntPtr.Zero)
			{
				try
				{
					if (((DalamudGameObject)val2).GameObjectId == character.GameObjectID)
					{
						val = val2;
					}
				}
				catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
				{
					val = null;
				}
			}
			if (val == null)
			{
				DalamudGameObject obj2 = _objectTable.SearchById(character.GameObjectID);
				val = (DalamudPlayerCharacter)(object)((obj2 is DalamudPlayerCharacter) ? obj2 : null);
			}
			value.Object = val;
			value.Position = character.Position;
			阵营类型 阵营类型2 = ResolveAlliance(character, val, value.阵营);
			if (value.阵营 != 阵营类型2)
			{
				value.阵营 = 阵营类型2;
				flag2 = true;
			}
			value.IsHostile = playerCID != num && IsHostile(value.阵营, localAlliance);
			uint rowId = character.ClassJob.RowId;
			if (value.ClassJobId != rowId)
			{
				value.ClassJobId = rowId;
				value.ClassJobName = GetClassName(rowId);
				flag = true;
			}
		}
		foreach (PlayerInfo value2 in _persistentPlayers.Values)
		{
			if (!_seenPlayersScratch.Contains(value2.CID))
			{
				value2.Object = null;
			}
		}
		if (flag || flag2)
		{
			RefreshPlayerLists();
		}
		else
		{
			RefreshHostilePlayers();
		}
	}

	private unsafe void RefreshPlayerMarkers()
	{
		MarkingController* ptr = MarkingController.Instance();
		if (ptr == null)
		{
			return;
		}
		_objectIdToPlayerScratch.Clear();
		_activePlayerCidsScratch.Clear();
		foreach (PlayerInfo value6 in _persistentPlayers.Values)
		{
			DalamudPlayerCharacter? obj = value6.Object;
			ulong num = ((obj != null) ? ((DalamudGameObject)obj).GameObjectId : 0);
			if (num != 0L)
			{
				_objectIdToPlayerScratch[num] = value6;
				_activePlayerCidsScratch.Add(value6.CID);
			}
		}
		_currentAssignmentsScratch.Clear();
		for (int i = 0; i < 17; i++)
		{
			MarkerType? markerType = MarkerIndexToType(i);
			if (markerType.HasValue)
			{
				ulong num2 = ptr->Markers[i].ObjectId;
				if (num2 != 0L && _objectIdToPlayerScratch.TryGetValue(num2, out PlayerInfo value))
				{
					_currentAssignmentsScratch[markerType.Value] = value;
				}
			}
		}
		_currentMarkedActiveCidsScratch.Clear();
		foreach (KeyValuePair<MarkerType, PlayerInfo> item in _currentAssignmentsScratch)
		{
			MarkerType key = item.Key;
			PlayerInfo value2 = item.Value;
			_currentMarkedActiveCidsScratch.Add(value2.CID);
			if (_markerOwners.TryGetValue(key, out var value3) && value3 != value2.CID && _persistentPlayers.TryGetValue(value3, out PlayerInfo value4))
			{
				value4.CurrentMarker = null;
			}
			if (value2.CurrentMarker.HasValue && value2.CurrentMarker.Value != key)
			{
				_markerOwners.Remove(value2.CurrentMarker.Value);
			}
			value2.CurrentMarker = key;
			_markerOwners[key] = value2.CID;
		}
		foreach (PlayerInfo value7 in _persistentPlayers.Values)
		{
			if (_activePlayerCidsScratch.Contains(value7.CID) && !_currentMarkedActiveCidsScratch.Contains(value7.CID) && value7.CurrentMarker.HasValue)
			{
				if (_markerOwners.TryGetValue(value7.CurrentMarker.Value, out var value5) && value5 == value7.CID)
				{
					_markerOwners.Remove(value7.CurrentMarker.Value);
				}
				value7.CurrentMarker = null;
			}
		}
	}

	private static MarkerType? MarkerIndexToType(int index)
	{
		return index switch
		{
			0 => MarkerType.Attack1, 
			1 => MarkerType.Attack2, 
			2 => MarkerType.Attack3, 
			3 => MarkerType.Attack4, 
			4 => MarkerType.Attack5, 
			5 => MarkerType.Bind1, 
			6 => MarkerType.Bind2, 
			7 => MarkerType.Bind3, 
			8 => MarkerType.Ignore1, 
			9 => MarkerType.Ignore2, 
			10 => MarkerType.Square, 
			11 => MarkerType.Circle, 
			12 => MarkerType.Cross, 
			13 => MarkerType.Triangle, 
			14 => MarkerType.Attack6, 
			15 => MarkerType.Attack7, 
			16 => MarkerType.Attack8, 
			_ => null, 
		};
	}

	private bool FullScanPlayers(dynamic omenObjectTable, bool shouldUpdateBuffs)
	{
		ulong num = 0uL;
		阵营类型 localAlliance = GetLocalAlliance();
		long tickCount = Environment.TickCount64;
		long num2 = (long)(Math.Clamp(_plugin.Config.PlayerAutoCleanupIntervalMinutes, 0.5f, 10f) * 60f * 1000f);
		try
		{
			OmenPlayerCharacter localPlayer = DService.Instance().ObjectTable.LocalPlayer;
			if (localPlayer != null)
			{
				num = GetPlayerCID((OmenCharacter)localPlayer);
			}
		}
		catch
		{
		}
		foreach (object item in omenObjectTable)
		{
			if (!(item is OmenCharacter character))
			{
				continue;
			}
			ulong playerCID = GetPlayerCID(character);
			string text = character.Name.ToString();
			if (playerCID == 0L || string.IsNullOrEmpty(text))
			{
				continue;
			}
			if (!_persistentPlayers.TryGetValue(playerCID, out PlayerInfo value))
			{
				value = new PlayerInfo
				{
					Name = text,
					CID = playerCID
				};
				_persistentPlayers[playerCID] = value;
			}
			DalamudPlayerCharacter val = null;
			DalamudPlayerCharacter val2 = value.Object;
			if (val2 != null && ((DalamudGameObject)val2).Address != (IntPtr)IntPtr.Zero)
			{
				try
				{
					if (((DalamudGameObject)val2).GameObjectId == character.GameObjectID)
					{
						val = val2;
					}
				}
				catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
				{
					val = null;
				}
			}
			if (val == null)
			{
				DalamudGameObject obj2 = _objectTable.SearchById(character.GameObjectID);
				val = (DalamudPlayerCharacter)(object)((obj2 is DalamudPlayerCharacter) ? obj2 : null);
			}
			value.Name = text;
			value.Object = val;
			value.Position = character.Position;
			value.ClassJobId = character.ClassJob.RowId;
			value.ClassJobName = GetClassName(value.ClassJobId);
			try
			{
				if (character.HomeWorld.IsValid)
				{
					World value2 = character.HomeWorld.Value;
					string text2 = ((object)value2.Name/*cast due to constrained. prefix*/).ToString();
					if (!string.IsNullOrEmpty(text2))
					{
						value.ServerName = text2;
						SyncTrackedPlayerServerName(playerCID, text2);
					}
				}
			}
			catch
			{
			}
			value.阵营 = ResolveAlliance(character, val, value.阵营);
			value.IsHostile = playerCID != num && IsHostile(value.阵营, localAlliance);
			value.LastSeenTick = tickCount;
			if (shouldUpdateBuffs)
			{
				value.战意等级 = GetBattleLevelAndBuffs(character, value.Buffs);
			}
		}
		try
		{
			RefreshPlayerMarkers();
		}
		catch
		{
		}
		_cidsToRemoveScratch.Clear();
		foreach (KeyValuePair<ulong, PlayerInfo> persistentPlayer in _persistentPlayers)
		{
			if (tickCount - persistentPlayer.Value.LastSeenTick > num2)
			{
				_cidsToRemoveScratch.Add(persistentPlayer.Key);
			}
		}
		foreach (ulong item2 in _cidsToRemoveScratch)
		{
			_persistentPlayers.Remove(item2);
		}
		RefreshPlayerLists();
		if (num == 0L)
		{
			return _persistentPlayers.Count > 0;
		}
		return true;
	}

	public ulong GetPlayerCID(DalamudPlayerCharacter player)
	{
		try
		{
			PropertyInfo propertyInfo = _cachedContentIdProperty;
			if (propertyInfo == null)
			{
				propertyInfo = (_cachedContentIdProperty = ((object)player).GetType().GetProperty("ContentId"));
				if (propertyInfo == null)
				{
					return 0uL;
				}
			}
			object value = propertyInfo.GetValue(player);
			if (value is ulong result)
			{
				return result;
			}
			if (value is uint num)
			{
				return num;
			}
		}
		catch
		{
		}
		return 0uL;
	}

	public ulong GetPlayerCID(OmenCharacter player)
	{
		return player.ContentID;
	}

	private 阵营类型 GetPartyAlliance(OmenCharacter player)
	{
		try
		{
			switch (player.Battalion)
			{
			case BattalionFlags.TwinAdder:
				return 阵营类型.双蛇党;
			case BattalionFlags.FriendOrMaelstrom:
				return 阵营类型.黑涡团;
			case BattalionFlags.ImmortalFlames:
				return 阵营类型.恒辉队;
			}
		}
		catch
		{
		}
		return 阵营类型.未知;
	}

	private 阵营类型 ResolveAlliance(OmenCharacter omenPlayer, DalamudPlayerCharacter? playerObject, 阵营类型 fallbackAlliance)
	{
		if (playerObject != null)
		{
			阵营类型 partyAlliance = GetPartyAlliance(playerObject);
			if (partyAlliance != 阵营类型.未知)
			{
				return partyAlliance;
			}
		}
		阵营类型 partyAlliance2 = GetPartyAlliance(omenPlayer);
		if (partyAlliance2 != 阵营类型.未知)
		{
			return partyAlliance2;
		}
		return fallbackAlliance;
	}

	private 阵营类型 GetPartyAlliance(DalamudPlayerCharacter player)
	{
		try
		{
			PropertyInfo propertyInfo = _cachedAllianceProperty;
			if (propertyInfo == null)
			{
				propertyInfo = (_cachedAllianceProperty = ((object)player).GetType().GetProperty("Alliance"));
				if (propertyInfo == null)
				{
					return 阵营类型.未知;
				}
			}
			object value = propertyInfo.GetValue(player);
			if (value is byte)
			{
				switch ((byte)value)
				{
				case 0:
					return 阵营类型.黑涡团;
				case 1:
					return 阵营类型.双蛇党;
				case 2:
					return 阵营类型.恒辉队;
				}
			}
		}
		catch
		{
		}
		return 阵营类型.未知;
	}

	private int GetClassJobSortOrder(uint classJobId)
	{
		return classJobId switch
		{
			1u => 0, 
			19u => 1, 
			3u => 2, 
			21u => 3, 
			32u => 4, 
			37u => 5, 
			24u => 6, 
			28u => 7, 
			33u => 8, 
			40u => 9, 
			2u => 10, 
			20u => 11, 
			4u => 12, 
			22u => 13, 
			29u => 14, 
			30u => 15, 
			34u => 16, 
			39u => 17, 
			41u => 18, 
			5u => 19, 
			23u => 20, 
			31u => 21, 
			38u => 22, 
			7u => 23, 
			25u => 24, 
			26u => 25, 
			27u => 26, 
			35u => 27, 
			42u => 28, 
			36u => 29, 
			43u => 30, 
			_ => (int)(1000 + classJobId), 
		};
	}

	private string GetClassName(uint classJobId)
	{
		if (_classNameCache.TryGetValue(classJobId, out string value))
		{
			return value;
		}
		try
		{
			string jobName = LuminaWrapper.GetJobName(classJobId);
			if (!string.IsNullOrEmpty(jobName))
			{
				_classNameCache[classJobId] = jobName;
				return jobName;
			}
		}
		catch
		{
		}
		_classNameCache[classJobId] = "未知";
		return "未知";
	}

	private 战意等级 GetBattleLevelAndBuffs(OmenCharacter player, List<BuffInfo> destination)
	{
		战意等级 战意等级2 = 战意等级.无战意;
		int num = 0;
		try
		{
			if (player is OmenBattleChara battleChara)
			{
				foreach (IStatus status in battleChara.StatusList)
				{
					if (战意等级2 == 战意等级.无战意)
					{
						switch (status.StatusID)
						{
						case 2135u:
							战意等级2 = 战意等级.战意5;
							break;
						case 2134u:
							战意等级2 = 战意等级.战意4;
							break;
						case 2133u:
							战意等级2 = 战意等级.战意3;
							break;
						case 2132u:
							战意等级2 = 战意等级.战意2;
							break;
						case 2131u:
							战意等级2 = 战意等级.战意1;
							break;
						}
					}
					BuffInfo buffInfo;
					if (num < destination.Count)
					{
						buffInfo = destination[num];
					}
					else
					{
						buffInfo = new BuffInfo();
						destination.Add(buffInfo);
					}
					num++;
					buffInfo.StatusId = status.StatusID;
					buffInfo.StackCount = status.Param;
					buffInfo.RemainingTime = status.RemainingTime;
					try
					{
						if (status.GameData.IsValid)
						{
							BuffInfo buffInfo2 = buffInfo;
							Status value = status.GameData.Value;
							buffInfo2.IconId = value.Icon;
						}
						else
						{
							buffInfo.IconId = GetStatusIconId(status.StatusID);
						}
					}
					catch
					{
						buffInfo.IconId = GetStatusIconId(status.StatusID);
					}
					buffInfo.Name = GetStatusName(status.StatusID);
				}
			}
		}
		catch
		{
		}
		if (num < destination.Count)
		{
			destination.RemoveRange(num, destination.Count - num);
		}
		return 战意等级2;
	}

	private int GetStatusStackCount(object status)
	{
		try
		{
			PropertyInfo propertyInfo = _statusStackCountProp;
			if (propertyInfo == null)
			{
				propertyInfo = (_statusStackCountProp = status.GetType().GetProperty("StackCount"));
			}
			if (propertyInfo != null && propertyInfo.GetValue(status) is int result)
			{
				return result;
			}
			PropertyInfo propertyInfo2 = _statusStacksProp;
			if (propertyInfo2 == null)
			{
				propertyInfo2 = (_statusStacksProp = status.GetType().GetProperty("Stacks"));
			}
			if (propertyInfo2 != null && propertyInfo2.GetValue(status) is int result2)
			{
				return result2;
			}
		}
		catch
		{
		}
		return 0;
	}

	private float GetStatusRemainingTime(object status)
	{
		try
		{
			PropertyInfo propertyInfo = _statusRemainingTimeProp;
			if (propertyInfo == null)
			{
				propertyInfo = (_statusRemainingTimeProp = status.GetType().GetProperty("RemainingTime"));
			}
			if (propertyInfo != null && propertyInfo.GetValue(status) is float result)
			{
				return result;
			}
			PropertyInfo propertyInfo2 = _statusDurationProp;
			if (propertyInfo2 == null)
			{
				propertyInfo2 = (_statusDurationProp = status.GetType().GetProperty("Duration"));
			}
			if (propertyInfo2 != null && propertyInfo2.GetValue(status) is float result2)
			{
				return result2;
			}
		}
		catch
		{
		}
		return 0f;
	}

	private uint GetStatusIconId(uint statusId)
	{
		if (_statusIconCache.TryGetValue(statusId, out var value))
		{
			return value;
		}
		uint num = 0u;
		try
		{
			if (_statusSheetInitState == 1 && _statusSheet != null && _statusSheetGetRow != null)
			{
				object obj = _statusSheetGetRow.Invoke(_statusSheet, new object[1] { statusId });
				if (obj != null)
				{
					if (_statusRowIconProp == null)
					{
						_statusRowIconProp = obj.GetType().GetProperty("Icon");
					}
					if (_statusRowIconProp != null && _statusRowIconProp.GetValue(obj) is uint num2)
					{
						num = num2;
					}
				}
			}
			else if (_statusSheetInitState == 2)
			{
				Type type = Type.GetType("Lumina.Excel.GeneratedSheets.Status, Lumina");
				if (type != null)
				{
					MethodInfo method = ((object)_dataManager).GetType().GetMethod("GetExcelSheet", Type.EmptyTypes);
					if (method != null && method.IsGenericMethodDefinition)
					{
						object obj2 = method.MakeGenericMethod(type).Invoke(_dataManager, null);
						if (obj2 != null)
						{
							MethodInfo method2 = obj2.GetType().GetMethod("GetRow", new Type[1] { typeof(uint) });
							if (method2 != null)
							{
								object obj3 = method2.Invoke(obj2, new object[1] { statusId });
								if (obj3 != null)
								{
									PropertyInfo property = obj3.GetType().GetProperty("Icon");
									if (property != null && property.GetValue(obj3) is uint num3)
									{
										num = num3;
									}
								}
							}
						}
					}
				}
			}
		}
		catch
		{
		}
		_statusIconCache[statusId] = num;
		return num;
	}

	private string GetStatusName(uint statusId)
	{
		if (_statusNameCache.TryGetValue(statusId, out string value))
		{
			return value;
		}
		string text = string.Empty;
		try
		{
			if (_statusSheetInitState == 1 && _statusSheet != null && _statusSheetGetRow != null)
			{
				object obj = _statusSheetGetRow.Invoke(_statusSheet, new object[1] { statusId });
				if (obj != null)
				{
					if (_statusRowNameProp == null)
					{
						_statusRowNameProp = obj.GetType().GetProperty("Name");
					}
					if (_statusRowNameProp != null)
					{
						object value2 = _statusRowNameProp.GetValue(obj);
						if (value2 != null)
						{
							if (_statusSeStringExtractText == null)
							{
								_statusSeStringExtractText = value2.GetType().GetMethod("ExtractText");
							}
							text = ((!(_statusSeStringExtractText != null)) ? (value2.ToString() ?? string.Empty) : ((!(_statusSeStringExtractText.Invoke(value2, null) is string text2)) ? string.Empty : text2));
						}
					}
				}
			}
			else if (_statusSheetInitState == 2)
			{
				Type type = Type.GetType("Lumina.Excel.GeneratedSheets.Status, Lumina");
				if (type != null)
				{
					MethodInfo method = ((object)_dataManager).GetType().GetMethod("GetExcelSheet", Type.EmptyTypes);
					if (method != null && method.IsGenericMethodDefinition)
					{
						object obj2 = method.MakeGenericMethod(type).Invoke(_dataManager, null);
						if (obj2 != null)
						{
							MethodInfo method2 = obj2.GetType().GetMethod("GetRow", new Type[1] { typeof(uint) });
							if (method2 != null)
							{
								object obj3 = method2.Invoke(obj2, new object[1] { statusId });
								if (obj3 != null)
								{
									PropertyInfo property = obj3.GetType().GetProperty("Name");
									if (property != null)
									{
										object value3 = property.GetValue(obj3);
										if (value3 != null)
										{
											MethodInfo method3 = value3.GetType().GetMethod("ExtractText");
											text = ((!(method3 != null)) ? (value3.ToString() ?? string.Empty) : ((!(method3.Invoke(value3, null) is string text3)) ? string.Empty : text3));
										}
									}
								}
							}
						}
					}
				}
			}
		}
		catch
		{
		}
		_statusNameCache[statusId] = text;
		return text;
	}

	private static bool IsHostile(阵营类型 alliance, 阵营类型 localAlliance)
	{
		if (alliance == 阵营类型.未知)
		{
			return true;
		}
		if (localAlliance == 阵营类型.未知)
		{
			return true;
		}
		return alliance != localAlliance;
	}

	private void RefreshPlayerLists()
	{
		_allPlayersScratch.Clear();
		foreach (PlayerInfo value in _persistentPlayers.Values)
		{
			_allPlayersScratch.Add(value);
		}
		_allPlayersScratch.Sort(delegate(PlayerInfo p1, PlayerInfo p2)
		{
			int num = GetClassJobSortOrder(p1.ClassJobId).CompareTo(GetClassJobSortOrder(p2.ClassJobId));
			return (num != 0) ? num : p1.CID.CompareTo(p2.CID);
		});
		AllPlayers = _allPlayersScratch;
		PlayerListVersion++;
		RefreshHostilePlayers();
	}

	private void RefreshHostilePlayers()
	{
		_hostilePlayersScratch.Clear();
		foreach (PlayerInfo allPlayer in AllPlayers)
		{
			if (allPlayer.IsHostile)
			{
				_hostilePlayersScratch.Add(allPlayer);
			}
		}
		HostilePlayers = _hostilePlayersScratch;
	}

	private 阵营类型 GetLocalAlliance()
	{
		long tickCount = Environment.TickCount64;
		if (_cachedLocalAlliance != 阵营类型.未知 && tickCount - _lastLocalAllianceCheckTick < 2000)
		{
			return _cachedLocalAlliance;
		}
		_lastLocalAllianceCheckTick = tickCount;
		try
		{
			OmenPlayerCharacter localPlayer = DService.Instance().ObjectTable.LocalPlayer;
			if (localPlayer != null)
			{
				阵营类型 partyAlliance = GetPartyAlliance((OmenCharacter)localPlayer);
				if (partyAlliance != 阵营类型.未知)
				{
					_cachedLocalAlliance = partyAlliance;
					return partyAlliance;
				}
			}
		}
		catch
		{
		}
		try
		{
			foreach (IPartyMember item in (IEnumerable<IPartyMember>)_partyList)
			{
				PropertyInfo property = ((object)item).GetType().GetProperty("Alliance");
				if (!(property != null))
				{
					continue;
				}
				object value = property.GetValue(item);
				if (value is byte)
				{
					switch ((byte)value)
					{
					case 0:
						_cachedLocalAlliance = 阵营类型.黑涡团;
						return 阵营类型.黑涡团;
					case 1:
						_cachedLocalAlliance = 阵营类型.双蛇党;
						return 阵营类型.双蛇党;
					case 2:
						_cachedLocalAlliance = 阵营类型.恒辉队;
						return 阵营类型.恒辉队;
					}
				}
			}
		}
		catch
		{
		}
		return 阵营类型.未知;
	}

	private void SyncTrackedPlayerServerName(ulong cid, string serverName)
	{
		bool flag = false;
		if (_plugin.Config.WatchCollections != null)
		{
			foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
			{
				关注成员 关注成员2 = watchCollection.Members.Find((关注成员 m) => m.CID == cid);
				if (关注成员2 != null && 关注成员2.ServerName != serverName)
				{
					关注成员2.ServerName = serverName;
					flag = true;
				}
			}
		}
		foreach (连线数据 line in _plugin.Config.Lines)
		{
			if (line.TargetCID == cid && line.ServerName != serverName)
			{
				line.ServerName = serverName;
				flag = true;
			}
		}
		foreach (标记配置 markerConfig in _plugin.Config.MarkerConfigs)
		{
			if (markerConfig.玩家CID == cid && markerConfig.服务器名称 != serverName)
			{
				markerConfig.服务器名称 = serverName;
				flag = true;
			}
		}
		if (flag)
		{
			_plugin.SaveConfig();
		}
	}

	public void Dispose()
	{
		_persistentPlayers.Clear();
		_markerOwners.Clear();
		AllPlayers.Clear();
		HostilePlayers.Clear();
	}

	private void ResetTrackedPlayers(bool clearOverlayCache = true)
	{
		_lastFullScanTick = 0L;
		_lastBuffScanTick = 0L;
		_persistentPlayers.Clear();
		_markerOwners.Clear();
		AllPlayers.Clear();
		HostilePlayers.Clear();
		PlayerListVersion++;
		if (clearOverlayCache)
		{
			_plugin.OverlayRenderer?.ClearScreenPositionCache();
		}
	}
}
