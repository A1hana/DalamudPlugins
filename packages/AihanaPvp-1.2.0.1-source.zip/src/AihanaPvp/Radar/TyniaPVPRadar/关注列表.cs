#nullable disable warnings
using System;
using System.Collections.Generic;

namespace TyniaPVPRadar;

[Serializable]
public class 关注列表
{
	public string Id { get; set; } = Guid.NewGuid().ToString("N");

	public string Name { get; set; } = "新列表";

	public string BorderColorHex { get; set; } = "#FFFF00";

	public bool IsOpen { get; set; } = true;

	public List<关注成员> Members { get; set; } = new List<关注成员>();
}
