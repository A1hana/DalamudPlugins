#nullable disable warnings
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace TyniaPVPRadar;

public class LineListWindow : Window
{
	private readonly TyniaPVPRadar _plugin;

	public LineListWindow(TyniaPVPRadar plugin)
		: base("连线列表")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Size = new Vector2(_plugin.Config.LineListWindowWidth, _plugin.Config.LineListWindowHeight);
		((Window)this).SizeCondition = (ImGuiCond)4;
	}

	public override void Draw()
	{
		if (_plugin.Config.Lines.Count == 0)
		{
			ImGui.Text((ImU8String)("暂无连线"));
			return;
		}
		ImGui.Text((ImU8String)("当前连线目标"));
		ImGui.Separator();
		List<连线数据> list = new List<连线数据>();
		ImGuiListClipper val = default(ImGuiListClipper);
		val.Begin(_plugin.Config.Lines.Count);
		ImU8String val2 = default(ImU8String);
		ImU8String val3 = default(ImU8String);
		while (val.Step())
		{
			for (int i = val.DisplayStart; i < val.DisplayEnd; i++)
			{
				连线数据 连线数据2 = _plugin.Config.Lines[i];
				ImGui.Text((ImU8String)(连线数据2.TargetName));
				if (!string.IsNullOrEmpty(连线数据2.ServerName))
				{
					ImGui.SameLine();
					Vector4 vector = new Vector4(0.7f, 0.7f, 0.7f, 1f);
					val2 = new ImU8String(2, 1);
					val2.AppendLiteral("- ");
					val2.AppendFormatted<string>(连线数据2.ServerName);
					ImGui.TextColored(ref vector, val2);
				}
				if (连线数据2.IsTemporary)
				{
					ImGui.SameLine();
					Vector4 vector = new Vector4(0.7f, 0.5f, 0.85f, 1f);
					ImGui.TextColored(ref vector, (ImU8String)("[临时]"));
				}
				val3 = new ImU8String(6, 1);
				val3.AppendLiteral("删除连线##");
				val3.AppendFormatted<ulong>(连线数据2.TargetCID);
				if (ImGui.Button(val3, default(Vector2)))
				{
					list.Add(连线数据2);
				}
			}
		}
		val.End();
		if (list.Count <= 0)
		{
			return;
		}
		foreach (连线数据 item in list)
		{
			_plugin.Config.Lines.Remove(item);
		}
		_plugin.SaveConfig();
	}

	public void ResetOnTerritoryChange()
	{
		if (_plugin.Config.Lines.Count != 0)
		{
			_plugin.Config.Lines.Clear();
			_plugin.SaveConfig();
		}
	}
}
