#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Configuration;
using Newtonsoft.Json;

namespace TyniaPVPRadar;

[Serializable]
public class PluginConfig : IPluginConfiguration
{
	public int Version { get; set; } = 2;

	public bool AutoOpenMainWindowOnPvp { get; set; } = true;

	public bool AutoOpenAllPlayersWindowOnPvp { get; set; } = true;

	public bool AutoOpenMarkerPanelOnPvp { get; set; } = true;

	public float DotSize { get; set; } = 3f;

	public float DotOpacity { get; set; } = 1f;

	public bool ShowEnemyDots { get; set; } = true;

	public bool ShowFriendlyDots { get; set; }

	public bool FriendlyDotsUseSelfColor { get; set; } = true;

	public bool ShowSelfDot { get; set; }

	public Vector4 SelfDotColor { get; set; } = new Vector4(1f, 1f, 1f, 1f);

	public float MapDotSize { get; set; } = 5f;

	public float MapDotOpacity { get; set; } = 1f;

	public bool ShowEnemyMapDots { get; set; } = true;

	public bool ShowFriendlyMapDots { get; set; }

	public bool ShowSelfMapDot { get; set; }

	public bool MapUseArrowInsteadOfDot { get; set; } = true;

	public bool ShowMapLines { get; set; }

	public float MapLineOpacity { get; set; } = 0.6f;

	public float MapLineThickness { get; set; } = 2f;

	public Vector4 MapLineColor { get; set; } = new Vector4(0f, 1f, 0.44313726f, 1f);

	public Vector4 EnemyMapLineColor { get; set; } = new Vector4(1f, 0f, 0.44313726f, 1f);

	public float LineThickness { get; set; } = 2f;

	public float LineOpacity { get; set; } = 0.6f;

	public bool Show3DLines { get; set; } = true;

	public Vector4 LineColor { get; set; } = new Vector4(0f, 1f, 0.44313726f, 1f);

	public Vector4 EnemyLineColor { get; set; } = new Vector4(1f, 0f, 0.44313726f, 1f);

	public Vector4 MaelstromColor { get; set; } = new Vector4(1f, 0.2f, 0.2f, 1f);

	public Vector4 TwinAdderColor { get; set; } = new Vector4(1f, 1f, 0f, 1f);

	public Vector4 ImmortalFlamesColor { get; set; } = new Vector4(0.2f, 0.6f, 1f, 1f);

	public float GridCellWidth { get; set; } = 90f;

	public float GridCellHeight { get; set; } = 50f;

	public int GridColumns { get; set; } = 8;

	public bool EnableLeftClickSelect { get; set; } = true;

	public bool ShowPreviewButtonInAllPlayersWindowTitleBar { get; set; } = true;

	public bool ShowRefreshButtonInAllPlayersWindowTitleBar { get; set; } = true;

	public float WatchMemberBorderThickness { get; set; } = 2f;

	public float PlayerAutoCleanupIntervalMinutes { get; set; } = 3f;

	public float MainWindowButtonHeight { get; set; } = 30f;

	public bool ShowSettingsButtonInMainWindowTitleBar { get; set; } = true;

	public bool ShowLockButtonInMainWindowTitleBar { get; set; } = true;

	public bool AllowMainWindowMoveAndResize { get; set; } = true;

	[Obsolete("仅用于旧数据迁移，迁移完成后可删除")]
	public bool AllowMainWindowMovement { get; set; } = true;

	[Obsolete("仅用于旧数据迁移，迁移完成后可删除")]
	public bool AllowMainWindowResize { get; set; } = true;

	public float MainWindowWidth { get; set; } = 250f;

	public float MainWindowHeight { get; set; } = 150f;

	public float SettingsWindowWidth { get; set; } = 430f;

	public float SettingsWindowHeight { get; set; } = 450f;

	public float WatchListWindowWidth { get; set; } = 300f;

	public float WatchListWindowHeight { get; set; } = 200f;

	public float LineListWindowWidth { get; set; } = 300f;

	public float LineListWindowHeight { get; set; } = 200f;

	public float MarkerPanelWidth { get; set; } = 400f;

	public float MarkerPanelHeight { get; set; } = 600f;

	public bool ShowWatchListInMain { get; set; } = true;

	public bool ShowLineListInMain { get; set; } = true;

	public List<关注列表> WatchCollections { get; set; } = new List<关注列表>();

	[Obsolete("仅用于旧数据迁移，迁移完成后可删除")]
	public List<关注玩家>? WatchList { get; set; }

	[Obsolete("仅用于旧数据迁移，迁移完成后可删除")]
	public Vector4? WatchListColor { get; set; }

	public List<连线数据> Lines { get; set; } = new List<连线数据>();

	public List<标记配置> MarkerConfigs { get; set; } = new List<标记配置>();

	public float IconScale { get; set; } = 1.38f;

	public float FontScale { get; set; } = 1f;

	public bool ShowLinePrefixInAllPlayersWindow { get; set; } = true;

	public bool ShowLineBgHintInAllPlayersWindow { get; set; } = true;

	public float LineBgHintAlpha { get; set; } = 0.3f;

	public string LinePermanentPrefixSymbol { get; set; } = "◆";

	public string LineTempPrefixSymbol { get; set; } = "◇";

	public bool ShowJobIcon { get; set; } = true;

	public bool ShowSkillIcon { get; set; } = true;

	public bool ShowMarkerIcon { get; set; }

	public bool ShowBattleLevelIcon { get; set; } = true;

	public bool AutoMarkerSkillPriority { get; set; }

	public bool SavedSkillIconBeforeAuto { get; set; } = true;

	public bool SavedMarkerIconBeforeAuto { get; set; }

	public List<string> ContextMenuItemsOrder { get; set; } = new List<string> { "Inspect", "AdventurerPlate", "NameHistory", "ServerTransfer", "AddLine", "AddTempLine", "AddWatch" };

	public bool ShowInspectMenuItem { get; set; } = true;

	public bool ShowAdventurerPlateMenuItem { get; set; } = true;

	public bool ShowCopyNameMenuItem { get; set; } = true;

	public bool CopyServerName { get; set; } = true;

	public bool ShowNameHistoryMenuItem { get; set; } = true;

	public bool ShowServerTransferMenuItem { get; set; } = true;

	public bool ShowAddLineMenuItem { get; set; } = true;

	public bool ShowAddTempLineMenuItem { get; set; } = true;

	public bool ShowAddWatchMenuItem { get; set; } = true;

	public bool AutoConfirmYesNo { get; set; } = true;

	public bool EnableOnAllMaps { get; set; }

	public bool SaveWindowStates { get; set; }

	public bool AutoResetMarkerPanelOnTerritoryChange { get; set; } = true;

	public bool AutoResetLineListOnTerritoryChange { get; set; }

	public bool ShowPlayerNameInTargetInfo { get; set; } = true;

	public bool ShowPlayerNameInFocusTargetInfo { get; set; } = true;

	public bool RequireCtrlToDeleteWatchMember { get; set; } = true;

	public bool MainWindowIsOpen { get; set; } = true;

	public bool AllPlayersWindowIsOpen { get; set; } = true;

	public bool MarkerPanelIsOpen { get; set; }

	public bool TargetSelectWindowIsOpen { get; set; }

	public bool SettingsWindowIsOpen { get; set; }

	public bool LineListWindowIsOpen { get; set; }

	public bool WatchListWindowIsOpen { get; set; }

	[JsonIgnore]
	public bool ConfigNeedsSaveAfterInit { get; private set; }

	public void Initialize()
	{
		if (WatchCollections == null)
		{
			WatchCollections = new List<关注列表>();
		}
		if (Lines == null)
		{
			Lines = new List<连线数据>();
		}
		if (MarkerConfigs == null)
		{
			MarkerConfigs = new List<标记配置>();
		}
		WatchMemberBorderThickness = Math.Clamp(WatchMemberBorderThickness, 0.5f, 10f);
		PlayerAutoCleanupIntervalMinutes = Math.Clamp(PlayerAutoCleanupIntervalMinutes, 0.5f, 10f);
		if (Lines.Count > 0)
		{
			List<连线数据> list = new List<连线数据>(Lines.Count);
			bool flag = false;
			foreach (连线数据 line in Lines)
			{
				if (line.IsTemporary)
				{
					flag = true;
				}
				else
				{
					list.Add(line);
				}
			}
			if (flag)
			{
				Lines = list;
				ConfigNeedsSaveAfterInit = true;
			}
		}
		if (Version < 2)
		{
			AllowMainWindowMoveAndResize = AllowMainWindowMovement || AllowMainWindowResize;
			Version = 2;
		}
		AllowMainWindowMovement = AllowMainWindowMoveAndResize;
		AllowMainWindowResize = AllowMainWindowMoveAndResize;
		if (AutoMarkerSkillPriority)
		{
			ShowSkillIcon = true;
			ShowMarkerIcon = true;
		}
		else if (ShowSkillIcon && ShowMarkerIcon)
		{
			ShowMarkerIcon = false;
		}
		string[] array = new string[7] { "Inspect", "AdventurerPlate", "NameHistory", "ServerTransfer", "AddLine", "AddTempLine", "AddWatch" };
		List<string> list2 = new List<string>();
		foreach (string item2 in ContextMenuItemsOrder)
		{
			if (array.Contains(item2) && !list2.Contains(item2))
			{
				list2.Add(item2);
			}
		}
		string[] array2 = array;
		foreach (string item in array2)
		{
			if (!list2.Contains(item))
			{
				list2.Add(item);
			}
		}
		ContextMenuItemsOrder = list2;
		MigrateLegacyWatchList();
	}

	private void MigrateLegacyWatchList()
	{
		if (WatchCollections.Count > 0)
		{
			return;
		}
		string borderColorHex = "#FFFF00";
		if (WatchListColor.HasValue)
		{
			borderColorHex = $"#{(int)(WatchListColor.Value.X * 255f):X2}{(int)(WatchListColor.Value.Y * 255f):X2}{(int)(WatchListColor.Value.Z * 255f):X2}";
		}
		关注列表 关注列表2 = new 关注列表
		{
			Name = "默认列表",
			BorderColorHex = borderColorHex,
			Members = new List<关注成员>()
		};
		if (WatchList != null && WatchList.Count > 0)
		{
			foreach (关注玩家 watch in WatchList)
			{
				关注列表2.Members.Add(new 关注成员
				{
					CID = watch.CID,
					Name = watch.Name
				});
			}
		}
		WatchCollections.Add(关注列表2);
		WatchList = null;
		WatchListColor = null;
	}
}
