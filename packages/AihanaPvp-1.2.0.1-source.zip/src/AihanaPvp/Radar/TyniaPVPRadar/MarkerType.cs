#nullable disable warnings
namespace TyniaPVPRadar;

public enum MarkerType
{
	Attack1,
	Attack2,
	Attack3,
	Attack4,
	Attack5,
	Attack6,
	Attack7,
	Attack8,
	Bind1,
	Bind2,
	Bind3,
	Ignore1,
	Ignore2,
	Square,
	Circle,
	Cross,
	Triangle,
	Clear
}
