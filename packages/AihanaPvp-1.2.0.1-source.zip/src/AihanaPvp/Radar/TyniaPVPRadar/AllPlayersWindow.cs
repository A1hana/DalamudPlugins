#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Interface;
using Dalamud.Interface.Components;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Textures.TextureWraps;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using OmenTools.Info.Game.Packets.Upstream;
using DalamudGameObject = Dalamud.Game.ClientState.Objects.Types.IGameObject;
using DalamudPlayerCharacter = Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter;

namespace TyniaPVPRadar;

public class AllPlayersWindow : Window
{
	private enum CenterIconDisplayMode
	{
		None,
		Skill,
		Marker
	}

	private static readonly IReadOnlyDictionary<MarkerType, uint> MarkerIconIds = new Dictionary<MarkerType, uint>
	{
		[MarkerType.Attack1] = 61201u,
		[MarkerType.Attack2] = 61202u,
		[MarkerType.Attack3] = 61203u,
		[MarkerType.Attack4] = 61204u,
		[MarkerType.Attack5] = 61205u,
		[MarkerType.Attack6] = 61206u,
		[MarkerType.Attack7] = 61207u,
		[MarkerType.Attack8] = 61208u,
		[MarkerType.Bind1] = 61211u,
		[MarkerType.Bind2] = 61212u,
		[MarkerType.Bind3] = 61213u,
		[MarkerType.Ignore1] = 61221u,
		[MarkerType.Ignore2] = 61222u,
		[MarkerType.Square] = 61231u,
		[MarkerType.Circle] = 61232u,
		[MarkerType.Cross] = 61233u,
		[MarkerType.Triangle] = 61234u
	};

	private static readonly HashSet<uint> PvpTargetBuffIds = new HashSet<uint>
	{
		4491u, 4484u, 4489u, 4495u, 4488u, 4497u, 4486u, 4494u, 4483u, 4487u,
		4492u, 4516u, 4496u, 4490u, 4485u
	};

	private readonly TyniaPVPRadar _plugin;

	private readonly TitleBarButton _refreshButton;

	private readonly TitleBarButton _previewButton;

	private readonly TitleBarButton _autoModeButton;

	private string _contextMenuPlayerName = string.Empty;

	private string _contextMenuServerName = string.Empty;

	private ulong _contextMenuPlayerCID;

	private ulong _contextMenuPlayerObjectId;

	private Vector2 _contextMenuPos;

	private readonly List<(string Label, bool HasSubMenu, string Key)> _contextMenuItemsCache = new List<(string, bool, string)>();

	private readonly List<BuffInfo> _buffFilterScratch = new List<BuffInfo>();

	private CenterIconDisplayMode? _savedCenterIconMode;

	private bool _needsSizeReset = true;

	private uint _lastTerritoryId;

	private uint _lastListVersion;

	private List<KeyValuePair<阵营类型, List<PlayerInfo>>>? _cachedGroups;

	private readonly Dictionary<阵营类型, List<PlayerInfo>> _groupDict = new Dictionary<阵营类型, List<PlayerInfo>>();

	private readonly List<KeyValuePair<阵营类型, List<PlayerInfo>>> _groupList = new List<KeyValuePair<阵营类型, List<PlayerInfo>>>();

	private readonly HashSet<ulong> _permanentLineCIDs = new HashSet<ulong>();

	private readonly HashSet<ulong> _temporaryLineCIDs = new HashSet<ulong>();

	public AllPlayersWindow(TyniaPVPRadar plugin)
		: base("所有玩家")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Flags = (ImGuiWindowFlags)72;
		_refreshButton = new TitleBarButton
		{
			AvailableClickthrough = false,
			Click = delegate
			{
				_plugin.PlayerManager.ForceRefreshPlayers();
			},
			Icon = (FontAwesomeIcon)61470
		};
		_previewButton = new TitleBarButton
		{
			AvailableClickthrough = false,
			Click = delegate
			{
				ToggleMarkerPreviewMode();
			},
			Icon = (FontAwesomeIcon)61550
		};
		_autoModeButton = new TitleBarButton
		{
			AvailableClickthrough = false,
			Click = delegate
			{
				ToggleAutoMarkerSkillMode();
			},
			Icon = (FontAwesomeIcon)61648
		};
	}

	public override void OnClose()
	{
		_needsSizeReset = true;
		base.OnClose();
	}

	public override void PreDraw()
	{
		((Window)this).TitleBarButtons.Clear();
		if (_plugin.Config.ShowRefreshButtonInAllPlayersWindowTitleBar)
		{
			((Window)this).TitleBarButtons.Add(_refreshButton);
		}
		if (_plugin.Config.ShowPreviewButtonInAllPlayersWindowTitleBar)
		{
			_autoModeButton.Icon = (FontAwesomeIcon)(_plugin.Config.AutoMarkerSkillPriority ? 58058 : 61648);
			((Window)this).TitleBarButtons.Add(_autoModeButton);
			if (!_plugin.Config.AutoMarkerSkillPriority)
			{
				((Window)this).TitleBarButtons.Add(_previewButton);
			}
		}
		uint territoryType = Service.ClientState.TerritoryType;
		if (territoryType != _lastTerritoryId)
		{
			_lastTerritoryId = territoryType;
			_needsSizeReset = true;
		}
		if (_needsSizeReset)
		{
			_needsSizeReset = false;
			ImGui.SetNextWindowSize(new Vector2(240f, 80f), (ImGuiCond)1);
		}
		base.PreDraw();
	}

	public override void Draw()
	{
		bool flag = _plugin.Config.Show3DLines || _plugin.Config.ShowMapLines;
		if (_plugin.Config.ShowLinePrefixInAllPlayersWindow && flag)
		{
			_permanentLineCIDs.Clear();
			_temporaryLineCIDs.Clear();
			List<连线数据> lines = _plugin.Config.Lines;
			if (lines.Count > 0)
			{
				for (int i = 0; i < lines.Count; i++)
				{
					连线数据 连线数据2 = lines[i];
					if (连线数据2.IsTemporary)
					{
						_temporaryLineCIDs.Add(连线数据2.TargetCID);
					}
					else
					{
						_permanentLineCIDs.Add(连线数据2.TargetCID);
					}
				}
			}
		}
		uint playerListVersion = _plugin.PlayerManager.PlayerListVersion;
		if (playerListVersion != _lastListVersion)
		{
			_lastListVersion = playerListVersion;
			_cachedGroups = null;
		}
		List<KeyValuePair<阵营类型, List<PlayerInfo>>> list = _cachedGroups ?? (_cachedGroups = GroupPlayersByAlliance());
		if (list.Count == 0)
		{
			if (_plugin.PlayerManager.IsInitialPvpScanPending)
			{
				DrawLoadingState();
			}
			else
			{
				DrawEmptyState();
			}
			DrawContextMenu();
			return;
		}
		foreach (KeyValuePair<阵营类型, List<PlayerInfo>> item in list)
		{
			DrawAllianceSection(item.Key, item.Value);
		}
		DrawContextMenu();
	}

	private float GetScaledCellWidth()
	{
		return _plugin.Config.GridCellWidth;
	}

	private float GetScaledCellHeight()
	{
		return _plugin.Config.GridCellHeight;
	}

	private float GetBannerHeight()
	{
		return GetScaledCellHeight() * 0.6f;
	}

	private List<KeyValuePair<阵营类型, List<PlayerInfo>>> GroupPlayersByAlliance()
	{
		foreach (KeyValuePair<阵营类型, List<PlayerInfo>> item in _groupDict)
		{
			item.Value.Clear();
		}
		_groupDict.Clear();
		_groupList.Clear();
		foreach (PlayerInfo allPlayer in _plugin.PlayerManager.AllPlayers)
		{
			if (!_groupDict.TryGetValue(allPlayer.阵营, out List<PlayerInfo> value))
			{
				value = new List<PlayerInfo>();
				_groupDict[allPlayer.阵营] = value;
			}
			value.Add(allPlayer);
		}
		阵营类型[] array = new 阵营类型[3]
		{
			阵营类型.黑涡团,
			阵营类型.双蛇党,
			阵营类型.恒辉队
		};
		foreach (阵营类型 key in array)
		{
			if (_groupDict.TryGetValue(key, out List<PlayerInfo> value2))
			{
				_groupList.Add(new KeyValuePair<阵营类型, List<PlayerInfo>>(key, value2));
			}
		}
		return _groupList;
	}

	private void DrawAllianceSection(阵营类型 alliance, List<PlayerInfo> players)
	{
		bool flag = !_plugin.PlayerManager.IsInPvpZone || Service.ClientState.TerritoryType == 250;
		Vector4 vector;
		ImGuiStylePtr style;
		if (!flag)
		{
			vector = new Vector4(GetAllianceBaseColor(alliance).X, GetAllianceBaseColor(alliance).Y, GetAllianceBaseColor(alliance).Z, 0.4f);
		}
		else
		{
			style = ImGui.GetStyle();
			vector = style.Colors[21];
		}
		Vector4 vector2 = vector;
		string text = (flag ? "附近玩家" : GetAllianceName(alliance));
		ImGui.PushStyleColor((ImGuiCol)21, vector2);
		ImGui.PushStyleColor((ImGuiCol)22, AdjustBrightness(vector2, 1.1f));
		ImGui.PushStyleColor((ImGuiCol)23, AdjustBrightness(vector2, 0.9f));
		ImGui.PushStyleColor((ImGuiCol)0, new Vector4(0f, 0f, 0f, 0f));
		float num = (float)_plugin.Config.GridColumns * GetScaledCellWidth();
		float num2 = _plugin.Config.GridColumns - 1;
		style = ImGui.GetStyle();
		float x = num + num2 * style.ItemSpacing.X;
		Vector2 vector3 = new Vector2(x, GetBannerHeight());
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		windowDrawList.AddRectFilled(cursorScreenPos, cursorScreenPos + vector3, ImGui.GetColorU32(new Vector4(10f / 51f, 10f / 51f, 10f / 51f, 1f)));
		ImGui.PushID((IntPtr)(nint)alliance);
		ImGui.Button((ImU8String)("##banner"), vector3);
		ImGui.PopID();
		ImU8String val = default(ImU8String);
		val = new ImU8String(3, 2);
		val.AppendFormatted<string>(text);
		val.AppendLiteral(" (");
		val.AppendFormatted<int>(players.Count);
		val.AppendLiteral(")");
		Vector2 vector4 = ImGui.CalcTextSize(val, false, -1f);
		Vector2 position = new Vector2(cursorScreenPos.X + (vector3.X - vector4.X) * 0.5f, cursorScreenPos.Y + (vector3.Y - vector4.Y) * 0.5f);
		DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), $"{text} ({players.Count})");
		ImGui.PopStyleColor(4);
		for (int i = 0; i < players.Count; i++)
		{
			bool placeOnSameLineAfter = (i + 1) % _plugin.Config.GridColumns != 0 && i < players.Count - 1;
			DrawPlayerCell(players[i], placeOnSameLineAfter, flag);
		}
	}

	private void DrawEmptyState()
	{
		ImGui.TextWrapped((ImU8String)((_plugin.PlayerManager.IsInPvpZone || _plugin.Config.EnableOnAllMaps) ? "当前没有可显示的玩家。" : "当前不在PVP地图，没有可显示的玩家。"));
		ImGui.Dummy(new Vector2(MathF.Max(220f, GetScaledCellWidth() * 2f), 16f));
	}

	private void DrawLoadingState()
	{
		ImGui.TextWrapped((ImU8String)("加载中..."));
		ImGui.Dummy(new Vector2(MathF.Max(220f, GetScaledCellWidth() * 2f), 16f));
	}

	private unsafe void DrawPlayerCell(PlayerInfo player, bool placeOnSameLineAfter, bool isNearbyMode)
	{
		if (_plugin.Config == null)
		{
			return;
		}
		Vector2 vector = new Vector2(GetScaledCellWidth(), GetScaledCellHeight());
		var (flag, text) = GetPlayerCollectionInfo(player.CID);
		ImGuiStylePtr style;
		Vector4 vector2;
		if (isNearbyMode)
		{
			style = ImGui.GetStyle();
			vector2 = style.Colors[21];
		}
		else
		{
			Vector4 allianceBaseColor = GetAllianceBaseColor(player.阵营);
			vector2 = new Vector4(allianceBaseColor.X, allianceBaseColor.Y, allianceBaseColor.Z, 0.4f);
		}
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		windowDrawList.AddRectFilled(cursorScreenPos, cursorScreenPos + vector, ImGui.GetColorU32(new Vector4(10f / 51f, 10f / 51f, 10f / 51f, 1f)));
		ImGui.PushStyleColor((ImGuiCol)21, vector2);
		ImGui.PushStyleColor((ImGuiCol)22, AdjustBrightness(vector2, 1.1f));
		ImGui.PushStyleColor((ImGuiCol)23, AdjustBrightness(vector2, 0.9f));
		Vector4 vector3;
		if (!flag)
		{
			style = ImGui.GetStyle();
			vector3 = style.Colors[0];
		}
		else
		{
			vector3 = ParseColor(text);
		}
		ImGui.PushStyleColor((ImGuiCol)0, vector3);
		ImGui.PushID((IntPtr)(nint)player.CID);
		if (ImGui.Button((ImU8String)("##player"), vector) && _plugin.Config.EnableLeftClickSelect)
		{
			DalamudPlayerCharacter? target = player.Object;
			if (target == null || ((DalamudGameObject)target).Address == IntPtr.Zero)
			{
				Service.ToastGui.ShowError("目标距离过远，无法选中。");
			}
			else
			{
				try
				{
					DalamudPlayerCharacter? localPlayer = Service.ObjectTable.LocalPlayer;
					if (localPlayer == null || ((DalamudGameObject)localPlayer).Address == IntPtr.Zero)
					{
						Service.ToastGui.ShowError("目标不可选中。");
					}
					else
					{
						float deltaX = ((DalamudGameObject)target).Position.X - ((DalamudGameObject)localPlayer).Position.X;
						float deltaZ = ((DalamudGameObject)target).Position.Z - ((DalamudGameObject)localPlayer).Position.Z;
						if (deltaX * deltaX + deltaZ * deltaZ > 3025f)
						{
							Service.ToastGui.ShowError("目标距离过远，无法选中。");
						}
						else
						{
							Service.TargetManager.Target = target;
						}
					}
				}
				catch (Exception)
				{
					Service.ToastGui.ShowError("目标不可选中。");
				}
			}
		}
		ImGui.PopID();
		if ((_plugin.Config.Show3DLines || _plugin.Config.ShowMapLines) && _plugin.Config.ShowLinePrefixInAllPlayersWindow && _plugin.Config.ShowLineBgHintInAllPlayersWindow && (_permanentLineCIDs.Contains(player.CID) || _temporaryLineCIDs.Contains(player.CID)))
		{
			Vector2 itemRectMin = ImGui.GetItemRectMin();
			Vector2 itemRectMax = ImGui.GetItemRectMax();
			float num3 = Math.Clamp(_plugin.Config.LineBgHintAlpha, 0f, 1f);
			if (num3 > 0.001f)
			{
				uint colorU = ImGui.GetColorU32(new Vector4(0.5f, 0.5f, 0.5f, num3 * 0.6f));
				windowDrawList.AddRectFilled(itemRectMin, itemRectMax, colorU);
				uint colorU2 = ImGui.GetColorU32(new Vector4(0.85f, 0.85f, 0.85f, num3));
				float scaledCellHeight = GetScaledCellHeight();
				float fontSize = ImGui.GetFontSize();
				float num4 = Math.Max(3f, fontSize * 0.2f + scaledCellHeight * 0.115f);
				float num5 = Math.Max(0.75f, fontSize * 0.1f);
				Vector2 vector4 = itemRectMin;
				Vector2 vector5 = itemRectMax;
				float num6 = vector5.X - vector4.X;
				float num7 = vector5.Y - vector4.Y;
				float num8 = vector4.X - num7;
				float num9 = vector4.X + num6;
				windowDrawList.PushClipRect(vector4, vector5);
				for (float num10 = num8; num10 <= num9; num10 += num4)
				{
					windowDrawList.AddLine(new Vector2(num10, vector4.Y), new Vector2(num10 + num7, vector5.Y), colorU2, num5);
				}
				windowDrawList.PopClipRect();
				ImGuiStylePtr style2 = ImGui.GetStyle();
				uint colorU3 = ImGui.GetColorU32((ImGuiCol)5);
				float frameBorderSize = style2.FrameBorderSize;
				float frameRounding = style2.FrameRounding;
				if (frameBorderSize > 0f)
				{
					windowDrawList.AddRect(itemRectMin, itemRectMax, colorU3, frameRounding);
				}
			}
		}
		if (flag && !string.IsNullOrEmpty(text))
		{
			Vector2 itemRectMin2 = ImGui.GetItemRectMin();
			Vector2 itemRectMax2 = ImGui.GetItemRectMax();
			uint colorU4 = ImGui.GetColorU32(ParseColor(text));
			float watchMemberBorderThickness = _plugin.Config.WatchMemberBorderThickness;
			uint colorU5 = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 1f));
			float num11 = (watchMemberBorderThickness + 1f) * 0.5f;
			Vector2 vector6 = new Vector2(num11, num11);
			windowDrawList.AddRect(itemRectMin2 - vector6, itemRectMax2 + vector6, colorU5, 0f, (ImDrawFlags)0, 1f);
			windowDrawList.AddRect(itemRectMin2, itemRectMax2, colorU4, 0f, (ImDrawFlags)0, watchMemberBorderThickness);
			windowDrawList.AddRect(itemRectMin2 + vector6, itemRectMax2 - vector6, colorU5, 0f, (ImDrawFlags)0, 1f);
		}
		if (ImGui.IsItemClicked((ImGuiMouseButton)1))
		{
			_contextMenuPlayerName = player.Name;
			_contextMenuServerName = player.ServerName;
			_contextMenuPlayerCID = player.CID;
			DalamudPlayerCharacter? obj = player.Object;
			_contextMenuPlayerObjectId = ((obj != null) ? ((DalamudGameObject)obj).GameObjectId : 0);
			_contextMenuPos = ImGui.GetMousePos();
			ImGui.OpenPopup((ImU8String)("PlayerContextMenu"), (ImGuiPopupFlags)0);
		}
		ImDrawListPtr windowDrawList2 = ImGui.GetWindowDrawList();
		Vector2 itemRectMin3 = ImGui.GetItemRectMin();
		Vector2 itemRectSize = ImGui.GetItemRectSize();
		DrawPlayerName(player, itemRectMin3, itemRectSize);
		DrawPlayerIcon(player, windowDrawList2, itemRectMin3, itemRectSize);
		DrawBattleLevelIcon(player, windowDrawList2, itemRectMin3, itemRectSize);
		DrawPvpBuffIcons(player, windowDrawList2, itemRectMin3, itemRectSize);
		DrawMarkerIcon(player, windowDrawList2, itemRectMin3, itemRectSize);
		ImGui.PopStyleColor(4);
		if (placeOnSameLineAfter)
		{
			ImGui.SameLine();
		}
	}

	private unsafe void DrawContextMenu()
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		float frameHeight = ImGui.GetFrameHeight();
		float textLineHeight = ImGui.GetTextLineHeight();
		float y = style.ItemSpacing.Y;
		float x = style.WindowPadding.X;
		float y2 = style.WindowPadding.Y;
		_contextMenuItemsCache.Clear();
		bool flag = false;
		bool flag2 = false;
		foreach (连线数据 line in _plugin.Config.Lines)
		{
			if (line.TargetCID == _contextMenuPlayerCID)
			{
				if (line.IsTemporary)
				{
					flag2 = true;
				}
				else
				{
					flag = true;
				}
				if (flag2 && flag)
				{
					break;
				}
			}
		}
		List<关注列表> playerCollections = GetPlayerCollections(_contextMenuPlayerCID);
		DalamudPlayerCharacter localPlayer = Service.ObjectTable.LocalPlayer;
		bool isSelf = localPlayer != null && _contextMenuPlayerObjectId == ((DalamudGameObject)localPlayer).GameObjectId;
		bool showCopyNameMenuItem = _plugin.Config.ShowCopyNameMenuItem;
		FillVisibleMenuItems(flag, flag2, isSelf, _contextMenuItemsCache);
		List<(string, bool, string)> contextMenuItemsCache = _contextMenuItemsCache;
		float num = 0f;
		foreach (var item in contextMenuItemsCache)
		{
			float x2 = ImGui.CalcTextSize((ImU8String)(item.Item1), false, -1f).X;
			if (x2 > num)
			{
				num = x2;
			}
		}
		float num2 = style.FramePadding.X * 2f + style.ItemSpacing.X;
		float num3 = frameHeight * 0.7f;
		float val = num + num2 + num3;
		float num4 = ImGui.CalcTextSize((ImU8String)(_contextMenuPlayerName), false, -1f).X;
		if (!string.IsNullOrEmpty(_contextMenuServerName))
		{
			float x3 = ImGui.CalcTextSize((ImU8String)(_contextMenuServerName), false, -1f).X;
			if (x3 > num4)
			{
				num4 = x3;
			}
		}
		float val2 = (showCopyNameMenuItem ? (num4 + frameHeight + style.ItemSpacing.X) : num4);
		float num5 = Math.Max(val, val2) + x * 2f;
		int count = contextMenuItemsCache.Count;
		float num6 = ((!string.IsNullOrEmpty(_contextMenuServerName)) ? ((showCopyNameMenuItem ? (Math.Max(textLineHeight, frameHeight) + y) : (textLineHeight + y)) + textLineHeight + y) : (showCopyNameMenuItem ? (Math.Max(textLineHeight, frameHeight) + y) : (textLineHeight + y)));
		float num7 = y * 2f + 1f;
		float num8 = (float)count * frameHeight;
		float num9 = y2 + num6 + num7 + num8;
		ImGuiIOPtr iO = ImGui.GetIO();
		Vector2 displaySize = iO.DisplaySize;
		Vector2 contextMenuPos = _contextMenuPos;
		float num10 = 4f;
		if (contextMenuPos.X + num5 + num10 > displaySize.X)
		{
			contextMenuPos.X = displaySize.X - num5 - num10;
		}
		if (contextMenuPos.X < num10)
		{
			contextMenuPos.X = num10;
		}
		if (contextMenuPos.Y + num9 + num10 > displaySize.Y)
		{
			contextMenuPos.Y = _contextMenuPos.Y - num9;
		}
		if (contextMenuPos.Y < num10)
		{
			contextMenuPos.Y = num10;
		}
		ImGui.SetNextWindowPos(contextMenuPos);
		ImGui.SetNextWindowSize(new Vector2(num5, 0f));
		if (!ImGui.BeginPopup((ImU8String)("PlayerContextMenu"), (ImGuiWindowFlags)0))
		{
			return;
		}
		ImGuiStylePtr style2 = ImGui.GetStyle();
		ImGui.PushStyleVar((ImGuiStyleVar)1, new Vector2(MathF.Max(0f, style2.WindowPadding.X * 4f / 5f), MathF.Max(0f, style2.WindowPadding.Y * 4f / 5f)));
		float cursorPosY = ImGui.GetCursorPosY();
		ImGui.Text((ImU8String)(_contextMenuPlayerName));
		if (!string.IsNullOrEmpty(_contextMenuServerName))
		{
			Vector4 vector = new Vector4(0.7f, 0.7f, 0.7f, 1f);
			ImGui.TextColored(ref vector, (ImU8String)(_contextMenuServerName));
		}
		if (_plugin.Config.ShowCopyNameMenuItem)
		{
			float cursorPosX = ImGui.GetCursorPosX();
			float cursorPosY2 = ImGui.GetCursorPosY();
			ImGui.SetCursorPosX(ImGui.GetWindowContentRegionMax().X - frameHeight);
			ImGui.SetCursorPosY(cursorPosY + (ImGui.GetTextLineHeight() - frameHeight) * 0.5f);
			if (ImGuiComponents.IconButton((FontAwesomeIcon)61637))
			{
				ImGui.SetClipboardText((ImU8String)((_plugin.Config.CopyServerName && !string.IsNullOrEmpty(_contextMenuServerName)) ? (_contextMenuPlayerName + "@" + _contextMenuServerName) : _contextMenuPlayerName));
				ImGui.CloseCurrentPopup();
			}
			ImGui.SetCursorPos(new Vector2(cursorPosX, cursorPosY2));
		}
		if (contextMenuItemsCache.Count > 0)
		{
			ImGui.Separator();
			foreach (var item2 in contextMenuItemsCache)
			{
				switch (item2.Item3)
				{
				case "Inspect":
					if (!ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						break;
					}
					try
					{
						if (Service.ObjectTable.SearchById(_contextMenuPlayerObjectId) != null)
						{
							AgentInspect.Instance()->ExamineCharacter((uint)_contextMenuPlayerObjectId, false);
						}
						else
						{
							Service.ToastGui.ShowError(_contextMenuPlayerName + " 距离太远，无法调查。");
						}
					}
					catch
					{
						Service.ToastGui.ShowError(_contextMenuPlayerName + " 距离太远，无法调查。");
					}
					break;
				case "AdventurerPlate":
					if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						try
						{
							new CharaCardOpenPacket(_contextMenuPlayerObjectId).Send();
						}
						catch
						{
							Service.ToastGui.ShowError(_contextMenuPlayerName + " 距离太远，无法查看冒险者铭牌。");
						}
					}
					break;
				case "NameHistory":
					if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						_plugin.UsedNameIntegration.SearchPlayerByCID(_contextMenuPlayerCID);
					}
					break;
				case "ServerTransfer":
					if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						_plugin.UsedNameIntegration.GetServerTransferHistoryByCID(_contextMenuPlayerCID);
					}
					break;
				case "AddLine":
					if (flag)
					{
						if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
						{
							RemoveLineFromPlayer(_contextMenuPlayerCID);
						}
					}
					else if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						AddLineToPlayer(_contextMenuPlayerCID, _contextMenuPlayerName, _contextMenuServerName);
					}
					break;
				case "AddTempLine":
					if (flag2)
					{
						if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
						{
							RemoveLineFromPlayer(_contextMenuPlayerCID);
						}
					}
					else if (ImGui.MenuItem((ImU8String)(item2.Item1), false, true))
					{
						AddTempLineToPlayer(_contextMenuPlayerCID, _contextMenuPlayerName, _contextMenuServerName);
					}
					break;
				case "AddWatch":
				{
					if (!ImGui.BeginMenu((ImU8String)(item2.Item1), true))
					{
						break;
					}
					int num11 = 0;
					foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
					{
						bool flag3 = false;
						foreach (关注列表 item3 in playerCollections)
						{
							if (item3.Id == watchCollection.Id)
							{
								flag3 = true;
								break;
							}
						}
						ImGuiStylePtr style3 = ImGui.GetStyle();
						float num12 = style3.FramePadding.X * 0.5f;
						Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
						Vector2 vector2 = cursorScreenPos;
						Vector2 vector3 = new Vector2(ImGui.GetContentRegionAvail().X, ImGui.GetFrameHeight());
						float num13 = ImGui.GetFontSize() * 0.6f;
						int num14 = Math.Max(4, (int)Math.Round(num13));
						float num15 = style3.ItemSpacing.X * 0.35f;
						string text = (flag3 ? "从 " : "添加到 ");
						string text2 = (flag3 ? "中移除" : "");
						ImGui.SetCursorScreenPos(vector2);
						ImGui.PushID((IntPtr)num11);
						bool num16 = ImGui.InvisibleButton((ImU8String)("##menuCol"), vector3, (ImGuiButtonFlags)0);
						ImGui.PopID();
						bool num17 = ImGui.IsItemHovered();
						Vector4 vector4 = ParseColor(watchCollection.BorderColorHex);
						ImGui.SetCursorScreenPos(vector2);
						if (num17)
						{
							uint colorU = ImGui.GetColorU32((ImGuiCol)25);
							Vector2 vector5 = new Vector2(vector2.X + vector3.X + num12, vector2.Y + vector3.Y);
							ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
							windowDrawList.AddRectFilled(vector2, vector5, colorU);
						}
						float num18 = MathF.Max(0f, (vector3.Y - ImGui.GetFontSize()) * 0.5f);
						Vector2 cursorScreenPos2 = new Vector2(vector2.X + num12, vector2.Y + num18);
						ImGui.SetCursorScreenPos(cursorScreenPos2);
						ImGui.TextUnformatted((ImU8String)(text));
						ImGui.SameLine(0f, 0f);
						ImGui.TextUnformatted((ImU8String)(watchCollection.Name));
						ImGui.SameLine(0f, num15);
						ImGui.Dummy(new Vector2(num14, num14));
						float x4 = ImGui.GetItemRectMin().X;
						iO = ImGui.GetIO();
						float num19 = iO.FontGlobalScale;
						if (num19 <= 0.001f)
						{
							num19 = 1f;
						}
						float num20 = 1f;
						float num21 = cursorScreenPos2.Y + ImGui.GetFontSize() * 0.5f;
						float num22 = (float)Math.Round(x4);
						float num23 = num21 - (float)num14 * 0.5f + num20 * num19;
						num23 = (float)Math.Round(num23, MidpointRounding.AwayFromZero);
						Vector2 vector6 = new Vector2(num22, num23);
						Vector2 vector7 = new Vector2(num22 + (float)num14, num23 + (float)num14);
						ImDrawListPtr windowDrawList2 = ImGui.GetWindowDrawList();
						vector4.W = 1f;
						windowDrawList2.AddRectFilled(vector6, vector7, ImGui.ColorConvertFloat4ToU32(vector4));
						windowDrawList2.AddRect(vector6, vector7, ImGui.ColorConvertFloat4ToU32(new Vector4(0f, 0f, 0f, 1f)));
						if (flag3)
						{
							ImGui.SameLine();
							ImGui.TextUnformatted((ImU8String)(text2));
						}
						ImGui.SetCursorScreenPos(new Vector2(cursorScreenPos.X, cursorScreenPos.Y + vector3.Y));
						if (num16)
						{
							if (flag3)
							{
								RemovePlayerFromCollection(watchCollection.Id, _contextMenuPlayerCID);
							}
							else
							{
								AddPlayerToCollection(watchCollection.Id, _contextMenuPlayerCID, _contextMenuPlayerName, _contextMenuServerName);
							}
							ImGui.CloseCurrentPopup();
						}
						num11++;
					}
					if (_plugin.Config.WatchCollections.Count == 0)
					{
						ImGui.TextDisabled((ImU8String)("暂无列表，请在设置中创建"));
					}
					ImGui.EndMenu();
					break;
				}
				}
			}
		}
		ImGui.PopStyleVar();
		ImGui.EndPopup();
	}

	private void FillVisibleMenuItems(bool hasPermanentLine, bool hasTempLine, bool isSelf, List<(string Label, bool HasSubMenu, string Key)> result)
	{
		foreach (string item3 in _plugin.Config.ContextMenuItemsOrder)
		{
			if (item3 switch
			{
				"Inspect" => _plugin.Config.ShowInspectMenuItem, 
				"AdventurerPlate" => _plugin.Config.ShowAdventurerPlateMenuItem, 
				"NameHistory" => _plugin.UsedNameIntegration.IsAvailable && _plugin.Config.ShowNameHistoryMenuItem, 
				"ServerTransfer" => _plugin.UsedNameIntegration.IsAvailable && _plugin.Config.ShowServerTransferMenuItem, 
				"AddLine" => _plugin.Config.ShowAddLineMenuItem && !isSelf, 
				"AddTempLine" => _plugin.Config.ShowAddTempLineMenuItem && !isSelf && !_plugin.Config.AutoResetLineListOnTerritoryChange, 
				"AddWatch" => _plugin.Config.ShowAddWatchMenuItem, 
				_ => false, 
			})
			{
				string item = item3 switch
				{
					"Inspect" => "调查", 
					"AdventurerPlate" => "查看冒险者铭牌", 
					"NameHistory" => "改名查询", 
					"ServerTransfer" => "转服查询", 
					"AddLine" => hasPermanentLine ? "删除连线" : "添加连线", 
					"AddTempLine" => hasTempLine ? "删除临时连线" : "添加临时连线", 
					"AddWatch" => "添加关注", 
					_ => "", 
				};
				bool item2 = item3 == "AddWatch";
				result.Add((item, item2, item3));
			}
		}
	}

	private void AddLineToPlayer(ulong cid, string name, string serverName)
	{
		连线数据 连线数据2 = _plugin.Config.Lines.Find((连线数据 l) => l.TargetCID == cid);
		if (连线数据2 == null)
		{
			_plugin.Config.Lines.Add(new 连线数据
			{
				TargetCID = cid,
				TargetName = name,
				ServerName = serverName
			});
			_plugin.SaveConfig();
		}
		else if (连线数据2.IsTemporary)
		{
			连线数据2.IsTemporary = false;
			_plugin.SaveConfig();
		}
	}

	private void AddTempLineToPlayer(ulong cid, string name, string serverName)
	{
		连线数据 连线数据2 = _plugin.Config.Lines.Find((连线数据 l) => l.TargetCID == cid);
		if (连线数据2 == null)
		{
			_plugin.Config.Lines.Add(new 连线数据
			{
				TargetCID = cid,
				TargetName = name,
				ServerName = serverName,
				IsTemporary = true
			});
			_plugin.SaveConfig();
		}
		else if (!连线数据2.IsTemporary)
		{
			连线数据2.IsTemporary = true;
			_plugin.SaveConfig();
		}
	}

	private void RemoveLineFromPlayer(ulong cid)
	{
		连线数据 连线数据2 = _plugin.Config.Lines.Find((连线数据 l) => l.TargetCID == cid);
		if (连线数据2 != null)
		{
			_plugin.Config.Lines.Remove(连线数据2);
			_plugin.SaveConfig();
		}
	}

	private void AddPlayerToCollection(string collectionId, ulong cid, string name, string serverName)
	{
		关注列表 关注列表2 = _plugin.Config.WatchCollections.Find((关注列表 c) => c.Id == collectionId);
		if (关注列表2 == null)
		{
			return;
		}
		foreach (关注成员 member in 关注列表2.Members)
		{
			if (member.CID == cid)
			{
				return;
			}
		}
		foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
		{
			if (!(watchCollection.Id == collectionId))
			{
				关注成员 关注成员2 = watchCollection.Members.Find((关注成员 m) => m.CID == cid);
				if (关注成员2 != null)
				{
					watchCollection.Members.Remove(关注成员2);
				}
			}
		}
		关注列表2.Members.Add(new 关注成员
		{
			CID = cid,
			Name = name,
			ServerName = serverName
		});
		_plugin.SaveConfig();
	}

	private void RemovePlayerFromCollection(string collectionId, ulong cid)
	{
		关注列表 关注列表2 = _plugin.Config.WatchCollections.Find((关注列表 c) => c.Id == collectionId);
		if (关注列表2 != null)
		{
			关注成员 关注成员2 = 关注列表2.Members.Find((关注成员 m) => m.CID == cid);
			if (关注成员2 != null)
			{
				关注列表2.Members.Remove(关注成员2);
				_plugin.SaveConfig();
			}
		}
	}

	private List<关注列表> GetPlayerCollections(ulong cid)
	{
		List<关注列表> list = new List<关注列表>(_plugin.Config.WatchCollections.Count);
		foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
		{
			foreach (关注成员 member in watchCollection.Members)
			{
				if (member.CID == cid)
				{
					list.Add(watchCollection);
					break;
				}
			}
		}
		return list;
	}

	private (bool isInCollection, string? colorHex) GetPlayerCollectionInfo(ulong cid)
	{
		foreach (关注列表 watchCollection in _plugin.Config.WatchCollections)
		{
			bool flag = false;
			foreach (关注成员 member in watchCollection.Members)
			{
				if (member.CID == cid)
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				return (isInCollection: true, colorHex: watchCollection.BorderColorHex);
			}
		}
		return (isInCollection: false, colorHex: null);
	}

	private Vector4 ParseColor(string? hexColor)
	{
		ImGuiStylePtr style;
		if (string.IsNullOrEmpty(hexColor))
		{
			style = ImGui.GetStyle();
			return style.Colors[0];
		}
		try
		{
			if (hexColor.StartsWith("#"))
			{
				hexColor = hexColor.Substring(1);
			}
			byte num = byte.Parse(hexColor.Substring(0, 2), NumberStyles.HexNumber);
			byte b = byte.Parse(hexColor.Substring(2, 2), NumberStyles.HexNumber);
			return new Vector4(z: (float)(int)byte.Parse(hexColor.Substring(4, 2), NumberStyles.HexNumber) / 255f, x: (float)(int)num / 255f, y: (float)(int)b / 255f, w: 1f);
		}
		catch
		{
			style = ImGui.GetStyle();
			return style.Colors[0];
		}
	}

	private Vector4 GetAllianceBaseColor(阵营类型 alliance)
	{
		return alliance switch
		{
			阵营类型.双蛇党 => _plugin.Config.TwinAdderColor, 
			阵营类型.恒辉队 => _plugin.Config.ImmortalFlamesColor, 
			阵营类型.黑涡团 => _plugin.Config.MaelstromColor, 
			_ => new Vector4(0.2f, 0.2f, 0.2f, 1f), 
		};
	}

	private Vector4 AdjustBrightness(Vector4 color, float factor)
	{
		return new Vector4(Math.Clamp(color.X * factor, 0f, 1f), Math.Clamp(color.Y * factor, 0f, 1f), Math.Clamp(color.Z * factor, 0f, 1f), color.W);
	}

	private string GetAllianceName(阵营类型 alliance)
	{
		return alliance switch
		{
			阵营类型.双蛇党 => "双蛇党", 
			阵营类型.恒辉队 => "恒辉队", 
			阵营类型.黑涡团 => "黑涡团", 
			_ => "未知", 
		};
	}

	private void DrawPlayerName(PlayerInfo player, Vector2 buttonPos, Vector2 buttonSize)
	{
		float num = 4f;
		Vector2 position = new Vector2(buttonPos.X + num + 2f, buttonPos.Y + num - 2f);
		bool flag = _plugin.Config.Show3DLines || _plugin.Config.ShowMapLines;
		if (!_plugin.Config.ShowLinePrefixInAllPlayersWindow || !flag)
		{
			DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), player.Name);
			return;
		}
		if (_plugin.Config.ShowLineBgHintInAllPlayersWindow)
		{
			DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), player.Name);
			return;
		}
		string text = null;
		if (_permanentLineCIDs.Contains(player.CID))
		{
			text = _plugin.Config.LinePermanentPrefixSymbol;
			if (string.IsNullOrEmpty(text))
			{
				text = "◆";
			}
		}
		else if (_temporaryLineCIDs.Contains(player.CID))
		{
			text = _plugin.Config.LineTempPrefixSymbol;
			if (string.IsNullOrEmpty(text))
			{
				text = "◇";
			}
		}
		if (text != null)
		{
			float num2 = Math.Max(0.01f, _plugin.Config.FontScale);
			float num3 = ImGui.GetFontSize() * num2;
			DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), text);
			float num4 = ImGui.CalcTextSize((ImU8String)(text), false, -1f).X * num2;
			float num5 = num3 * 0.1f;
			if (num4 < num5)
			{
				num4 = num3 * 0.9f;
			}
			float num6 = num3 * 0.1f;
			float num7 = num4 + num6;
			position.X += num7;
		}
		DrawOutlinedText(position, new Vector4(1f, 1f, 1f, 1f), player.Name);
	}

	private void DrawOutlinedText(Vector2 position, Vector4 textColor, string text)
	{
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		uint colorU = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 1f));
		uint colorU2 = ImGui.GetColorU32(textColor);
		float fontScale = _plugin.Config.FontScale;
		ImFontPtr font = ImGui.GetFont();
		float num = ImGui.GetFontSize() * _plugin.Config.FontScale;
		windowDrawList.AddText(font, num, position + new Vector2(0f - fontScale, 0f), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(fontScale, 0f), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(0f, 0f - fontScale), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position + new Vector2(0f, fontScale), colorU, (ImU8String)(text), 0f);
		windowDrawList.AddText(font, num, position, colorU2, (ImU8String)(text), 0f);
	}

	private void DrawPlayerIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 buttonPos, Vector2 buttonSize)
	{
		if (!_plugin.Config.ShowJobIcon)
		{
			return;
		}
		float num = 4f;
		float num2 = 18f * _plugin.Config.IconScale;
		if (player.ClassJobId == 0)
		{
			return;
		}
		try
		{
			uint num3 = 62100 + player.ClassJobId;
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(num3);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(buttonPos.X + num, buttonPos.Y + buttonSize.Y - num2 - num);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num2), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch
		{
		}
	}

	private void DrawBattleLevelIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 buttonPos, Vector2 buttonSize)
	{
		if (!_plugin.Config.ShowBattleLevelIcon)
		{
			return;
		}
		float num = 4f;
		float num2 = 18f * _plugin.Config.IconScale;
		if (player.战意等级 == 战意等级.无战意)
		{
			return;
		}
		try
		{
			uint num3 = player.战意等级 switch
			{
				战意等级.战意1 => 61483u, 
				战意等级.战意2 => 61484u, 
				战意等级.战意3 => 61485u, 
				战意等级.战意4 => 61486u, 
				战意等级.战意5 => 61487u, 
				_ => 0u, 
			};
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(num3);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(buttonPos.X + buttonSize.X - num2 - num, buttonPos.Y + buttonSize.Y - num2 - num);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num2), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch
		{
		}
	}

	private void DrawPvpBuffIcons(PlayerInfo player, ImDrawListPtr drawList, Vector2 buttonPos, Vector2 buttonSize)
	{
		if (!_plugin.Config.ShowSkillIcon || (_plugin.Config.AutoMarkerSkillPriority && _plugin.Config.ShowMarkerIcon && player.CurrentMarker.HasValue) || player.Buffs == null || player.Buffs.Count == 0)
		{
			return;
		}
		_buffFilterScratch.Clear();
		foreach (BuffInfo buff in player.Buffs)
		{
			if (PvpTargetBuffIds.Contains(buff.StatusId) && buff.IconId != 0)
			{
				_buffFilterScratch.Add(buff);
			}
		}
		if (_buffFilterScratch.Count == 0)
		{
			return;
		}
		float num = 19.7f * _plugin.Config.IconScale;
		float num2 = 18f * _plugin.Config.IconScale;
		float num3 = 4f;
		float num4 = buttonPos.Y + buttonSize.Y - num3 - num2 / 2f;
		foreach (BuffInfo item in _buffFilterScratch)
		{
			try
			{
				ITextureProvider textureProvider = Service.TextureProvider;
				GameIconLookup val = (GameIconLookup)(item.IconId);
				ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
				if (fromGameIcon != null)
				{
					IDalamudTextureWrap wrapOrEmpty = fromGameIcon.GetWrapOrEmpty();
					if (wrapOrEmpty.Handle != (IntPtr)IntPtr.Zero)
					{
						float num5 = wrapOrEmpty.Size.X / wrapOrEmpty.Size.Y;
						float num6 = num * num5;
						Vector2 vector = new Vector2(buttonPos.X + (buttonSize.X - num6) / 2f, num4 - num / 2f + 0.3f * _plugin.Config.IconScale);
						drawList.AddImage(wrapOrEmpty.Handle, vector, vector + new Vector2(num6, num), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
					}
				}
			}
			catch
			{
			}
		}
	}

	private void DrawMarkerIcon(PlayerInfo player, ImDrawListPtr drawList, Vector2 buttonPos, Vector2 buttonSize)
	{
		if (!_plugin.Config.ShowMarkerIcon || !player.CurrentMarker.HasValue || !MarkerIconIds.TryGetValue(player.CurrentMarker.Value, out var value))
		{
			return;
		}
		float num = 18f * _plugin.Config.IconScale;
		float num2 = 4f;
		try
		{
			ITextureProvider textureProvider = Service.TextureProvider;
			GameIconLookup val = (GameIconLookup)(value);
			ISharedImmediateTexture fromGameIcon = textureProvider.GetFromGameIcon(ref val);
			if (fromGameIcon != null && fromGameIcon.GetWrapOrEmpty().Handle != (IntPtr)IntPtr.Zero)
			{
				Vector2 vector = new Vector2(buttonPos.X + (buttonSize.X - num) * 0.5f, buttonPos.Y + buttonSize.Y - num - num2);
				drawList.AddImage(fromGameIcon.GetWrapOrEmpty().Handle, vector, vector + new Vector2(num), Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(new Vector4(1f, 1f, 1f, 1f)));
			}
		}
		catch
		{
		}
	}

	private void ToggleMarkerPreviewMode()
	{
		InvalidateSavedIconToggleStateIfConfigChanged();
		if (_savedCenterIconMode.HasValue)
		{
			ApplyCenterIconDisplayMode(_savedCenterIconMode.Value);
			ClearSavedIconToggleState();
			_plugin.SaveConfig();
		}
		else
		{
			CenterIconDisplayMode currentCenterIconDisplayMode = GetCurrentCenterIconDisplayMode();
			_savedCenterIconMode = currentCenterIconDisplayMode;
			ApplyCenterIconDisplayMode(GetToggledCenterIconDisplayMode(currentCenterIconDisplayMode));
			_plugin.SaveConfig();
		}
	}

	private void InvalidateSavedIconToggleStateIfConfigChanged()
	{
		if (_savedCenterIconMode.HasValue && GetCurrentCenterIconDisplayMode() != GetToggledCenterIconDisplayMode(_savedCenterIconMode.Value))
		{
			ClearSavedIconToggleState();
		}
	}

	private CenterIconDisplayMode GetCurrentCenterIconDisplayMode()
	{
		if (_plugin.Config.ShowMarkerIcon && !_plugin.Config.ShowSkillIcon)
		{
			return CenterIconDisplayMode.Marker;
		}
		if (_plugin.Config.ShowSkillIcon)
		{
			return CenterIconDisplayMode.Skill;
		}
		return CenterIconDisplayMode.None;
	}

	private CenterIconDisplayMode GetToggledCenterIconDisplayMode(CenterIconDisplayMode currentMode)
	{
		if (currentMode != CenterIconDisplayMode.Marker)
		{
			return CenterIconDisplayMode.Marker;
		}
		return CenterIconDisplayMode.Skill;
	}

	private void ApplyCenterIconDisplayMode(CenterIconDisplayMode mode)
	{
		_plugin.Config.ShowSkillIcon = mode == CenterIconDisplayMode.Skill;
		_plugin.Config.ShowMarkerIcon = mode == CenterIconDisplayMode.Marker;
	}

	private void ClearSavedIconToggleState()
	{
		_savedCenterIconMode = null;
	}

	private void ToggleAutoMarkerSkillMode()
	{
		bool flag = !_plugin.Config.AutoMarkerSkillPriority;
		if (flag)
		{
			_plugin.Config.SavedSkillIconBeforeAuto = _plugin.Config.ShowSkillIcon;
			_plugin.Config.SavedMarkerIconBeforeAuto = _plugin.Config.ShowMarkerIcon;
			_plugin.Config.ShowSkillIcon = true;
			_plugin.Config.ShowMarkerIcon = true;
		}
		else
		{
			_plugin.Config.ShowSkillIcon = _plugin.Config.SavedSkillIconBeforeAuto;
			_plugin.Config.ShowMarkerIcon = _plugin.Config.SavedMarkerIconBeforeAuto;
		}
		_plugin.Config.AutoMarkerSkillPriority = flag;
		_plugin.SaveConfig();
	}
}
