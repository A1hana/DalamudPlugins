#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Interface.Utility;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Graphics.Kernel;
using FFXIVClientStructs.FFXIV.Common.Math;
using Matrix4x4 = System.Numerics.Matrix4x4;
using Vector2 = System.Numerics.Vector2;
using Vector3 = System.Numerics.Vector3;
using Vector4 = System.Numerics.Vector4;

namespace TyniaPVPRadar;

public class OverlayRenderer : IDisposable
{
	private const float FixedLineClipThreshold = 10f;

	private const float FixedLineClipEdgeScale = 1f;

	private readonly TyniaPVPRadar _plugin;

	private bool _isVisible = true;

	private Dictionary<ulong, Vector2> lastScreenPositions = new Dictionary<ulong, Vector2>();

	private Dictionary<ulong, Vector2> lastVelocities = new Dictionary<ulong, Vector2>();

	private HashSet<ulong> _seenIdsThisFrame = new HashSet<ulong>();

	private readonly List<ulong> _idsToRemoveScratch = new List<ulong>();

	private Dictionary<ulong, Vector2> _lastLineStartPositions = new Dictionary<ulong, Vector2>();

	private Dictionary<ulong, Vector2> _lastLineStartVelocities = new Dictionary<ulong, Vector2>();

	private Dictionary<ulong, Vector2> _lastLineEndPositions = new Dictionary<ulong, Vector2>();

	private Dictionary<ulong, Vector2> _lastLineEndVelocities = new Dictionary<ulong, Vector2>();

	private Dictionary<ulong, bool> _lastLineStartClippedStates = new Dictionary<ulong, bool>();

	private Dictionary<ulong, bool> _lastLineEndClippedStates = new Dictionary<ulong, bool>();

	private HashSet<ulong> _seenLineIdsThisFrame = new HashSet<ulong>();

	private readonly List<ulong> _lineIdsToRemoveScratch = new List<ulong>();

	public OverlayRenderer(TyniaPVPRadar plugin)
	{
		_plugin = plugin;
	}

	public void Draw()
	{
		if (!_isVisible || _plugin.PlayerManager.IsInitialPvpScanPending || (!_plugin.PlayerManager.IsInPvpZone && !_plugin.Config.EnableOnAllMaps))
		{
			return;
		}
		_seenIdsThisFrame.Clear();
		_seenLineIdsThisFrame.Clear();
		ImDrawListPtr backgroundDrawList = ImGui.GetBackgroundDrawList();
		ImGuiViewportPtr mainViewport = ImGuiHelpers.MainViewport;
		Vector2 pos = mainViewport.Pos;
		mainViewport = ImGuiHelpers.MainViewport;
		Vector2 size = mainViewport.Size;
		DrawLines(backgroundDrawList, pos, size);
		DrawEnemyDots(backgroundDrawList, pos, size);
		DrawFriendlyDots(backgroundDrawList, pos, size);
		DrawSelfDot(backgroundDrawList, pos, size);
		_idsToRemoveScratch.Clear();
		foreach (ulong key in lastScreenPositions.Keys)
		{
			if (!_seenIdsThisFrame.Contains(key))
			{
				_idsToRemoveScratch.Add(key);
			}
		}
		foreach (ulong item in _idsToRemoveScratch)
		{
			lastScreenPositions.Remove(item);
			lastVelocities.Remove(item);
		}
		_lineIdsToRemoveScratch.Clear();
		foreach (ulong key2 in _lastLineStartPositions.Keys)
		{
			if (!_seenLineIdsThisFrame.Contains(key2))
			{
				_lineIdsToRemoveScratch.Add(key2);
			}
		}
		foreach (ulong item2 in _lineIdsToRemoveScratch)
		{
			_lastLineStartPositions.Remove(item2);
			_lastLineStartVelocities.Remove(item2);
			_lastLineEndPositions.Remove(item2);
			_lastLineEndVelocities.Remove(item2);
			_lastLineStartClippedStates.Remove(item2);
			_lastLineEndClippedStates.Remove(item2);
		}
	}

	private bool TryGetVisibleScreenPosition(IGameObject obj, out Vector2 screenPos)
	{
		screenPos = Vector2.Zero;
		if (obj.Address == (IntPtr)IntPtr.Zero)
		{
			return false;
		}
		try
		{
			Vector2 vector = default(Vector2);
			bool num = Service.GameGui.WorldToScreen(obj.Position, out vector);
			screenPos = new Vector2(vector.X, vector.Y);
			if (!num || float.IsNaN(screenPos.X) || float.IsNaN(screenPos.Y) || float.IsInfinity(screenPos.X) || float.IsInfinity(screenPos.Y))
			{
				screenPos = Vector2.Zero;
				return false;
			}
			screenPos = ApplyAdaptiveSmoothing(obj.GameObjectId, screenPos, lastScreenPositions, lastVelocities);
			_seenIdsThisFrame.Add(obj.GameObjectId);
			return true;
		}
		catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
		{
			return false;
		}
	}

	private static void DrawDot(ImDrawListPtr drawList, Vector2 screenPos, float dotSize, Vector4 color, Vector2 viewportMin, Vector2 viewportMax)
	{
		int circleSegments = GetCircleSegments(dotSize);
		drawList.PushClipRect(viewportMin, viewportMax, false);
		drawList.AddCircleFilled(screenPos, dotSize, ImGui.GetColorU32(color), circleSegments);
		drawList.PopClipRect();
	}

	private static int GetCircleSegments(float dotSize)
	{
		if (dotSize <= 3f)
		{
			return 8;
		}
		if (dotSize <= 6f)
		{
			return 12;
		}
		if (dotSize <= 10f)
		{
			return 16;
		}
		if (dotSize <= 16f)
		{
			return 20;
		}
		if (dotSize <= 22f)
		{
			return 24;
		}
		return 28;
	}

	private void DrawEnemyDots(ImDrawListPtr drawList, Vector2 viewportPos, Vector2 viewportSize)
	{
		if (!_plugin.Config.ShowEnemyDots)
		{
			return;
		}
		float dotOpacity = _plugin.Config.DotOpacity;
		float dotSize = _plugin.Config.DotSize;
		Vector2 viewportMax = viewportPos + viewportSize;
		foreach (PlayerInfo hostilePlayer in _plugin.PlayerManager.HostilePlayers)
		{
			if (hostilePlayer.Object != null && ((IGameObject)hostilePlayer.Object).Address != (IntPtr)IntPtr.Zero && IsAlive((IGameObject)(object)hostilePlayer.Object) && TryGetVisibleScreenPosition((IGameObject)(object)hostilePlayer.Object, out var screenPos))
			{
				Vector4 allianceColor = GetAllianceColor(hostilePlayer.阵营);
				allianceColor.W = dotOpacity;
				DrawDot(drawList, screenPos, dotSize, allianceColor, viewportPos, viewportMax);
			}
		}
	}

	private void DrawFriendlyDots(ImDrawListPtr drawList, Vector2 viewportPos, Vector2 viewportSize)
	{
		if (!_plugin.Config.ShowFriendlyDots)
		{
			return;
		}
		float dotOpacity = _plugin.Config.DotOpacity;
		float dotSize = _plugin.Config.DotSize;
		Vector2 viewportMax = viewportPos + viewportSize;
		if (!_plugin.PlayerManager.IsInPvpZone)
		{
			_ = 1;
		}
		else
			_ = Service.ClientState.TerritoryType == 250;
		IPlayerCharacter localPlayer = Service.ObjectTable.LocalPlayer;
		ulong num = 0uL;
		if (localPlayer != null && ((IGameObject)localPlayer).Address != (IntPtr)IntPtr.Zero)
		{
			try
			{
				num = ((IGameObject)localPlayer).GameObjectId;
			}
			catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
			{
				return;
			}
		}
		foreach (PlayerInfo allPlayer in _plugin.PlayerManager.AllPlayers)
		{
			if (allPlayer.IsHostile || allPlayer.Object == null || ((IGameObject)allPlayer.Object).Address == (IntPtr)IntPtr.Zero)
			{
				continue;
			}
			try
			{
				if (num != 0L && ((IGameObject)allPlayer.Object).GameObjectId == num)
				{
					continue;
				}
			}
			catch (Exception ex2) when (((ex2 is AccessViolationException || ex2 is NullReferenceException) ? 1 : 0) != 0)
			{
				continue;
			}
			if (IsAlive((IGameObject)(object)allPlayer.Object) && TryGetVisibleScreenPosition((IGameObject)(object)allPlayer.Object, out var screenPos))
			{
				Vector4 color = (_plugin.Config.FriendlyDotsUseSelfColor ? _plugin.Config.SelfDotColor : GetAllianceColor(allPlayer.阵营));
				color.W = dotOpacity;
				DrawDot(drawList, screenPos, dotSize, color, viewportPos, viewportMax);
			}
		}
	}

	private void DrawSelfDot(ImDrawListPtr drawList, Vector2 viewportPos, Vector2 viewportSize)
	{
		if (_plugin.Config.ShowSelfDot)
		{
			IPlayerCharacter localPlayer = Service.ObjectTable.LocalPlayer;
			if (localPlayer != null && IsAlive((IGameObject)(object)localPlayer) && TryGetVisibleScreenPosition((IGameObject)(object)localPlayer, out var screenPos))
			{
				Vector4 selfDotColor = _plugin.Config.SelfDotColor;
				selfDotColor.W = _plugin.Config.DotOpacity;
				Vector2 viewportMax = viewportPos + viewportSize;
				DrawDot(drawList, screenPos, _plugin.Config.DotSize, selfDotColor, viewportPos, viewportMax);
			}
		}
	}

	private void DrawLines(ImDrawListPtr drawList, Vector2 viewportPos, Vector2 viewportSize)
	{
		if (!_plugin.Config.Show3DLines)
		{
			return;
		}
		IPlayerCharacter localPlayer = Service.ObjectTable.LocalPlayer;
		if (localPlayer == null || ((IGameObject)localPlayer).Address == (IntPtr)IntPtr.Zero)
		{
			return;
		}
		Vector3 position;
		try
		{
			position = ((IGameObject)localPlayer).Position;
		}
		catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
		{
			return;
		}
		foreach (连线数据 line in _plugin.Config.Lines)
		{
			if (_plugin.PlayerManager.PlayersByCID.TryGetValue(line.TargetCID, out PlayerInfo value) && value != null && value.Object != null && ((IGameObject)value.Object).Address != (IntPtr)IntPtr.Zero)
			{
				Vector3 position2;
				try
				{
					position2 = ((IGameObject)value.Object).Position;
				}
				catch (Exception ex2) when (((ex2 is AccessViolationException || ex2 is NullReferenceException) ? 1 : 0) != 0)
				{
					continue;
				}
				if (TryProjectWorldLineToScreen(position, position2, viewportPos, viewportSize, 10f, 1f, out var startClipped, out var endClipped, out var screenStart, out var screenEnd))
				{
					screenStart = GetStableLinePosition(line.TargetCID, screenStart, startClipped, _lastLineStartClippedStates, _lastLineStartPositions, _lastLineStartVelocities);
					screenEnd = GetStableLinePosition(line.TargetCID, screenEnd, endClipped, _lastLineEndClippedStates, _lastLineEndPositions, _lastLineEndVelocities);
					Vector4 colour = (value.IsHostile ? _plugin.Config.EnemyLineColor : _plugin.Config.LineColor);
					colour.W = _plugin.Config.LineOpacity;
					DrawClippedLine(drawList, screenStart, screenEnd, colour, _plugin.Config.LineThickness, viewportPos, viewportSize);
				}
			}
		}
	}

	private static Vector2 ApplyAdaptiveSmoothing(ulong key, Vector2 currentPos, Dictionary<ulong, Vector2> positionCache, Dictionary<ulong, Vector2> velocityCache)
	{
		if (positionCache.TryGetValue(key, out var value))
		{
			Vector2 vector = currentPos - value;
			if (velocityCache.TryGetValue(key, out var value2))
			{
				vector = Vector2.Lerp(value2, vector, 0.5f);
			}
			velocityCache[key] = vector;
			float num = vector.Length();
			float amount = ((num < 2f) ? 0.3f : ((num < 10f) ? 0.5f : ((!(num < 50f)) ? 0.9f : 0.7f)));
			currentPos = Vector2.Lerp(value, currentPos, amount);
		}
		positionCache[key] = currentPos;
		return currentPos;
	}

	private Vector2 SmoothLinePosition(ulong lineId, Vector2 screenPos, Dictionary<ulong, Vector2> positionCache, Dictionary<ulong, Vector2> velocityCache)
	{
		screenPos = ApplyAdaptiveSmoothing(lineId, screenPos, positionCache, velocityCache);
		_seenLineIdsThisFrame.Add(lineId);
		return screenPos;
	}

	private Vector2 GetStableLinePosition(ulong lineId, Vector2 screenPos, bool isClipped, Dictionary<ulong, bool> clippedStateCache, Dictionary<ulong, Vector2> positionCache, Dictionary<ulong, Vector2> velocityCache)
	{
		_seenLineIdsThisFrame.Add(lineId);
		bool value;
		bool num = clippedStateCache.TryGetValue(lineId, out value);
		clippedStateCache[lineId] = isClipped;
		if (num && value != isClipped)
		{
			velocityCache.Remove(lineId);
			positionCache[lineId] = screenPos;
			return screenPos;
		}
		return SmoothLinePosition(lineId, screenPos, positionCache, velocityCache);
	}

	private unsafe static bool TryProjectWorldLineToScreen(Vector3 startWorld, Vector3 endWorld, Vector2 viewportPos, Vector2 viewportSize, float clipThreshold, float edgeScale, out bool startClipped, out bool endClipped, out Vector2 screenStart, out Vector2 screenEnd)
	{
		startClipped = false;
		endClipped = false;
		screenStart = Vector2.Zero;
		screenEnd = Vector2.Zero;
		Camera* activeCamera = CameraManager.Instance()->GetActiveCamera();
		if (activeCamera == null)
		{
			return false;
		}
		Vector3 vector = new Vector3(activeCamera->LastPosition.X, activeCamera->LastPosition.Y, activeCamera->LastPosition.Z);
		Vector3 value = new Vector3(activeCamera->LastLookAtVector.X, activeCamera->LastLookAtVector.Y, activeCamera->LastLookAtVector.Z) - vector;
		if (value.LengthSquared() <= 0.0001f)
		{
			return false;
		}
		value = Vector3.Normalize(value);
		var gameMatrix = Control.Instance()->ViewProjectionMatrix;
		Matrix4x4 viewProjectionMatrix = new Matrix4x4(gameMatrix.M11, gameMatrix.M12, gameMatrix.M13, gameMatrix.M14,
			gameMatrix.M21, gameMatrix.M22, gameMatrix.M23, gameMatrix.M24,
			gameMatrix.M31, gameMatrix.M32, gameMatrix.M33, gameMatrix.M34,
			gameMatrix.M41, gameMatrix.M42, gameMatrix.M43, gameMatrix.M44);
		if (!TryTransformWorldToClip(startWorld, viewProjectionMatrix, out var clipPos) || !TryTransformWorldToClip(endWorld, viewProjectionMatrix, out var endClip))
		{
			return false;
		}
		float clipNearThreshold = GetClipNearThreshold(vector, value, viewProjectionMatrix, clipPos, endClip, clipThreshold, edgeScale);
		if (!ClipProjectedLineToNear(ref clipPos, ref endClip, clipNearThreshold, out startClipped, out endClipped))
		{
			return false;
		}
		if (!TryProjectClipToScreen(clipPos, viewportPos, out screenStart) || !TryProjectClipToScreen(endClip, viewportPos, out screenEnd))
		{
			return false;
		}
		return CohenSutherlandClipStatic(ref screenStart, ref screenEnd, viewportPos, viewportPos + viewportSize);
	}

	private static bool TryTransformWorldToClip(Vector3 worldPos, Matrix4x4 mat, out Vector4 clipPos)
	{
		float x = worldPos.X;
		float y = worldPos.Y;
		float z = worldPos.Z;
		clipPos = new Vector4(x * mat.M11 + y * mat.M21 + z * mat.M31 + mat.M41, x * mat.M12 + y * mat.M22 + z * mat.M32 + mat.M42, x * mat.M13 + y * mat.M23 + z * mat.M33 + mat.M43, x * mat.M14 + y * mat.M24 + z * mat.M34 + mat.M44);
		if (float.IsFinite(clipPos.X) && float.IsFinite(clipPos.Y) && float.IsFinite(clipPos.Z))
		{
			return float.IsFinite(clipPos.W);
		}
		return false;
	}

	private static float GetClipNearThreshold(Vector3 cameraPosition, Vector3 forward, Matrix4x4 mat, Vector4 startClip, Vector4 endClip, float clipThreshold, float edgeScale)
	{
		if (TryTransformWorldToClip(cameraPosition + forward, mat, out var clipPos))
		{
			float num = MathF.Abs(clipPos.Z);
			if (float.IsFinite(num) && num > 0.0001f)
			{
				float y = MathF.Max(num * 0.02f, 0.002f);
				float num2 = MathF.Max(num * clipThreshold, y);
				Vector4 startClip2 = startClip;
				Vector4 endClip2 = endClip;
				if (!ClipProjectedLineToNear(ref startClip2, ref endClip2, num2, out var _, out var _))
				{
					return num2;
				}
				float horizontalClipFactor = GetHorizontalClipFactor(GetHorizontalEdgeWeight(startClip2, endClip2), edgeScale);
				return num2 * horizontalClipFactor;
			}
		}
		return 0.002f;
	}

	private static float GetHorizontalEdgeWeight(Vector4 startClip, Vector4 endClip)
	{
		Vector4 vector = ((startClip.W <= endClip.W) ? startClip : endClip);
		if (vector.W <= 0.0001f || !float.IsFinite(vector.W))
		{
			return 0f;
		}
		float num = vector.X / vector.W;
		if (!float.IsFinite(num))
		{
			return 0f;
		}
		return MathF.Pow(Math.Clamp(MathF.Abs(num), 0f, 1f), 1.35f);
	}

	private static float GetHorizontalClipFactor(float edgeWeight, float edgeScale)
	{
		edgeScale = Math.Clamp(edgeScale, 0.01f, 1f);
		return 1f - (1f - edgeScale) * edgeWeight;
	}

	private static bool ClipProjectedLineToNear(ref Vector4 startClip, ref Vector4 endClip, float nearClip, out bool startClipped, out bool endClipped)
	{
		startClipped = false;
		endClipped = false;
		bool flag = false;
		bool flag2 = false;
		if (startClip.W > endClip.W)
		{
			Vector4 vector = endClip;
			Vector4 vector2 = startClip;
			startClip = vector;
			endClip = vector2;
			flag = true;
		}
		if (endClip.W < nearClip)
		{
			if (flag)
			{
				Vector4 vector2 = endClip;
				Vector4 vector = startClip;
				startClip = vector2;
				endClip = vector;
			}
			return false;
		}
		if (startClip.W < nearClip)
		{
			float num = endClip.W - startClip.W;
			if (MathF.Abs(num) <= 0.0001f)
			{
				if (flag)
				{
					Vector4 vector = endClip;
					Vector4 vector2 = startClip;
					startClip = vector;
					endClip = vector2;
				}
				return false;
			}
			float value = (nearClip - startClip.W) / num;
			value = Math.Clamp(value, 0f, 1f);
			startClip = Vector4.Lerp(startClip, endClip, value);
			flag2 = true;
		}
		if (flag)
		{
			Vector4 vector2 = endClip;
			Vector4 vector = startClip;
			startClip = vector2;
			endClip = vector;
			endClipped = flag2;
		}
		else
		{
			startClipped = flag2;
		}
		return true;
	}

	private unsafe static bool TryProjectClipToScreen(Vector4 clipPos, Vector2 viewportPos, out Vector2 screenPos)
	{
		Device* ptr = Device.Instance();
		if (ptr == null)
		{
			screenPos = Vector2.Zero;
			return false;
		}
		float w = clipPos.W;
		if (w <= 0.0001f || !float.IsFinite(w))
		{
			screenPos = Vector2.Zero;
			return false;
		}
		float num = 1f / w;
		float num2 = clipPos.X * num;
		float num3 = clipPos.Y * num;
		if (!float.IsFinite(num2) || !float.IsFinite(num3))
		{
			screenPos = Vector2.Zero;
			return false;
		}
		float num4 = ptr->Width;
		float num5 = ptr->Height;
		float num6 = num4 * 0.5f;
		float num7 = num5 * 0.5f;
		screenPos = new Vector2(num2 * num6 + num6 + viewportPos.X, num7 - num3 * num7 + viewportPos.Y);
		return true;
	}

	private static bool CohenSutherlandClipStatic(ref Vector2 p1, ref Vector2 p2, Vector2 rectMin, Vector2 rectMax)
	{
		int num = ComputeOutCode(p1, rectMin, rectMax);
		int num2 = ComputeOutCode(p2, rectMin, rectMax);
		while (true)
		{
			if ((num | num2) == 0)
			{
				return true;
			}
			if ((num & num2) != 0)
			{
				break;
			}
			float x = 0f;
			float y = 0f;
			int num3 = ((num != 0) ? num : num2);
			if ((num3 & 8) != 0)
			{
				x = p1.X + (p2.X - p1.X) * (rectMax.Y - p1.Y) / (p2.Y - p1.Y);
				y = rectMax.Y;
			}
			else if ((num3 & 4) != 0)
			{
				x = p1.X + (p2.X - p1.X) * (rectMin.Y - p1.Y) / (p2.Y - p1.Y);
				y = rectMin.Y;
			}
			else if ((num3 & 2) != 0)
			{
				y = p1.Y + (p2.Y - p1.Y) * (rectMax.X - p1.X) / (p2.X - p1.X);
				x = rectMax.X;
			}
			else if ((num3 & 1) != 0)
			{
				y = p1.Y + (p2.Y - p1.Y) * (rectMin.X - p1.X) / (p2.X - p1.X);
				x = rectMin.X;
			}
			if (num3 == num)
			{
				p1 = new Vector2(x, y);
				num = ComputeOutCode(p1, rectMin, rectMax);
			}
			else
			{
				p2 = new Vector2(x, y);
				num2 = ComputeOutCode(p2, rectMin, rectMax);
			}
		}
		return false;
		static int ComputeOutCode(Vector2 vector, Vector2 min, Vector2 max)
		{
			int num4 = 0;
			if (vector.X < min.X)
			{
				num4 |= 1;
			}
			else if (vector.X > max.X)
			{
				num4 |= 2;
			}
			if (vector.Y < min.Y)
			{
				num4 |= 4;
			}
			else if (vector.Y > max.Y)
			{
				num4 |= 8;
			}
			return num4;
		}
	}

	private void DrawClippedLine(ImDrawListPtr drawList, Vector2 p1, Vector2 p2, Vector4 colour, float thickness, Vector2 viewportPos, Vector2 viewportSize)
	{
		if (!float.IsNaN(p1.X) && !float.IsNaN(p1.Y) && !float.IsInfinity(p1.X) && !float.IsInfinity(p1.Y) && !float.IsNaN(p2.X) && !float.IsNaN(p2.Y) && !float.IsInfinity(p2.X) && !float.IsInfinity(p2.Y))
		{
			drawList.PushClipRect(viewportPos, viewportPos + viewportSize, false);
			drawList.AddLine(p1, p2, ImGui.GetColorU32(colour), thickness);
			drawList.PopClipRect();
		}
	}

	private Vector4 GetAllianceColor(阵营类型 alliance)
	{
		return alliance switch
		{
			阵营类型.双蛇党 => _plugin.Config.TwinAdderColor, 
			阵营类型.恒辉队 => _plugin.Config.ImmortalFlamesColor, 
			阵营类型.黑涡团 => _plugin.Config.MaelstromColor, 
			_ => new Vector4(0.5f, 0.5f, 0.5f, 1f), 
		};
	}

	private bool IsAlive(IGameObject obj)
	{
		if (obj.Address == (IntPtr)IntPtr.Zero)
		{
			return false;
		}
		try
		{
			if (obj.IsDead)
			{
				return false;
			}
			ICharacter val = (ICharacter)(object)((obj is ICharacter) ? obj : null);
			if (val != null && val.CurrentHp == 0)
			{
				return false;
			}
		}
		catch (Exception ex) when (((ex is AccessViolationException || ex is NullReferenceException) ? 1 : 0) != 0)
		{
			return false;
		}
		return true;
	}

	public void Dispose()
	{
		ClearScreenPositionCache();
	}

	public void ClearScreenPositionCache()
	{
		lastScreenPositions.Clear();
		lastVelocities.Clear();
		_seenIdsThisFrame.Clear();
		_lastLineStartPositions.Clear();
		_lastLineStartVelocities.Clear();
		_lastLineEndPositions.Clear();
		_lastLineEndVelocities.Clear();
		_lastLineStartClippedStates.Clear();
		_lastLineEndClippedStates.Clear();
		_seenLineIdsThisFrame.Clear();
	}
}
