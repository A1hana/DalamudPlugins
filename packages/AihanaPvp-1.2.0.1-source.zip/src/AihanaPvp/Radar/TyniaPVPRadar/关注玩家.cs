#nullable disable warnings
using System;

namespace TyniaPVPRadar;

[Serializable]
[Obsolete("仅用于旧数据迁移，迁移完成后可删除")]
public class 关注玩家
{
	public ulong CID { get; set; }

	public string Name { get; set; } = string.Empty;

	public string CustomColor { get; set; } = "#FF0000";
}
