#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace TyniaPVPRadar;

public class MarkerPanel : Window
{
	private readonly TyniaPVPRadar _plugin;

	private bool _initialized;

	private DateTime _lastCheckTime = DateTime.MinValue;

	private bool _isActive;

	private readonly Dictionary<MarkerType, 标记配置> _configByType = new Dictionary<MarkerType, 标记配置>(Enum.GetValues<MarkerType>().Length);

	private int _configByTypeStamp = -1;

	private static readonly List<(MarkerType Type, string Name, string DisplayName)> AllMarkers = new List<(MarkerType, string, string)>
	{
		(MarkerType.Attack1, "Attack1", "攻击1"),
		(MarkerType.Attack2, "Attack2", "攻击2"),
		(MarkerType.Attack3, "Attack3", "攻击3"),
		(MarkerType.Attack4, "Attack4", "攻击4"),
		(MarkerType.Attack5, "Attack5", "攻击5"),
		(MarkerType.Attack6, "Attack6", "攻击6"),
		(MarkerType.Attack7, "Attack7", "攻击7"),
		(MarkerType.Attack8, "Attack8", "攻击8"),
		(MarkerType.Bind1, "Bind1", "锁链1"),
		(MarkerType.Bind2, "Bind2", "锁链2"),
		(MarkerType.Bind3, "Bind3", "锁链3"),
		(MarkerType.Ignore1, "Ignore1", "禁止1"),
		(MarkerType.Ignore2, "Ignore2", "禁止2"),
		(MarkerType.Square, "Square", "方块"),
		(MarkerType.Circle, "Circle", "圆圈"),
		(MarkerType.Cross, "Cross", "十字"),
		(MarkerType.Triangle, "Triangle", "三角")
	};

	public MarkerPanel(TyniaPVPRadar plugin)
		: base("标记面板")
	{
		_plugin = plugin;
		((Window)this).RespectCloseHotkey = true;
		((Window)this).Size = new Vector2(_plugin.Config.MarkerPanelWidth, _plugin.Config.MarkerPanelHeight);
		((Window)this).SizeCondition = (ImGuiCond)4;
		InitializeMarkerConfigs();
	}

	private void InitializeMarkerConfigs()
	{
		if (_initialized)
		{
			return;
		}
		foreach (var allMarker in AllMarkers)
		{
			MarkerType item = allMarker.Type;
			if (!_configByType.ContainsKey(item))
			{
				_plugin.Config.MarkerConfigs.Add(new 标记配置
				{
					标记类型 = item,
					玩家CID = null,
					玩家名称 = string.Empty,
					清除模式 = false
				});
			}
		}
		_initialized = true;
		RebuildConfigByTypeIfNeeded();
	}

	private void RebuildConfigByTypeIfNeeded()
	{
		List<标记配置> markerConfigs = _plugin.Config.MarkerConfigs;
		int num = markerConfigs.Count;
		foreach (标记配置 item in markerConfigs)
		{
			num = num * 397 + item.GetHashCode();
		}
		if (num == _configByTypeStamp)
		{
			return;
		}
		_configByType.Clear();
		foreach (标记配置 item2 in markerConfigs)
		{
			_configByType[item2.标记类型] = item2;
		}
		_configByTypeStamp = num;
	}

	public override void Draw()
	{
		InitializeMarkerConfigs();
		RebuildConfigByTypeIfNeeded();
		if (_isActive)
		{
			CheckAndApplyMarkers();
		}
		if (ImGui.Button((ImU8String)(_isActive ? "停止" : "启用标记/清除标记"), new Vector2(-1f, 30f)))
		{
			_isActive = !_isActive;
		}
		ImGui.Spacing();
		ImGui.BeginChild((ImU8String)("MarkersList"), new Vector2(-1f, -1f), true, (ImGuiWindowFlags)0);
		foreach (var (key, _, displayName) in AllMarkers)
		{
			if (_configByType.TryGetValue(key, out 标记配置 value))
			{
				DrawMarkerRow(value, displayName);
			}
		}
		ImGui.EndChild();
	}

	private void DrawMarkerRow(标记配置 config, string displayName)
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		float cursorPosX = ImGui.GetCursorPosX();
		float num = cursorPosX + ImGui.GetContentRegionAvail().X;
		float markerLabelColumnWidth = GetMarkerLabelColumnWidth();
		float adaptiveButtonWidth = GetAdaptiveButtonWidth("选择目标", 60f);
		float adaptiveButtonWidth2 = GetAdaptiveButtonWidth("清除目标", 60f);
		float frameHeight = ImGui.GetFrameHeight();
		float x = ImGui.CalcTextSize((ImU8String)("清除标记"), false, -1f).X;
		float num2 = frameHeight + style.ItemInnerSpacing.X + x;
		ImGui.TextUnformatted((ImU8String)(displayName));
		ImGui.SameLine();
		ImGui.SetCursorPosX(cursorPosX + markerLabelColumnWidth);
		ImU8String val = default(ImU8String);
		val = new ImU8String(13, 1);
		val.AppendLiteral("选择目标##select_");
		val.AppendFormatted<MarkerType>(config.标记类型);
		if (ImGui.Button(val, new Vector2(adaptiveButtonWidth, 0f)))
		{
			_plugin.TargetSelectWindow.Show(config.标记类型, OnTargetSelected);
		}
		ImGui.SameLine();
		ImU8String val2 = default(ImU8String);
		val2 = new ImU8String(19, 1);
		val2.AppendLiteral("清除目标##clear_target_");
		val2.AppendFormatted<MarkerType>(config.标记类型);
		if (ImGui.Button(val2, new Vector2(adaptiveButtonWidth2, 0f)))
		{
			config.玩家CID = null;
			config.玩家名称 = string.Empty;
			config.服务器名称 = string.Empty;
			_plugin.SaveConfig();
		}
		ImGui.SameLine();
		float cursorPosX2 = ImGui.GetCursorPosX();
		float num3 = Math.Max(num - num2, cursorPosX2);
		float width = Math.Max(0f, num3 - cursorPosX2 - style.ItemSpacing.X);
		DrawClippedText(config.玩家名称, width);
		ImGui.SameLine(0f, style.ItemSpacing.X);
		ImGui.SetCursorPosX(num3);
		bool 清除模式 = config.清除模式;
		ImU8String val3 = default(ImU8String);
		val3 = new ImU8String(8, 1);
		val3.AppendLiteral("##clear_");
		val3.AppendFormatted<MarkerType>(config.标记类型);
		if (ImGui.Checkbox(val3, ref 清除模式))
		{
			config.清除模式 = 清除模式;
			_plugin.SaveConfig();
		}
		ImGui.SameLine(0f, style.ItemInnerSpacing.X);
		ImGui.TextUnformatted((ImU8String)("清除标记"));
		ImGui.Spacing();
	}

	private float GetMarkerLabelColumnWidth()
	{
		float num = 0f;
		foreach (var allMarker in AllMarkers)
		{
			float x = ImGui.CalcTextSize((ImU8String)(allMarker.DisplayName), false, -1f).X;
			if (x > num)
			{
				num = x;
			}
		}
		float num2 = num;
		ImGuiStylePtr style = ImGui.GetStyle();
		return num2 + style.ItemSpacing.X * 2f;
	}

	private float GetAdaptiveButtonWidth(string label, float minWidth)
	{
		ImGuiStylePtr style = ImGui.GetStyle();
		float x = ImGui.CalcTextSize((ImU8String)(label), false, -1f).X;
		return Math.Max(minWidth, x + style.FramePadding.X * 2f);
	}

	private void DrawClippedText(string text, float width)
	{
		float textLineHeight = ImGui.GetTextLineHeight();
		if (width <= 1f)
		{
			ImGui.Dummy(new Vector2(0f, textLineHeight));
			return;
		}
		string text2 = ClipTextToWidth(text, width);
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		ImGuiStylePtr style = ImGui.GetStyle();
		uint colorU = ImGui.GetColorU32(style.Colors[0]);
		windowDrawList.AddText(cursorScreenPos, colorU, (ImU8String)(text2));
		ImGui.Dummy(new Vector2(width, textLineHeight));
	}

	private string ClipTextToWidth(string text, float maxWidth)
	{
		if (string.IsNullOrEmpty(text) || ImGui.CalcTextSize((ImU8String)(text), false, -1f).X <= maxWidth)
		{
			return text;
		}
		if (ImGui.CalcTextSize((ImU8String)("..."), false, -1f).X > maxWidth)
		{
			return string.Empty;
		}
		for (int num = text.Length - 1; num > 0; num--)
		{
			string text2 = text.Substring(0, num) + "...";
			if (ImGui.CalcTextSize((ImU8String)(text2), false, -1f).X <= maxWidth)
			{
				return text2;
			}
		}
		return string.Empty;
	}

	private void OnTargetSelected(MarkerType markerType, PlayerInfo? player)
	{
		if (!_configByType.TryGetValue(markerType, out 标记配置 value))
		{
			return;
		}
		if (player != null)
		{
			标记配置 标记配置2 = null;
			foreach (KeyValuePair<MarkerType, 标记配置> item in _configByType)
			{
				标记配置 value2 = item.Value;
				if (value2.标记类型 != markerType && value2.玩家CID == player.CID)
				{
					标记配置2 = value2;
					break;
				}
			}
			if (标记配置2 != null)
			{
				标记配置2.玩家CID = null;
				标记配置2.玩家名称 = string.Empty;
				标记配置2.服务器名称 = string.Empty;
			}
			value.玩家CID = player.CID;
			value.玩家名称 = player.Name;
			value.服务器名称 = player.ServerName;
		}
		else
		{
			value.玩家CID = null;
			value.玩家名称 = string.Empty;
			value.服务器名称 = string.Empty;
		}
		_plugin.SaveConfig();
	}

	private void CheckAndApplyMarkers()
	{
		DateTime now = DateTime.Now;
		if ((now - _lastCheckTime).TotalMilliseconds < 200.0)
		{
			return;
		}
		_lastCheckTime = now;
		IReadOnlyDictionary<ulong, PlayerInfo> playersByCID = _plugin.PlayerManager.PlayersByCID;
		foreach (标记配置 markerConfig in _plugin.Config.MarkerConfigs)
		{
			PlayerInfo value2;
			if (markerConfig.清除模式)
			{
				try
				{
					if (markerConfig.玩家CID.HasValue && playersByCID.TryGetValue(markerConfig.玩家CID.Value, out var value))
					{
						_plugin.MarkerService.ClearAllMarkersOnPlayer(value);
					}
					else if (!markerConfig.玩家CID.HasValue)
					{
						_plugin.MarkerService.ClearMarkerType(markerConfig.标记类型);
					}
				}
				catch (Exception ex)
				{
					Service.Log.Error("清除标记失败: " + ex.Message, Array.Empty<object>());
				}
			}
			else if (markerConfig.玩家CID.HasValue && playersByCID.TryGetValue(markerConfig.玩家CID.Value, out value2))
			{
				try
				{
					_plugin.MarkerService.MarkPlayer(value2, markerConfig.标记类型);
				}
				catch (Exception ex2)
				{
					Service.Log.Error("标记失败: " + ex2.Message, Array.Empty<object>());
				}
			}
		}
	}

	public void ResetOnTerritoryChange()
	{
		_isActive = false;
		foreach (标记配置 markerConfig in _plugin.Config.MarkerConfigs)
		{
			markerConfig.玩家CID = null;
			markerConfig.玩家名称 = string.Empty;
			markerConfig.服务器名称 = string.Empty;
			markerConfig.清除模式 = false;
		}
		_plugin.SaveConfig();
	}
}
