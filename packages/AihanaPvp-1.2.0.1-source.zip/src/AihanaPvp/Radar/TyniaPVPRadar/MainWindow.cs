#nullable disable warnings
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Windowing;

namespace TyniaPVPRadar;

public class MainWindow : Window
{
	private readonly TyniaPVPRadar _plugin;

	private readonly TitleBarButton _settingsButton;

	private readonly TitleBarButton _lockButton;

	public MainWindow(TyniaPVPRadar plugin)
		: base("Aihana PVP 雷达###AihanaPvpRadarPanel", (ImGuiWindowFlags)24, false)
	{
		_plugin = plugin;
		((Window)this).IsOpen = false;
		((Window)this).TitleBarButtons.Clear();
		_settingsButton = new TitleBarButton
		{
			AvailableClickthrough = false,
			Click = delegate
			{
				_plugin.OpenSettings();
			},
			Icon = (FontAwesomeIcon)61459
		};
		if (_plugin.Config.ShowSettingsButtonInMainWindowTitleBar)
		{
			((Window)this).TitleBarButtons.Add(_settingsButton);
		}
		_lockButton = new TitleBarButton
		{
			AvailableClickthrough = false,
			Click = delegate
			{
				ToggleMainWindowLockState();
			},
			Icon = (FontAwesomeIcon)61596
		};
		if (_plugin.Config.ShowLockButtonInMainWindowTitleBar)
		{
			((Window)this).TitleBarButtons.Add(_lockButton);
		}
		((Window)this).Size = new Vector2(_plugin.Config.MainWindowWidth, _plugin.Config.MainWindowHeight);
		((Window)this).SizeCondition = (ImGuiCond)4;
	}

	public override void PreDraw()
	{
		((Window)this).Flags = (ImGuiWindowFlags)24;
		if (_plugin.Config.ShowSettingsButtonInMainWindowTitleBar)
		{
			if (!((Window)this).TitleBarButtons.Contains(_settingsButton))
			{
				((Window)this).TitleBarButtons.Insert(0, _settingsButton);
			}
		}
		else
		{
			((Window)this).TitleBarButtons.Remove(_settingsButton);
		}
		if (_plugin.Config.ShowLockButtonInMainWindowTitleBar)
		{
			if (!((Window)this).TitleBarButtons.Contains(_lockButton))
			{
				((Window)this).TitleBarButtons.Add(_lockButton);
			}
		}
		else
		{
			((Window)this).TitleBarButtons.Remove(_lockButton);
		}
		_lockButton.Icon = (FontAwesomeIcon)(IsMainWindowLocked() ? 61475 : 61596);
		if (!_plugin.Config.AllowMainWindowMoveAndResize)
		{
			((Window)this).Flags |= (ImGuiWindowFlags)4;
			((Window)this).Flags |= (ImGuiWindowFlags)2;
		}
		base.PreDraw();
	}

	public override void Draw()
	{
		float x = ImGui.GetContentRegionAvail().X;
		float mainWindowButtonHeight = _plugin.Config.MainWindowButtonHeight;
		if (ImGui.Button((ImU8String)("玩家列表"), new Vector2(x, mainWindowButtonHeight)))
		{
			((Window)_plugin.AllPlayersWindow).IsOpen = !((Window)_plugin.AllPlayersWindow).IsOpen;
		}
		ImGui.Spacing();
		if (ImGui.Button((ImU8String)("标记面板"), new Vector2(x, mainWindowButtonHeight)))
		{
			((Window)_plugin.MarkerPanel).IsOpen = !((Window)_plugin.MarkerPanel).IsOpen;
		}
		if (_plugin.Config.ShowWatchListInMain)
		{
			ImGui.Spacing();
			if (ImGui.Button((ImU8String)("关注列表"), new Vector2(x, mainWindowButtonHeight)))
			{
				((Window)_plugin.WatchListWindow).IsOpen = !((Window)_plugin.WatchListWindow).IsOpen;
			}
		}
		if (_plugin.Config.ShowLineListInMain)
		{
			ImGui.Spacing();
			if (ImGui.Button((ImU8String)("连线列表"), new Vector2(x, mainWindowButtonHeight)))
			{
				((Window)_plugin.LineListWindow).IsOpen = !((Window)_plugin.LineListWindow).IsOpen;
			}
		}
	}

	private bool IsMainWindowLocked()
	{
		return !_plugin.Config.AllowMainWindowMoveAndResize;
	}

	private void ToggleMainWindowLockState()
	{
		bool allowMainWindowMoveAndResize = IsMainWindowLocked();
		_plugin.Config.AllowMainWindowMoveAndResize = allowMainWindowMoveAndResize;
		_plugin.SaveConfig();
	}
}
