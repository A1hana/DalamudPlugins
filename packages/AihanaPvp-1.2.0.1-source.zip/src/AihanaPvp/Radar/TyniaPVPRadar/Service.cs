#nullable disable warnings
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace TyniaPVPRadar;

public class Service
{
	[PluginService]
	public static ICommandManager CommandManager { get; private set; }

	[PluginService]
	public static IPluginLog Log { get; private set; }

	[PluginService]
	public static IClientState ClientState { get; private set; }

	[PluginService]
	public static IGameGui GameGui { get; private set; }

	[PluginService]
	public static IFramework Framework { get; private set; }

	[PluginService]
	public static ISigScanner SigScanner { get; private set; }

	[PluginService]
	public static IDalamudPluginInterface PluginInterface { get; private set; }

	[PluginService]
	public static IDataManager DataManager { get; private set; }

	[PluginService]
	public static ITextureProvider TextureProvider { get; private set; }

	[PluginService]
	public static IObjectTable ObjectTable { get; private set; }

	[PluginService]
	public static IPartyList PartyList { get; private set; }

	[PluginService]
	public static ITargetManager TargetManager { get; private set; }

	[PluginService]
	public static IToastGui ToastGui { get; private set; }
}
