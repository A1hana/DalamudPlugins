#nullable disable warnings
using System;

namespace TyniaPVPRadar;

[Serializable]
public class 连线数据
{
	public ulong TargetCID { get; set; }

	public string TargetName { get; set; } = string.Empty;

	public string ServerName { get; set; } = string.Empty;

	public bool IsTemporary { get; set; }
}
