#nullable disable warnings
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Game.ClientState.Objects.SubKinds;

namespace TyniaPVPRadar;

public class PlayerInfo
{
	public ulong CID { get; set; }

	public string Name { get; set; } = string.Empty;

	public 阵营类型 阵营 { get; set; }

	public uint ClassJobId { get; set; }

	public string ClassJobName { get; set; } = string.Empty;

	public string ServerName { get; set; } = string.Empty;

	public 战意等级 战意等级 { get; set; }

	public IPlayerCharacter? Object { get; set; }

	public MarkerType? CurrentMarker { get; set; }

	public bool IsHostile { get; set; }

	public Vector3 Position { get; set; } = Vector3.Zero;

	public List<BuffInfo> Buffs { get; set; } = new List<BuffInfo>();

	public long LastSeenTick { get; set; }
}
