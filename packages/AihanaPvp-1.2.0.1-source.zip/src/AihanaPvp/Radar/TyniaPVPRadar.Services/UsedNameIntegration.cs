#nullable disable warnings
using System;
using Dalamud.Plugin;

namespace TyniaPVPRadar.Services;

public class UsedNameIntegration
{
	private const string PingIpc = "UsedNameReborn.Ping";

	private const string SearchIpc = "UsedNameReborn.SearchPlayerByCID";

	private readonly IDalamudPluginInterface _pluginInterface;

	private bool _cachedAvailable;

	private DateTime _lastCheck = DateTime.MinValue;

	private static readonly TimeSpan CheckInterval = TimeSpan.FromSeconds(1L);

	private const string TransferIpc = "UsedNameReborn.GetServerTransferHistoryByCID";

	public bool IsAvailable
	{
		get
		{
			if (DateTime.Now - _lastCheck < CheckInterval)
			{
				return _cachedAvailable;
			}
			_lastCheck = DateTime.Now;
			try
			{
				_pluginInterface.GetIpcSubscriber<bool>("UsedNameReborn.Ping").InvokeFunc();
				_cachedAvailable = true;
			}
			catch
			{
				_cachedAvailable = false;
			}
			return _cachedAvailable;
		}
	}

	public UsedNameIntegration(IDalamudPluginInterface pluginInterface)
	{
		_pluginInterface = pluginInterface;
	}

	public void SearchPlayerByCID(ulong contentId)
	{
		try
		{
			_pluginInterface.GetIpcSubscriber<ulong, bool>("UsedNameReborn.SearchPlayerByCID").InvokeFunc(contentId);
		}
		catch (Exception ex)
		{
			Service.Log.Debug("UsedNameReborn IPC not available: " + ex.Message, Array.Empty<object>());
		}
	}

	public void GetServerTransferHistoryByCID(ulong contentId)
	{
		try
		{
			_pluginInterface.GetIpcSubscriber<ulong, bool>("UsedNameReborn.GetServerTransferHistoryByCID").InvokeFunc(contentId);
		}
		catch (Exception ex)
		{
			Service.Log.Debug("UsedNameReborn IPC not available: " + ex.Message, Array.Empty<object>());
		}
	}
}
