using Newtonsoft.Json;
using TyniaPVPRadar;

namespace OPP;

internal static class ConfigurationLoader
{
    // Read legacy type metadata without loading either old plugin assembly.
    private static readonly JsonSerializerSettings Settings = new()
    {
        TypeNameHandling = TypeNameHandling.None,
        MetadataPropertyHandling = MetadataPropertyHandling.ReadAhead,
        ObjectCreationHandling = ObjectCreationHandling.Replace,
    };

    internal static Configuration Load(string configPath, Action<Exception, string> reportError)
    {
        Configuration config;
        if (File.Exists(configPath))
        {
            // A damaged merged config must not silently overwrite the user's settings.
            config = Read<Configuration>(configPath)
                ?? throw new InvalidDataException("整合版配置为空，请检查 " + configPath);
        }
        else
        {
            var directory = Path.GetDirectoryName(configPath)!;
            config = ReadLegacy<Configuration>(Path.Combine(directory, "0xPvpPlugin.json"), reportError) ?? new();
            config.Radar = ReadLegacy<PluginConfig>(Path.Combine(directory, "TyniaPVPRadar.json"), reportError) ?? new();
            config.Version = 1;
        }

        config.Selector ??= ReadLegacy<PvpAutoLb.Configuration>(Path.Combine(Path.GetDirectoryName(configPath)!, "PvpAutoLb.json"), reportError)
            ?? new PvpAutoLb.Configuration { AutoSelectLowestHp = config.AutoSelect, HpThresholdPercent = 50, AutoSelectRangeYalms = config.SelectDistance, PreventUnsafeNinjaTenchu = config.XDTZ };
        config.Normalize();
        return config;
    }

    private static T? Read<T>(string path) => JsonConvert.DeserializeObject<T>(File.ReadAllText(path), Settings);

    private static T? ReadLegacy<T>(string path, Action<Exception, string> reportError)
    {
        if (!File.Exists(path)) return default;
        try { return Read<T>(path); }
        catch (Exception exception)
        {
            reportError(exception, "无法读取旧配置：" + Path.GetFileName(path));
            return default;
        }
    }
}
