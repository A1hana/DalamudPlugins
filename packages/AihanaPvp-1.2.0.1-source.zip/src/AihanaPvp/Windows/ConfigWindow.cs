using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;
using System.Numerics;

namespace OPP.Windows;

internal sealed class ConfigWindow : Window
{
    private readonly Plugin plugin;
    private int requestedTab = -1;

    internal ConfigWindow(Plugin plugin) : base("Aihana PVP 助手###AihanaPvpSettings")
    {
        this.plugin = plugin;
        Size = new Vector2(720, 580);
        SizeCondition = ImGuiCond.FirstUseEver;
    }

    internal void OpenTab(int tab)
    {
        requestedTab = tab;
        IsOpen = true;
    }

    public override void Draw()
    {
        if (!ImGui.BeginTabBar("AihanaPvpTabs")) return;
        if (ImGui.BeginTabItem("忍者", FlagsFor(0)))
        {
            DrawNinja();
            ImGui.EndTabItem();
        }
        if (ImGui.BeginTabItem("暗黑骑士", FlagsFor(3)))
        {
            DrawDarkKnight();
            ImGui.EndTabItem();
        }
        if (ImGui.BeginTabItem("雷达", FlagsFor(1)))
        {
            DrawRadar();
            ImGui.EndTabItem();
        }
        if (ImGui.BeginTabItem("移动", FlagsFor(2)))
        {
            DrawMovement();
            ImGui.EndTabItem();
        }
        ImGui.EndTabBar();
        requestedTab = -1;
    }

    private ImGuiTabItemFlags FlagsFor(int tab)
        => requestedTab == tab ? ImGuiTabItemFlags.SetSelected : ImGuiTabItemFlags.None;

    private void DrawNinja()
    {
        ImGui.TextWrapped("已接入原选人插件的完整实现。选人、连杀、技能拦截和各项开关均在下面的面板中调整。");
        if (ImGui.Button("打开选人面板")) plugin.Selector.ToggleMainUi();
        ImGui.SameLine();
        if (ImGui.Button("打开选人设置")) plugin.Selector.ToggleConfigUi();
    }

    private void DrawRadar()
    {
        var radar = plugin.Radar;
        if (ImGui.Button("雷达面板")) radar.MainWindow.Toggle();
        ImGui.SameLine();
        if (ImGui.Button("玩家列表")) radar.AllPlayersWindow.Toggle();
        ImGui.SameLine();
        if (ImGui.Button("标记面板")) radar.MarkerPanel.Toggle();
        ImGui.SameLine();
        if (ImGui.Button("关注列表")) radar.WatchListWindow.Toggle();
        ImGui.SameLine();
        if (ImGui.Button("连线列表")) radar.LineListWindow.Toggle();
        ImGui.Separator();
        radar.SettingsWindow.Draw();
    }

    private void DrawDarkKnight()
    {
        var config = plugin.Configuration;
        var changed = ImGui.Checkbox("释放夜昏时自动调整最佳方向", ref config.DarkKnightAutoAim);
        ImGui.TextWrapped("仅暗黑骑士 PvP 生效。手动释放夜昏时重新扫描敌人，选择预计覆盖人数最多的方向，并取消当前目标与临时目标。");
        ImGui.Spacing();
        ImGui.TextUnformatted("攻击范围：角色前后各 15 米，总宽 6 米。");
        ImGui.TextWrapped("计算包含敌人碰撞体积，方向可落在任意角度；当前方向已最优时保持原方向。");
        changed |= ImGui.SliderFloat("允许的目标高差", ref config.DarkKnightMaxHeight, 0.5f, 30f, "%.1f m");
        ImGui.TextDisabled("人数按释放瞬间的位置估算，移动、高差与网络延迟可能影响实际命中。");
        if (!plugin.DarkKnightAimAvailable)
            ImGui.TextWrapped("方向辅助暂不可用，请查看 Dalamud 日志中的夜昏初始化信息。");
        if (plugin.LastEventideHits is { } hits)
            ImGui.TextUnformatted($"最近一次夜昏预计覆盖：{hits} 人");
        if (changed) config.Save();
    }

    private void DrawMovement()
    {
        var config = plugin.Configuration;
        var changed = false;
        var speed = config.Dspeed;
        if (ImGui.InputFloat("移速倍率", ref speed, 0.1f, 1f, "%.1f"))
        {
            config.Dspeed = float.IsFinite(speed) ? Math.Clamp(speed, 0.1f, 10f) : 1f;
            plugin.ApplySpeed();
        }
        ImGui.SameLine();
        if (ImGui.Button("恢复 1.0"))
        {
            config.Dspeed = 1f;
            plugin.ApplySpeed();
        }
        ImGui.SameLine();
        if (ImGui.Button("重新应用")) plugin.ApplySpeed();
        ImGui.TextWrapped(plugin.SpeedStatus);
        if (plugin.AppliedBaseSpeed is { } speedValue)
            ImGui.TextDisabled($"当前基础移速：{speedValue:0.00} 米/秒（读取值）");
        ImGui.TextDisabled("1.0 恢复修改前的速度。角色或区域加载完成后会重新应用所设倍率。");
        ImGui.Separator();
        changed |= ImGui.InputInt("上升距离", ref config.upDistance);
        ImGui.SameLine();
        if (ImGui.Button("上升")) plugin.MoveUp();
        changed |= ImGui.InputInt("下降距离", ref config.downDistance);
        ImGui.SameLine();
        if (ImGui.Button("下降")) plugin.MoveDown();
        if (ImGui.Button("恢复累计下降")) plugin.RestoreAccumulatedDown();
        ImGui.Text($"累计下降：{config.downDistanceAll}m");
        if (changed) config.Save();
    }
}
