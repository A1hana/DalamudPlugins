using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using OPP.Core;
using OPP.Interop;
using OPP.Windows;
using RadarModule = TyniaPVPRadar.TyniaPVPRadar;

namespace OPP;

public sealed class Plugin : IDalamudPlugin
{
    private readonly PluginServices services;
    private readonly WindowSystem windowSystem = new("AihanaPvp");
    private readonly List<string> registeredCommands = new();
    private readonly ConfigWindow configWindow;

    internal PvpAutoLb.Plugin Selector { get; private set; } = null!;

    private readonly DarkKnightEventideHook darkKnightHook;
    private readonly MovementController movement;
    private bool disposed;

    public Configuration Configuration { get; }
    internal RadarModule Radar { get; private set; } = null!;


    internal bool SpeedAvailable => movement.SpeedAvailable;
    internal string SpeedStatus => movement.SpeedStatus;
    internal float? AppliedBaseSpeed => movement.AppliedBaseSpeed;
    internal bool DarkKnightAimAvailable => darkKnightHook.Available;
    internal int? LastEventideHits => darkKnightHook.LastHitCount;

    public Plugin(
        IDalamudPluginInterface pluginInterface, ICommandManager commands,
        IFramework framework, IClientState clientState, IObjectTable objects,
        ITargetManager targets, IGameInteropProvider interop, ISigScanner sigScanner,
        IDataManager dataManager, ICondition condition, IGameGui gameGui,
        IChatGui chat, IPluginLog log)
    {
        services = new PluginServices(pluginInterface, commands, framework, clientState,
            objects, targets, interop, sigScanner, dataManager, condition, gameGui, chat, log);

        var conflicts = pluginInterface.InstalledPlugins
            .Where(plugin => plugin.IsLoaded && plugin.InternalName is "0xPvpPlugin" or "TyniaPVPRadar" or "PvpAutoLb")
            .Select(plugin => plugin.InternalName).ToArray();
        if (conflicts.Length > 0)
            throw new InvalidOperationException("请先停用旧插件，再启用整合版：" + string.Join("、", conflicts));

        Configuration = ConfigurationLoader.Load(pluginInterface.ConfigFile.FullName,
            (exception, message) => log.Warning(exception, message));
        Configuration.Initialize(config => pluginInterface.SavePluginConfig(config));

        movement = new MovementController(services);


        darkKnightHook = new DarkKnightEventideHook(services, Configuration);
        configWindow = new ConfigWindow(this);

        try
        {
            Selector = new PvpAutoLb.Plugin(pluginInterface, this, Configuration.Selector!, Configuration.Save);
            Radar = new RadarModule(pluginInterface, Configuration.Radar,
                Configuration.Save, () => OpenSettings(1), () => configWindow.IsOpen);
            windowSystem.AddWindow(configWindow);
            if (Configuration.Radar.SaveWindowStates && Configuration.Radar.SettingsWindowIsOpen)
                OpenSettings(1);

            RegisterCommand("/pvp", OnCommand, "打开 PVP 助手菜单");
            framework.Update += OnFrameworkUpdate;
            pluginInterface.UiBuilder.Draw += Draw;
            pluginInterface.UiBuilder.OpenConfigUi += OpenConfig;
            pluginInterface.UiBuilder.OpenMainUi += OpenConfig;
            Configuration.Save();
            if (MathF.Abs(Configuration.Dspeed - 1f) > 0.001f)
                movement.RequestSpeedMultiplier(Configuration.Dspeed);
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    private void RegisterCommand(string command, IReadOnlyCommandInfo.HandlerDelegate handler, string help)
    {
        if (services.Commands.AddHandler(command, new CommandInfo(handler) { HelpMessage = help }))
            registeredCommands.Add(command);
        else
            services.Log.Warning("[AihanaPvp] 命令已被其他插件占用：{Command}", command);
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        if (disposed) return;
        movement.Update();

        Radar.Update();
    }

    private void Draw()
    {
        if (disposed) return;
        windowSystem.Draw();
        Radar.Draw();
        Selector.Draw();
    }

    private void OpenConfig() => OpenSettings();
    internal void OpenSettings(int tab = 0) => configWindow.OpenTab(tab);

    private void OnCommand(string command, string arguments) => OpenSettings();

    internal void ApplySpeed()
    {
        movement.RequestSpeedMultiplier(Configuration.Dspeed);
        Configuration.Save();
    }

    internal void MoveUp()
    {
        if (movement.TryMoveVertical(Configuration.upDistance))
            services.Chat.Print($"[PVP 助手] 上升 {Configuration.upDistance}m");
    }

    internal void MoveDown()
    {
        if (!movement.TryMoveVertical(-Configuration.downDistance)) return;
        Configuration.downDistanceAll += Configuration.downDistance;
        Configuration.Save();
    }

    internal void RestoreAccumulatedDown()
    {
        if (Configuration.downDistanceAll == 0 || !movement.TryMoveVertical(Configuration.downDistanceAll)) return;
        Configuration.downDistanceAll = 0;
        Configuration.Save();
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        services.Framework.Update -= OnFrameworkUpdate;
        services.PluginInterface.UiBuilder.Draw -= Draw;
        services.PluginInterface.UiBuilder.OpenConfigUi -= OpenConfig;
        services.PluginInterface.UiBuilder.OpenMainUi -= OpenConfig;
        foreach (var command in registeredCommands) services.Commands.RemoveHandler(command);
        registeredCommands.Clear();
        try { darkKnightHook.Dispose(); }
        finally
        {
            try { Selector?.Dispose(); }
            finally
            {
                try { movement.RestoreDefaultSpeed(); }
                finally
                {
                    try { Radar?.Dispose(); }
                    finally { windowSystem.RemoveAllWindows(); }
                }
            }
        }
    }
}
