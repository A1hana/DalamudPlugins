using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace OPP;

internal sealed record PluginServices(
    IDalamudPluginInterface PluginInterface,
    ICommandManager Commands,
    IFramework Framework,
    IClientState ClientState,
    IObjectTable Objects,
    ITargetManager Targets,
    IGameInteropProvider Interop,
    ISigScanner SigScanner,
    IDataManager DataManager,
    ICondition Condition,
    IGameGui GameGui,
    IChatGui Chat,
    IPluginLog Log);
