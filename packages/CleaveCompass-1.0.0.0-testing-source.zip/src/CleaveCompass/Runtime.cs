using System.Diagnostics;
using CleaveCompass.Core;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using NativeObject = FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject;
using GameAction = Lumina.Excel.Sheets.Action;

namespace CleaveCompass;

internal sealed unsafe class Runtime(Services services, Configuration config)
{
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly MotionTracker motion = new();
    private double nextScan;
    private double nextErrorLog;
    private uint territory;
    private bool wasPvp;
    private ulong localId;
    private bool scanFailed;
    private int pendingSelection;
    private int pendingReset;
    public Scene Scene { get; private set; } = Scene.Empty("等待角色就绪");
    public string Feedback { get; private set; } = "选择形状，查看覆盖，按下选中按钮。";
    public bool Demo { get; set; }
    public double ScanDurationMs { get; private set; }
    public bool Alive => services.Objects.LocalPlayer is { IsDead: false, CurrentHp: > 0, Address: not 0 };
    public bool Transitioning => !services.Client.IsLoggedIn || services.Condition[ConditionFlag.BetweenAreas] ||
        services.Condition[ConditionFlag.BetweenAreas51] || services.Condition[ConditionFlag.OccupiedInCutSceneEvent] ||
        services.Condition[ConditionFlag.WatchingCutscene] || services.Condition[ConditionFlag.WatchingCutscene78];

    public void Update(bool force = false)
    {
        if (Interlocked.Exchange(ref pendingReset, 0) != 0) { motion.Clear(); nextScan = 0; }
        var request = Interlocked.Exchange(ref pendingSelection, 0);
        force |= request != 0;
        var now = clock.Elapsed.TotalSeconds;
        if (!force && now < nextScan) return;
        nextScan = now + config.ScanMilliseconds / 1000d;
        var started = Stopwatch.GetTimestamp();
        try
        {
            Capture(now);
            scanFailed = false;
        }
        catch (Exception ex)
        {
            motion.Clear();
            scanFailed = true;
            Scene = Scene.Empty("读取失败，已暂停选人；详情见 Dalamud 日志", now);
            if (now >= nextErrorLog) { services.Log.Error(ex, "CleaveCompass snapshot failed"); nextErrorLog = now + 10; }
        }
        ScanDurationMs = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
        if (request != 0)
        {
            try { SelectBest(request == 2); }
            catch (Exception ex)
            {
                services.Log.Error(ex, "CleaveCompass explicit selection failed");
                Notify("选人失败，详情见 Dalamud 日志", request == 2);
            }
        }
    }

    private void Capture(double now)
    {
        var local = services.Objects.LocalPlayer;
        if (!config.Enabled || !Alive || Transitioning || local == null)
        {
            motion.Clear();
            Scene = Scene.Empty(!config.Enabled ? "插件已停用" : "等待角色就绪或区域加载完成", now);
            return;
        }
        var isPvp = services.Client.IsPvP;
        if (territory != services.Client.TerritoryType || wasPvp != isPvp || localId != local.GameObjectId)
        {
            motion.Clear();
            territory = services.Client.TerritoryType;
            wasPvp = isPvp;
            localId = local.GameObjectId;
        }
        var player = new Actor(local.Position, local.HitboxRadius, local.Rotation, local.IsCasting);
        var profile = config.Active.Copy();
        // A configured but invalid skill must not silently disable native range/LoS checks.
        if (profile.ActionId != 0 && !TryAction(profile.ActionId, out _, out _, out _))
        {
            Scene = Scene.Empty("绑定技能无效，请清除技能 ID 或重新绑定", now);
            return;
        }
        var enemies = new List<Enemy>();
        foreach (var obj in services.Objects)
        {
            if (obj is not IBattleChara enemy || enemy.Address == 0 || enemy.GameObjectId == local.GameObjectId ||
                !enemy.IsTargetable || enemy.IsDead || enemy.CurrentHp == 0 || !Geometry.Finite(enemy.Position) ||
                !float.IsFinite(enemy.HitboxRadius) || enemy.HitboxRadius < 0) continue;
            // Auto-attack is a target-category probe only. It does not execute an attack.
            if (!ActionManager.CanUseActionOnTarget(7, (NativeObject*)enemy.Address)) continue;
            var engaged = isPvp || (enemy.StatusFlags & StatusFlags.InCombat) != 0;
            var predicted = motion.Observe(enemy.GameObjectId, enemy.Position, now, config.PredictionSeconds);
            var fact = new Enemy(enemy.GameObjectId, enemy.Name.ToString(), enemy.Position,
                predicted, enemy.HitboxRadius, engaged, true);
            var canAnchor = Geometry.InRange(player, fact, profile.CastRange, config.MaxHeight);
            if (canAnchor && profile.ActionId != 0)
                canAnchor = ActionManager.CanUseActionOnTarget(profile.ActionId, (NativeObject*)enemy.Address) &&
                    ActionManager.GetActionInRangeOrLoS(profile.ActionId, (NativeObject*)local.Address,
                        (NativeObject*)enemy.Address) == 0;
            enemies.Add(fact with { CanAnchor = canAnchor });
        }
        motion.Prune(now);
        var current = (services.Targets.SoftTarget ?? services.Targets.Target)?.GameObjectId ?? 0;
        var analysis = Planner.Analyze(enemies, player, profile, current, config.ProtectPulls && !isPvp,
            config.IncludeHitboxes, config.MaxHeight);
        var message = analysis.Best != null ? "覆盖是几何估算，请按实际技能参数使用" :
            analysis.RejectedPulls > 0 ? "附近方案可能误拉怪，已阻止推荐" : "没有范围内的合格敌人";
        Scene = new(player, enemies.ToArray(), profile, analysis, current, isPvp, message, now);
    }

    // UI and command callbacks only enqueue; native reads and target changes occur in Framework.Update.
    public void RequestSelect(bool chat = false) => Interlocked.Exchange(ref pendingSelection, chat ? 2 : 1);

    private void SelectBest(bool chat)
    {
        var local = services.Objects.LocalPlayer;
        var reason = SelectionPolicy.BlockReason(config.Enabled, Alive, Transitioning,
            local?.IsCasting ?? false, Demo, Scene.Analysis.Best);
        if (scanFailed) reason = "读取游戏数据失败，选人已暂停";
        if (reason != null) { Notify(reason, chat); return; }
        var plan = Scene.Analysis.Best!;
        var target = services.Objects.SearchById(plan.TargetId);
        if (target is not IBattleChara live || live.IsDead || !live.IsTargetable || live.CurrentHp == 0)
        { Notify("目标已经失效，请重新选择", chat); return; }
        services.Targets.SoftTarget = null;
        services.Targets.Target = target;
        Notify($"已选中 {plan.Name}，预计覆盖 {plan.Hits} 个目标", chat);
        nextScan = 0;
    }

    public bool TryAction(uint id, out string name, out int range, out int effectRange)
    {
        name = ""; range = 0; effectRange = 0;
        var row = services.Data.GetExcelSheet<GameAction>().GetRowOrDefault(id);
        if (row is not { } action || string.IsNullOrWhiteSpace(action.Name.ToString()) || !action.CanTargetHostile || action.TargetArea)
            return false;
        name = action.Name.ToString();
        range = action.Range;
        effectRange = action.EffectRange;
        return range > 0; // Self-centred / ground-target / special-range skills are not supported anchors.
    }

    public void Notify(string message, bool chat = false)
    {
        Feedback = message;
        if (chat) services.Chat.Print($"[群攻罗盘] {message}");
    }

    public void Reset() { Interlocked.Exchange(ref pendingReset, 1); Interlocked.Exchange(ref pendingSelection, 0); }
}
