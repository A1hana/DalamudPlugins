using CleaveCompass.UI;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace CleaveCompass;

public sealed class Plugin : IDalamudPlugin
{
    private readonly Services services;
    private readonly Configuration config;
    private readonly Runtime runtime;
    private readonly WindowSystem windows = new("CleaveCompass");
    private readonly MainWindow main;
    private readonly Overlay overlay;
    private readonly bool ownsShortCommand;
    private readonly bool ownsLongCommand;
    private bool disposed;

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commands, IFramework framework,
        IClientState clientState, IObjectTable objects, ITargetManager targets, ICondition condition,
        IGameGui gameGui, IDataManager data, IChatGui chat, IPluginLog log)
    {
        services = new(pluginInterface, commands, framework, clientState, objects, targets, condition, gameGui, data, chat, log);
        config = pluginInterface.GetPluginConfig() as Configuration ?? new();
        config.Normalize();
        runtime = new(services, config);
        main = new(config, runtime, Save);
        overlay = new(services, config, runtime);
        windows.AddWindow(main);
        windows.AddWindow(new HudWindow(config, runtime, () => main.IsOpen = true));
        var commandInfo = new CommandInfo(OnCommand)
        { HelpMessage = "群攻罗盘：pick 选中最佳目标；circle/cone/line 切换形状；hud/overlay 显示；on/off 开关；demo 演示。" };
        ownsShortCommand = commands.AddHandler("/cleave", commandInfo);
        ownsLongCommand = commands.AddHandler("/cleavecompass", commandInfo);
        if (!ownsShortCommand) log.Warning("/cleave is already registered; use /cleavecompass instead.");
        framework.Update += Update;
        pluginInterface.UiBuilder.Draw += Draw;
        pluginInterface.UiBuilder.OpenMainUi += Open;
        pluginInterface.UiBuilder.OpenConfigUi += Open;
    }

    private void Update(IFramework _) => runtime.Update();
    private void Draw() { windows.Draw(); overlay.Draw(); }
    private void Open() => main.IsOpen = true;
    private void Save() { config.Normalize(); services.Plugin.SavePluginConfig(config); runtime.Reset(); }

    private void OnCommand(string command, string args)
    {
        switch (args.Trim().ToLowerInvariant())
        {
            case "pick": runtime.RequestSelect(true); return;
            case "circle": config.ActiveProfile = 0; break;
            case "cone": config.ActiveProfile = 1; break;
            case "line": config.ActiveProfile = 2; break;
            case "hud": config.ShowHud = !config.ShowHud; break;
            case "overlay": config.ShowOverlay = !config.ShowOverlay; break;
            case "on": config.Enabled = true; break;
            case "off": config.Enabled = false; break;
            case "demo": main.IsOpen = true; runtime.Demo = !runtime.Demo; return;
            case "": main.Toggle(); return;
            default: runtime.Notify("命令：/cleave pick | circle | cone | line | hud | overlay | on | off | demo", true); return;
        }
        Save();
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        services.Framework.Update -= Update;
        services.Plugin.UiBuilder.Draw -= Draw;
        services.Plugin.UiBuilder.OpenMainUi -= Open;
        services.Plugin.UiBuilder.OpenConfigUi -= Open;
        if (ownsShortCommand) services.Commands.RemoveHandler("/cleave");
        if (ownsLongCommand) services.Commands.RemoveHandler("/cleavecompass");
        windows.RemoveAllWindows();
        runtime.Reset();
    }
}
