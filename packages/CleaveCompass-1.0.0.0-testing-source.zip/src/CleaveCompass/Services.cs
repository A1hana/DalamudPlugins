using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace CleaveCompass;

internal sealed record Services(IDalamudPluginInterface Plugin, ICommandManager Commands, IFramework Framework,
    IClientState Client, IObjectTable Objects, ITargetManager Targets, ICondition Condition,
    IGameGui Gui, IDataManager Data, IChatGui Chat, IPluginLog Log);
