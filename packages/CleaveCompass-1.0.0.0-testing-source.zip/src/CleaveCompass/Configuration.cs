using CleaveCompass.Core;
using Dalamud.Configuration;

namespace CleaveCompass;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    public bool Enabled = true;
    public bool ShowHud = true;
    public bool LockHud;
    public bool ShowOverlay;
    public bool ProtectPulls = true;
    public bool IncludeHitboxes = true;
    public float PredictionSeconds = 0.25f;
    public float MaxHeight = 3;
    public int ScanMilliseconds = 100;
    public int ActiveProfile;
    public Profile[] Profiles = Defaults();
    public Profile Active => Profiles[ActiveProfile];

    public static Profile[] Defaults() =>
    [
        new() { Shape = Shape.Circle, CastRange = 25, Radius = 5 },
        new() { Shape = Shape.Cone, CastRange = 12, Length = 12, AngleDegrees = 90 },
        new() { Shape = Shape.Line, CastRange = 10, Length = 10, Width = 4 },
    ];

    public void Normalize()
    {
        if (Profiles == null || Profiles.Length != 3 || Profiles.Any(p => p == null)) Profiles = Defaults();
        for (var i = 0; i < Profiles.Length; i++) { Profiles[i].Normalize(); Profiles[i].Shape = (Shape)i; }
        ActiveProfile = Math.Clamp(ActiveProfile, 0, 2);
        PredictionSeconds = Profile.Safe(PredictionSeconds, 0, 0.75f, 0.25f);
        MaxHeight = Profile.Safe(MaxHeight, 0.5f, 10, 3);
        ScanMilliseconds = Math.Clamp(ScanMilliseconds, 50, 500);
    }
}
