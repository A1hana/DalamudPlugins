using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace CleaveCompass.UI;

internal sealed class HudWindow : Window
{
    private readonly Configuration config;
    private readonly Runtime runtime;
    private readonly Action open;
    public HudWindow(Configuration config, Runtime runtime, Action open) : base("群攻罗盘###CleaveCompassHud")
    {
        this.config = config; this.runtime = runtime; this.open = open;
        IsOpen = true; ShowCloseButton = false; RespectCloseHotkey = false;
        Position = new Vector2(40, 320); PositionCondition = ImGuiCond.FirstUseEver;
    }
    public override bool DrawConditions() => config.Enabled && config.ShowHud && runtime.Alive &&
        !runtime.Transitioning && runtime.Scene.Enemies.Length > 0;
    public override void PreDraw()
    {
        Flags = ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoFocusOnAppearing;
        if (config.LockHud) Flags |= ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoInputs;
    }
    public override void Draw()
    {
        var s = runtime.Scene;
        var best = s.Analysis.Best;
        ImGui.TextColored(ScenePainter.Mint, $"{ScenePainter.ShapeName(s.Profile.Shape)}  ·  预计 {s.Analysis.Current?.Hits ?? 0} -> {best?.Hits ?? 0} 个");
        if (best != null) ImGui.TextUnformatted($"推荐 {best.Name}");
        else ImGui.TextUnformatted(s.Message);
        if (runtime.Demo) ImGui.TextColored(ScenePainter.Amber, "演示开关已开启，选人暂停");
        if (s.Player.IsCasting) ImGui.TextUnformatted("读条中 · 暂不切换");
        if (s.Analysis.Current?.Pulls > 0 && config.ProtectPulls && !s.IsPvp)
            ImGui.TextColored(ScenePainter.Amber, "当前目标有误拉怪风险");
        if (!config.LockHud)
        {
            ImGui.BeginDisabled(best == null || runtime.Demo || s.Player.IsCasting);
            if (ImGui.Button("选中最佳")) runtime.RequestSelect();
            ImGui.EndDisabled();
            ImGui.SameLine(); if (ImGui.Button("设置")) open();
        }
    }
}
