using System.Numerics;
using CleaveCompass.Core;

namespace CleaveCompass.UI;

internal static class DemoScene
{
    public static Scene Create(Configuration config, int scenario, double time)
    {
        var player = new Actor(Vector3.Zero, 0.5f, 0, false);
        var profile = config.Active.Copy();
        var positions = profile.Shape == Shape.Circle ? new Vector3[]
        {
            new(-9, 0, -9), new(5, 0, -14), new(6, 0, -12), new(3, 0, -12), new(5, 0, -16), new(-12, 0, 3),
        } : new Vector3[]
        {
            new(-7, 0, -4), new(1, 0, -6), new(0, 0, -8), new(2, 0, -7), new(-1, 0, -9), new(-9, 0, 2),
        };
        var enemies = positions.Select((p, i) => new Enemy((ulong)i + 1, $"演示目标 {i + 1}", p,
            scenario == 2 && i is >= 2 and <= 4 ? p + new Vector3((i - 1) * config.PredictionSeconds * 5, 0, 0) : p,
            0.7f, true, true)).ToList();
        if (scenario == 1)
        {
            var p = profile.Shape == Shape.Circle ? new Vector3(7, 0, -15) : new Vector3(1, 0, -10);
            enemies.Add(new(99, "未开战小怪", p, p, 0.7f, false, true));
        }
        var analysis = Planner.Analyze(enemies, player, profile, 1, config.ProtectPulls, config.IncludeHitboxes, config.MaxHeight);
        return new(player, enemies.ToArray(), profile, analysis, 1, false, "模拟场景，不会改变游戏目标", time);
    }
}
