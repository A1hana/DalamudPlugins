using System.Numerics;
using CleaveCompass.Core;
using Dalamud.Bindings.ImGui;

namespace CleaveCompass.UI;

internal sealed class Overlay(Services services, Configuration config, Runtime runtime)
{
    public void Draw()
    {
        if (!config.Enabled || !config.ShowOverlay || runtime.Demo || !runtime.Alive || runtime.Transitioning) return;
        var scene = runtime.Scene;
        if (scene.Analysis.Best is not { } plan) return;
        var draw = ImGui.GetBackgroundDrawList();
        var color = ScenePainter.Color(ScenePainter.Mint);
        var points = Geometry.Outline(scene.Profile, plan.Origin + new Vector3(0, 0.08f, 0), plan.Direction);
        for (var i = 1; i < points.Length; i++)
        {
            if (services.Gui.WorldToScreen(points[i - 1], out var a) && services.Gui.WorldToScreen(points[i], out var b) &&
                Vector2.DistanceSquared(a, b) < 1000000)
                draw.AddLine(a, b, color, 2);
        }
        foreach (var e in scene.Enemies)
        {
            if (!plan.HitIds.Contains(e.Id) || !services.Gui.WorldToScreen(e.Predicted + new Vector3(0, 0.1f, 0), out var screen)) continue;
            draw.AddCircle(screen, e.Id == plan.TargetId ? 12 : 5, color, 24, 2);
            if (e.Id == plan.TargetId)
                draw.AddText(screen + new Vector2(15, -15), color, $"最佳 · 预计 {plan.Hits} 个");
        }
    }
}
