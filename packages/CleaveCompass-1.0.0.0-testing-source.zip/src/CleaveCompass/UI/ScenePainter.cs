using System.Numerics;
using CleaveCompass.Core;
using Dalamud.Bindings.ImGui;

namespace CleaveCompass.UI;

internal static class ScenePainter
{
    public static readonly Vector4 Mint = new(0.3f, 0.94f, 0.73f, 1);
    public static readonly Vector4 Amber = new(1f, 0.72f, 0.3f, 1);
    public static uint Color(Vector4 c) => ImGui.ColorConvertFloat4ToU32(c);
    public static string ShapeName(Shape s) => s switch { Shape.Circle => "目标圆形", Shape.Cone => "前方扇形", _ => "前方直线" };

    public static void Draw(Scene scene, float height, bool hitboxes)
    {
        var size = new Vector2(MathF.Max(200, ImGui.GetContentRegionAvail().X), height);
        var top = ImGui.GetCursorScreenPos();
        var d = ImGui.GetWindowDrawList();
        var visible = scene.Enemies.Where(e => Vector3.Distance(e.Predicted, scene.Player.Position) <=
            scene.Profile.CastRange + MathF.Max(scene.Profile.Radius, scene.Profile.Length) + 10).ToArray();
        var bounds = visible.Select(e => Geometry.Flat(e.Predicted)).Append(Geometry.Flat(scene.Player.Position)).ToList();
        if (scene.Analysis.Best is { } viewPlan)
            bounds.AddRange(Geometry.Outline(scene.Profile, viewPlan.Origin, viewPlan.Direction).Select(Geometry.Flat));
        var min = new Vector2(bounds.Min(p => p.X), bounds.Min(p => p.Y));
        var max = new Vector2(bounds.Max(p => p.X), bounds.Max(p => p.Y));
        var middle = (min + max) / 2;
        var extent = max - min + new Vector2(10);
        var scale = MathF.Min((size.X - 40) / MathF.Max(12, extent.X), (size.Y - 65) / MathF.Max(12, extent.Y));
        Vector2 Map(Vector3 p) => top + size / 2 + (Geometry.Flat(p) - middle) * scale;
        var center = Map(scene.Player.Position);
        d.AddRectFilled(top, top + size, Color(new(0.055f, 0.075f, 0.11f, 1)), 8);
        d.PushClipRect(top, top + size, true);
        for (var i = 1; i <= 3; i++)
            d.AddCircle(center, scene.Profile.CastRange * scale * i / 3, 0x303F7180, 64, 1);
        d.AddLine(new(center.X, top.Y), new(center.X, top.Y + size.Y), 0x254D768A);
        d.AddLine(new(top.X, center.Y), new(top.X + size.X, center.Y), 0x254D768A);
        d.AddText(top + new Vector2(12, 10), 0xFF94ABBC, "上方为北   俯视图 · 范围估算");
        if (scene.Analysis.Best is { } best)
        {
            var outline = Geometry.Outline(scene.Profile, best.Origin, best.Direction);
            for (var i = 1; i < outline.Length; i++) d.AddLine(Map(outline[i - 1]), Map(outline[i]), Color(Mint), 2);
            var anchor = scene.Enemies.FirstOrDefault(e => e.Id == best.TargetId);
            d.AddLine(center, Map(anchor.Predicted), 0x805FDDB0, 1);
        }
        foreach (var e in visible)
        {
            var p = Map(e.Predicted);
            var covered = scene.Analysis.Best?.HitIds.Contains(e.Id) == true;
            var c = !e.Engaged ? Amber : covered ? Mint : new Vector4(0.65f, 0.7f, 0.79f, 1);
            if (Vector3.DistanceSquared(e.Position, e.Predicted) > 0.03f)
                d.AddLine(Map(e.Position), p, Color(c with { W = 0.45f }), 1);
            d.AddCircleFilled(p, MathF.Max(3.5f, hitboxes ? e.Radius * scale : 3.5f), Color(c), 24);
            if (e.Id == scene.CurrentId) d.AddCircle(p, MathF.Max(7, e.Radius * scale + 3), 0xFFFFFFFF, 24, 1.5f);
            if (e.Id == scene.Analysis.Best?.TargetId)
            {
                d.AddCircle(p, MathF.Max(10, e.Radius * scale + 6), Color(Mint), 24, 2);
                d.AddText(p + new Vector2(10, -18), Color(Mint), "最佳");
            }
        }
        d.AddCircleFilled(center, 5, 0xFFFFC072, 16);
        d.AddText(center + new Vector2(8, 4), 0xFFFFC072, "你");
        d.AddText(top + new Vector2(12, size.Y - 26), 0xFFAFC1CA, "白圈 当前目标     绿圈 最佳目标     橙点 未开战");
        d.PopClipRect();
        ImGui.Dummy(size);
    }
}
