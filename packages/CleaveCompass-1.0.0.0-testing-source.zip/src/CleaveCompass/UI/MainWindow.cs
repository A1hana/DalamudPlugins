using System.Numerics;
using CleaveCompass.Core;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace CleaveCompass.UI;

internal sealed class MainWindow : Window
{
    private readonly Configuration config;
    private readonly Runtime runtime;
    private readonly Action save;
    private int scenario;
    private string actionInfo = "可选：绑定技能后，对主目标增加游戏原生距离和视线检查。";
    private static readonly string[] ShapeNames = ["目标圆形", "前方扇形", "前方直线"];

    public MainWindow(Configuration config, Runtime runtime, Action save) : base("群攻罗盘###CleaveCompassMain")
    {
        this.config = config; this.runtime = runtime; this.save = save;
        Size = new(700, 760);
        SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new() { MinimumSize = new(540, 480), MaximumSize = new(1400, 1600) };
    }

    public override void Draw()
    {
        ImGui.TextColored(ScenePainter.Mint, "CLEAVE COMPASS   /   群攻罗盘");
        ImGui.TextWrapped("选对群攻主目标，让同一发技能覆盖更多敌人。");
        ImGui.Spacing();
        if (ImGui.Checkbox("启用", ref config.Enabled)) save();
        ImGui.SameLine();
        if (ImGui.Checkbox("悬浮窗", ref config.ShowHud)) save();
        ImGui.SameLine();
        if (ImGui.Checkbox("场景叠加", ref config.ShowOverlay)) save();
        var demo = runtime.Demo;
        ImGui.SameLine();
        if (ImGui.Checkbox("演示模式", ref demo)) runtime.Demo = demo;
        if (!ImGui.BeginTabBar("CompassTabs")) return;
        if (ImGui.BeginTabItem("作战面板")) { DrawCombat(); ImGui.EndTabItem(); }
        if (ImGui.BeginTabItem("参数与使用")) { DrawSettings(); ImGui.EndTabItem(); }
        ImGui.EndTabBar();
    }

    private void DrawCombat()
    {
        if (ImGui.Combo("群攻形状", ref config.ActiveProfile, ShapeNames, 3)) save();
        if (runtime.Demo)
        {
            ImGui.Combo("演示场景", ref scenario, new[] { "密集怪群", "旁边有未开战怪", "敌人正在散开" }, 3);
            ImGui.TextColored(ScenePainter.Amber, "演示中：选人按钮和 /cleave pick 都不会操作游戏。");
        }
        var scene = runtime.Demo ? DemoScene.Create(config, scenario, runtime.Scene.Time) : runtime.Scene;
        var best = scene.Analysis.Best;
        var current = scene.Analysis.Current;
        ImGui.Separator();
        ImGui.TextUnformatted($"当前预计 {current?.Hits ?? 0} 个    ->    最佳预计 {best?.Hits ?? 0} 个");
        if (best != null) ImGui.TextColored(ScenePainter.Mint, $"推荐：{best.Name}    多覆盖 {Math.Max(0, best.Hits - (current?.Hits ?? 0))} 个");
        else ImGui.TextColored(ScenePainter.Amber, scene.Message);
        if (current?.Pulls > 0 && config.ProtectPulls && !scene.IsPvp)
            ImGui.TextColored(ScenePainter.Amber, $"当前方案可能碰到 {current.Pulls} 个未开战目标");
        ScenePainter.Draw(scene, 280, config.IncludeHitboxes);
        ImGui.BeginDisabled(runtime.Demo || best == null || !config.Enabled || scene.Player.IsCasting);
        if (ImGui.Button("选中最佳目标  /cleave pick", new(-1, 36))) runtime.RequestSelect();
        ImGui.EndDisabled();
        if (scene.Player.IsCasting) ImGui.TextColored(ScenePainter.Amber, "读条中暂不切换目标");
        ImGui.TextWrapped(runtime.Feedback);
        ImGui.Spacing();
        if (ImGui.BeginTable("Ranking", 3, ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.RowBg))
        {
            ImGui.TableSetupColumn("候选目标"); ImGui.TableSetupColumn("预计覆盖"); ImGui.TableSetupColumn("中心距离");
            ImGui.TableHeadersRow();
            foreach (var plan in scene.Analysis.Ranked.Take(4))
            {
                ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.TextUnformatted(plan.Name);
                ImGui.TableNextColumn(); ImGui.TextUnformatted($"{plan.Hits} 个");
                ImGui.TableNextColumn(); ImGui.TextUnformatted($"{plan.Distance:F1} m");
            }
            ImGui.EndTable();
        }
        ImGui.TextDisabled($"{(scene.IsPvp ? "PvP" : "PvE")}  |  已加载敌人 {scene.Enemies.Length}  |  扫描 {runtime.ScanDurationMs:F2} ms");
        ImGui.TextWrapped(config.Active.ActionId == 0 ? "几何模式：尚未检查障碍物视线。可在参数页绑定技能。" :
            $"主目标已启用技能 {config.Active.ActionId} 的原生距离和视线检查。");
    }

    private void DrawSettings()
    {
        ImGui.PushItemWidth(ImGui.GetContentRegionAvail().X * 0.53f);
        if (ImGui.Combo("配置形状", ref config.ActiveProfile, ShapeNames, 3)) save();
        var p = config.Active;
        var changed = false;
        var range = p.CastRange;
        if (ImGui.SliderFloat("主目标距离 (m)", ref range, 1, 50, "%.1f")) { p.CastRange = range; changed = true; }
        if (p.Shape == Shape.Circle)
        {
            var radius = p.Radius;
            if (ImGui.SliderFloat("圆形半径 (m)", ref radius, 0.5f, 30, "%.1f")) { p.Radius = radius; changed = true; }
        }
        else
        {
            var length = p.Length;
            if (ImGui.SliderFloat("前方长度 (m)", ref length, 1, 50, "%.1f")) { p.Length = length; changed = true; }
            if (p.Shape == Shape.Cone)
            {
                var angle = p.AngleDegrees;
                if (ImGui.SliderFloat("扇形总角度", ref angle, 5, 180, "%.0f°")) { p.AngleDegrees = angle; changed = true; }
            }
            else
            {
                var width = p.Width;
                if (ImGui.SliderFloat("直线总宽度 (m)", ref width, 0.5f, 30, "%.1f")) { p.Width = width; changed = true; }
            }
        }
        ImGui.TextWrapped("三个默认项是几何模板。请按准备释放的技能调整；不会自动识别职业、技能升级或朝向设置。");
        ImGui.Separator();
        var actionId = (int)p.ActionId;
        if (ImGui.InputInt("绑定技能 ID，0 为不绑定", ref actionId))
        { p.ActionId = (uint)Math.Clamp(actionId, 0, 1000000); changed = true; }
        if (ImGui.Button("检查并读取技能范围"))
        {
            if (runtime.TryAction(p.ActionId, out var name, out var actionRange, out var effectRange))
            {
                p.CastRange = actionRange;
                if (effectRange > 0) { if (p.Shape == Shape.Circle) p.Radius = effectRange; else p.Length = effectRange; }
                actionInfo = $"已读取 {name}。请核对形状、扇形角度和直线宽度；技能表不完整描述所有判定。";
                changed = true;
            }
            else actionInfo = "技能无效或不支持：需要可对敌使用、施法距离大于 0 的目标技能。";
        }
        ImGui.TextWrapped(actionInfo);
        ImGui.Separator();
        changed |= ImGui.Checkbox("PvE 防误拉怪", ref config.ProtectPulls);
        ImGui.TextWrapped("拒绝会覆盖未开战目标的方案；木人和首发拉怪时可临时关闭。PvP 自动忽略这一限制。");
        changed |= ImGui.Checkbox("覆盖估算考虑敌人碰撞圈", ref config.IncludeHitboxes);
        changed |= ImGui.SliderFloat("提前预测 (秒)", ref config.PredictionSeconds, 0, 0.75f, "%.2f");
        ImGui.TextWrapped("0 使用当前位置；0.25 为短时趋势估算。突进、传送和样本过期时自动重置。预测未模拟技能快照或网络延迟。");
        changed |= ImGui.SliderFloat("允许高度差 (m)", ref config.MaxHeight, 0.5f, 10, "%.1f");
        changed |= ImGui.SliderInt("扫描间隔 (毫秒)", ref config.ScanMilliseconds, 50, 500);
        changed |= ImGui.Checkbox("固定悬浮窗并鼠标穿透", ref config.LockHud);
        if (changed) save();
        ImGui.Separator();
        ImGui.TextWrapped("快捷使用：创建只有一行 /cleave pick 的游戏宏，拖到热键栏并绑定按键。按下后选人，再按自己的群攻技能。不要把群攻技能写入同一个宏，以免影响技能队列。");
        ImGui.TextWrapped("扇形和直线按朝向目标的方向估算。请开启游戏的自动面向目标，或手动面向目标。范围内的其他敌人不会逐个检查墙体、无敌、护盾或伤害衰减；数字表示预计覆盖，不表示伤害或斩杀人数。");
        ImGui.TextWrapped("命令：/cleave 打开面板；pick 选人；circle / cone / line 切形状；hud / overlay 切显示；on / off 开关；demo 演示。");
        ImGui.PopItemWidth();
    }
}
