using System.Numerics;

namespace CleaveCompass.Core;

public static class Planner
{
    public static Analysis Analyze(IReadOnlyList<Enemy> enemies, Actor player, Profile profile,
        ulong current, bool protectPulls, bool includeHitboxes, float maxHeight)
    {
        var ranked = new List<Plan>();
        Plan? currentPlan = null;
        var rejected = 0;
        foreach (var anchor in enemies)
        {
            if (!anchor.CanAnchor || !Geometry.InRange(player, anchor, profile.CastRange, maxHeight)) continue;
            var predictedOrigin = profile.Shape == Shape.Circle ? anchor.Predicted : player.Position;
            var currentOrigin = profile.Shape == Shape.Circle ? anchor.Position : player.Position;
            var direction = Geometry.Direction(player.Position, anchor.Predicted, player.Rotation);
            var currentDirection = Geometry.Direction(player.Position, anchor.Position, player.Rotation);
            var hits = new List<ulong>();
            var pulls = 0;
            foreach (var enemy in enemies)
            {
                var radius = includeHitboxes ? enemy.Radius : 0;
                var hit = Geometry.Hits(profile, predictedOrigin, direction, enemy.Predicted, radius, maxHeight);
                // Pull protection covers both observed and predicted positions. An unengaged
                // anchor is always a pull, even when a malformed directional template misses it.
                var pull = !enemy.Engaged && (enemy.Id == anchor.Id || hit ||
                    Geometry.Hits(profile, currentOrigin, currentDirection, enemy.Position, radius, maxHeight));
                if (pull) pulls++;
                if (hit && (enemy.Engaged || !protectPulls)) hits.Add(enemy.Id);
            }
            var plan = new Plan(anchor.Id, anchor.Name, hits.Count, pulls,
                Vector3.Distance(player.Position, anchor.Position), predictedOrigin, direction, hits.ToArray());
            if (anchor.Id == current) currentPlan = plan;
            if (protectPulls && pulls > 0) { rejected++; continue; }
            if (hits.Count > 0) ranked.Add(plan);
        }
        ranked.Sort((a, b) =>
        {
            var score = b.Hits.CompareTo(a.Hits);
            if (score != 0) return score;
            var selected = (b.TargetId == current).CompareTo(a.TargetId == current);
            if (selected != 0) return selected;
            var distance = a.Distance.CompareTo(b.Distance);
            return distance != 0 ? distance : a.TargetId.CompareTo(b.TargetId);
        });
        return new(ranked.FirstOrDefault(), currentPlan, ranked.ToArray(), rejected);
    }
}
