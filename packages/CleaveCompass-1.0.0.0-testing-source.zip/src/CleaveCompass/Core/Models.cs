using System.Numerics;

namespace CleaveCompass.Core;

public enum Shape { Circle, Cone, Line }

public sealed class Profile
{
    public Shape Shape { get; set; }
    public float CastRange { get; set; } = 25;
    public float Radius { get; set; } = 5;
    public float Length { get; set; } = 12;
    public float Width { get; set; } = 4;
    public float AngleDegrees { get; set; } = 90;
    public uint ActionId { get; set; }

    public void Normalize()
    {
        if (!Enum.IsDefined(Shape)) Shape = Shape.Circle;
        CastRange = Safe(CastRange, 1, 50, 25);
        Radius = Safe(Radius, 0.5f, 30, 5);
        Length = Safe(Length, 1, 50, 12);
        Width = Safe(Width, 0.5f, 30, 4);
        AngleDegrees = Safe(AngleDegrees, 5, 180, 90);
        if (ActionId > 1000000) ActionId = 0;
    }

    public static float Safe(float v, float min, float max, float fallback) =>
        float.IsFinite(v) ? Math.Clamp(v, min, max) : fallback;

    public Profile Copy() => (Profile)MemberwiseClone();
}

public readonly record struct Enemy(ulong Id, string Name, Vector3 Position, Vector3 Predicted,
    float Radius, bool Engaged, bool CanAnchor);

public readonly record struct Actor(Vector3 Position, float Radius, float Rotation, bool IsCasting);

public sealed record Plan(ulong TargetId, string Name, int Hits, int Pulls, float Distance,
    Vector3 Origin, Vector2 Direction, ulong[] HitIds);

public sealed record Analysis(Plan? Best, Plan? Current, Plan[] Ranked, int RejectedPulls);

public sealed record Scene(Actor Player, Enemy[] Enemies, Profile Profile, Analysis Analysis,
    ulong CurrentId, bool IsPvp, string Message, double Time)
{
    public static Scene Empty(string reason, double time = 0) => new(default, [], new(),
        new(null, null, [], 0), 0, false, reason, time);
}
