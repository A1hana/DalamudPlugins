namespace CleaveCompass.Core;

public static class SelectionPolicy
{
    public static string? BlockReason(bool enabled, bool alive, bool transitioning, bool casting, bool demo,
        Plan? plan) => !enabled ? "插件已停用" : !alive ? "角色尚未就绪或已经倒地" : transitioning ? "切换区域或观看过场中" :
        demo ? "演示模式不会选中游戏目标" : casting ? "正在读条，保持当前目标" : plan == null ? "没有符合条件的群攻目标" : null;
}
