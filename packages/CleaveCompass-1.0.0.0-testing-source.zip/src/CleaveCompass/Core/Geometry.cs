using System.Numerics;

namespace CleaveCompass.Core;

// Pure geometry, independently implemented. All calculations use the horizontal X/Z plane.
public static class Geometry
{
    private const float Epsilon = 0.0001f;
    public static Vector2 Flat(Vector3 p) => new(p.X, p.Z);
    public static bool Finite(Vector3 p) => float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z);
    public static Vector2 Direction(Vector3 from, Vector3 to, float rotation)
    {
        var d = Flat(to - from);
        return d.LengthSquared() > Epsilon ? Vector2.Normalize(d) : new(MathF.Sin(rotation), MathF.Cos(rotation));
    }

    public static bool Hits(Profile p, Vector3 origin, Vector2 direction, Vector3 point,
        float radius, float maxHeight)
    {
        if (!Finite(origin) || !Finite(point) || !float.IsFinite(radius) || radius < 0 ||
            MathF.Abs(origin.Y - point.Y) > maxHeight) return false;
        var v = Flat(point - origin);
        if (p.Shape == Shape.Circle)
            return v.LengthSquared() <= MathF.Pow(p.Radius + radius, 2) + Epsilon;
        var x = Vector2.Dot(v, direction);
        var y = MathF.Abs(v.X * direction.Y - v.Y * direction.X);
        if (p.Shape == Shape.Line)
        {
            // Exact disc/rectangle intersection, including rounded corner distance.
            var dx = MathF.Max(MathF.Max(-x, x - p.Length), 0);
            var dy = MathF.Max(y - p.Width * 0.5f, 0);
            return dx * dx + dy * dy <= radius * radius + Epsilon;
        }

        // Distance to a closed circular sector: interior, arc, or either radial edge.
        var halfAngle = p.AngleDegrees * MathF.PI / 360;
        var length = v.Length();
        if (length < Epsilon) return true;
        var angle = MathF.Atan2(y, x);
        if (angle <= halfAngle)
            return length <= p.Length + radius + Epsilon;
        var edge = new Vector2(MathF.Cos(halfAngle), MathF.Sin(halfAngle)) * p.Length;
        return DistanceToSegmentSquared(new(x, y), Vector2.Zero, edge) <= radius * radius + Epsilon;
    }

    public static float DistanceToSegmentSquared(Vector2 p, Vector2 a, Vector2 b)
    {
        var ab = b - a;
        var t = ab.LengthSquared() > Epsilon ? Math.Clamp(Vector2.Dot(p - a, ab) / ab.LengthSquared(), 0, 1) : 0;
        return Vector2.DistanceSquared(p, a + t * ab);
    }

    public static bool InRange(Actor player, Enemy enemy, float range, float maxHeight) =>
        Finite(player.Position) && Finite(enemy.Position) && float.IsFinite(enemy.Radius) &&
        enemy.Radius >= 0 && MathF.Abs(player.Position.Y - enemy.Position.Y) <= maxHeight &&
        Vector3.Distance(player.Position, enemy.Position) <= range + player.Radius + enemy.Radius;

    public static Vector3[] Outline(Profile p, Vector3 origin, Vector2 direction)
    {
        static Vector3 World(Vector3 o, Vector2 v) => o + new Vector3(v.X, 0, v.Y);
        if (p.Shape == Shape.Line)
        {
            var side = new Vector2(-direction.Y, direction.X) * (p.Width / 2);
            return [World(origin, side), World(origin, direction * p.Length + side),
                World(origin, direction * p.Length - side), World(origin, -side), World(origin, side)];
        }
        var points = new List<Vector3>();
        var centerAngle = MathF.Atan2(direction.Y, direction.X);
        var half = p.Shape == Shape.Circle ? MathF.PI : p.AngleDegrees * MathF.PI / 360;
        var radius = p.Shape == Shape.Circle ? p.Radius : p.Length;
        if (p.Shape == Shape.Cone) points.Add(origin);
        for (var i = 0; i <= 64; i++)
        {
            var angle = centerAngle - half + 2 * half * i / 64;
            points.Add(World(origin, new Vector2(MathF.Cos(angle), MathF.Sin(angle)) * radius));
        }
        if (p.Shape == Shape.Cone) points.Add(origin);
        return points.ToArray();
    }
}
