using System.Numerics;

namespace CleaveCompass.Core;

public sealed class MotionTracker
{
    private sealed record Sample(Vector3 Position, Vector3 Velocity, double Time, int Count);
    private readonly Dictionary<ulong, Sample> samples = [];
    public int Count => samples.Count;

    public Vector3 Observe(ulong id, Vector3 position, double now, float horizon)
    {
        if (!Geometry.Finite(position) || !double.IsFinite(now)) return position;
        var velocity = Vector3.Zero;
        var count = 1;
        if (samples.TryGetValue(id, out var old))
        {
            var dt = now - old.Time;
            if (dt is >= 0 and < 0.04)
                return position + old.Velocity * Profile.Safe(horizon, 0, 0.75f, 0);
            if (dt is >= 0.04 and <= 0.6)
            {
                var raw = (position - old.Position) / (float)dt;
                // Dashes/teleports and elevation jumps invalidate extrapolation.
                if (raw.Length() <= 12 && MathF.Abs(position.Y - old.Position.Y) < 1.5f)
                {
                    velocity = old.Count > 1 ? Vector3.Lerp(old.Velocity, raw, 0.65f) : raw;
                    count = old.Count + 1;
                }
            }
        }
        samples[id] = new(position, velocity, now, count);
        return position + velocity * Profile.Safe(horizon, 0, 0.75f, 0);
    }

    public void Prune(double now)
    {
        foreach (var id in samples.Where(x => now - x.Value.Time > 1.5).Select(x => x.Key).ToArray()) samples.Remove(id);
    }

    public void Clear() => samples.Clear();
}
