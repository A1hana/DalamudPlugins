param(
    [string]$Dotnet = 'dotnet',
    [string]$DalamudLibPath,
    [switch]$PackageOnly
)
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    if (-not $PackageOnly) {
        & $Dotnet run --project tests/CleaveCompass.Tests.csproj -c Release
        if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
        $arguments = @('build', 'src/CleaveCompass/CleaveCompass.csproj', '-c', 'Release')
        if ($DalamudLibPath) {
            $libraryPath = (Resolve-Path -LiteralPath $DalamudLibPath).Path.TrimEnd('\', '/') + '/'
            $arguments += "-p:DalamudLibPath=$libraryPath"
        }
        & $Dotnet @arguments
        if ($LASTEXITCODE -ne 0) { throw 'Plugin build failed.' }
    }
    $releasePath = Join-Path $PSScriptRoot 'src/CleaveCompass/bin/Release'
    $manifest = Get-Content -LiteralPath (Join-Path $releasePath 'CleaveCompass.json') -Raw | ConvertFrom-Json
    if ($manifest.DalamudApiLevel -ne 15 -or $manifest.InternalName -ne 'CleaveCompass' -or
        $manifest.AssemblyVersion -notmatch '^\d+\.\d+\.\d+\.\d+$') { throw 'Unexpected manifest.' }
    $version = $manifest.AssemblyVersion
    $distPath = Join-Path $PSScriptRoot 'dist'
    $packagePath = Join-Path $distPath 'CleaveCompass'
    New-Item -ItemType Directory -Path $packagePath -Force | Out-Null
    $files = @()
    foreach ($name in @('CleaveCompass.dll', 'CleaveCompass.json', 'CleaveCompass.deps.json')) {
        $destination = Join-Path $packagePath $name
        Copy-Item -LiteralPath (Join-Path $releasePath $name) -Destination $destination -Force
        $files += $destination
    }
    foreach ($name in @('LICENSE', 'NOTICE')) {
        $destination = Join-Path $packagePath $name
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $destination -Force
        $files += $destination
    }
    $manual = Join-Path $distPath '群攻罗盘使用手册.docx'
    if (-not (Test-Path -LiteralPath $manual)) { throw 'Verified DOCX manual is required for packaging.' }
    $manualDestination = Join-Path $packagePath '群攻罗盘使用手册.docx'
    Copy-Item -LiteralPath $manual -Destination $manualDestination -Force
    $files += $manualDestination
    $zipPath = Join-Path $distPath "CleaveCompass-$version.zip"
    Compress-Archive -LiteralPath $files -DestinationPath $zipPath -Force
    $sourcePath = Join-Path $distPath "CleaveCompass-$version-source.zip"
    $sourceFiles = @(Get-ChildItem -LiteralPath 'src', 'tests' -File -Recurse |
        Where-Object { $_.FullName -notmatch '[\\/](obj|bin)[\\/]' } | Select-Object -ExpandProperty FullName)
    $sourceFiles += @('build.ps1', 'LICENSE', 'NOTICE', '.gitignore') | ForEach-Object { Join-Path $PSScriptRoot $_ }
    $sourceFiles += $manual
    $stream = [System.IO.File]::Open($sourcePath, [System.IO.FileMode]::Create)
    $archive = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in $sourceFiles) {
            $entry = [System.IO.Path]::GetRelativePath($PSScriptRoot, $file).Replace('\', '/')
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file, $entry) | Out-Null
        }
    } finally { $archive.Dispose(); $stream.Dispose() }
    Get-FileHash -LiteralPath $zipPath, $sourcePath, $manual -Algorithm SHA256 |
        ForEach-Object { '{0}  {1}' -f $_.Hash, [System.IO.Path]::GetFileName($_.Path) } |
        Set-Content -LiteralPath (Join-Path $distPath 'SHA256SUMS.txt') -Encoding utf8
    Write-Output "Plugin package: $zipPath"
    Write-Output "Source package: $sourcePath"
} finally { Pop-Location }
