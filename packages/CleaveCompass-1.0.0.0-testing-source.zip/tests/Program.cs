using System.Diagnostics;
using System.Numerics;
using CleaveCompass.Core;

var checks = 0;
void Check(bool condition, string name)
{
    checks++;
    if (!condition) throw new InvalidOperationException($"FAILED: {name}");
}
void Near(float actual, float expected, string name) => Check(MathF.Abs(actual - expected) < 0.001f, $"{name}: {actual} != {expected}");
var actor = new Actor(Vector3.Zero, 0.5f, 0, false);
var circle = new Profile { Shape = Shape.Circle, Radius = 5, CastRange = 25 };
var cone = new Profile { Shape = Shape.Cone, Length = 10, AngleDegrees = 90, CastRange = 25 };
var line = new Profile { Shape = Shape.Line, Length = 10, Width = 4, CastRange = 25 };
var dir = Vector2.UnitX;
bool Hit(Profile p, float x, float z, float radius = 0) => Geometry.Hits(p, Vector3.Zero, dir, new(x, 0, z), radius, 3);
Enemy E(ulong id, float x, float z, bool engaged = true, bool anchor = true, float radius = 0.5f) =>
    new(id, $"Enemy {id}", new(x, 0, z), new(x, 0, z), radius, engaged, anchor);
Analysis Analyze(Enemy[] enemies, Profile? p = null, ulong current = 0, bool protect = true, bool hitboxes = true) =>
    Planner.Analyze(enemies, actor, p ?? circle, current, protect, hitboxes, 3);

Check(Hit(circle, 5, 0), "circle boundary included");
Check(!Hit(circle, 5.01f, 0), "circle outside excluded");
Check(Hit(circle, 6, 0, 1), "hitbox intersection included");
Check(!Hit(circle, 6.1f, 0, 1), "separated discs excluded");
Check(!Geometry.Hits(circle, Vector3.Zero, dir, new(0, 3.1f, 0), 2, 3), "other floor excluded");
Check(!Geometry.Hits(circle, Vector3.Zero, dir, new(float.NaN, 0, 0), 2, 3), "NaN position excluded");
Check(!Hit(circle, 0, 0, -1), "negative hitbox excluded");
Check(Hit(line, 10, 2), "rectangle corner included");
Check(Hit(line, 10.6f, 2.8f, 1), "rounded corner tangent");
Check(!Hit(line, 10.9f, 2.9f, 1), "expanded rectangle false positive avoided");
Check(!Hit(line, -2, 0, 1), "enemy behind origin excluded");
Check(Hit(line, -0.5f, 0, 1), "disc overlapping origin included");
Check(Hit(cone, 5, 5), "cone side boundary");
Check(Hit(cone, 10, 0), "cone front boundary");
Check(!Hit(cone, -3, 0, 1), "cone rear excluded");
Check(Hit(cone, 0, 0), "cone vertex");
Check(Hit(cone, 4, 5, 0.8f), "cone side hitbox intersection");
Check(!Hit(cone, 4, 5, 0.6f), "cone side miss");
Check(Hit(cone, 11, 0, 1), "cone arc hitbox tangent");
Check(!Hit(cone, 11.01f, 0, 1), "cone arc miss");
Check(Geometry.InRange(actor, E(1, 26, 0), 25, 3), "cast range includes both hitboxes");
Check(!Geometry.InRange(actor, E(1, 26.01f, 0), 25, 3), "cast range over limit");
Check(Geometry.Direction(Vector3.Zero, Vector3.Zero, 0) == Vector2.UnitY, "overlapping anchors use actor heading");

var pack = new[] { E(1, -10, 0), E(2, 10, 0), E(3, 12, 0), E(4, 10, 2) };
var a = Analyze(pack, current: 1);
Check(a.Best?.TargetId == 2 && a.Best.Hits == 3, "find dense cluster");
Check(a.Current?.Hits == 1, "compare actual current target");
Check(Analyze(pack, current: 3).Best?.TargetId == 3, "equal score retains current target");
Check(Analyze(pack.Reverse().ToArray()).Best?.TargetId == a.Best?.TargetId, "object order independent");
Check(Analyze([E(8, 5, 0), E(3, -5, 0)]).Best?.TargetId == 3, "distance tie uses stable id");
Check(Analyze([E(1, 5, 0, anchor: false), E(2, 6, 0)]).Best?.TargetId == 2, "invalid anchor still counts as collateral");
var splash = Analyze([E(1, 25, 0), E(2, 29, 0, anchor: false)]);
Check(splash.Best?.Hits == 2, "splash victim beyond cast range still counted");
Check(Analyze([]).Best == null, "empty scene");
Check(Analyze([E(1, 50, 0)]).Best == null, "no in-range anchors");
Check(Analyze([E(1, 1, 0, false)]).Best == null, "unengaged anchor blocked");
Check(Analyze([E(1, 1, 0, false)], protect: false).Best?.Hits == 1, "pull override supports first hit and dummies");
Check(Analyze([..pack, E(9, 11, 1, false)]).Best?.TargetId == 1, "reject cluster containing unpulled monster");
var unsafeCurrent = Analyze([..pack, E(9, 11, 1, false)], current: 2);
Check(unsafeCurrent.Current?.Pulls == 1 && unsafeCurrent.RejectedPulls == 4, "report unsafe current and rejected anchors");
Check(Analyze([E(1, 1, 0), E(2, 30, 0, false) with { Predicted = new(2, 0, 0) }]).Best == null,
    "future unengaged overlap blocks selection");
Check(Analyze([E(1, 1, 0), E(2, 2, 0, false) with { Predicted = new(30, 0, 0) }]).Best == null,
    "observed unengaged overlap blocks even if predicted to leave");
Check(Analyze([E(1, 10, 0), E(2, 10, 2), E(3, -10, 0)], line).Best?.Hits == 2, "line aims down best cluster");
Check(Analyze([E(1, 5, 0), E(2, 5, 4), E(3, -5, 0)], cone).Best?.Hits == 2, "cone aim optimization");
Check(Analyze([E(1, 10, 0), E(2, 15.8f, 0, radius: 1)], hitboxes: true).Best?.Hits == 2, "hitbox mode counts edge victim");
Check(Analyze([E(1, 10, 0), E(2, 15.8f, 0, radius: 1)], hitboxes: false).Best?.Hits == 1, "center-only mode supported");

var tracker = new MotionTracker();
Near(tracker.Observe(1, Vector3.Zero, 0, 0.5f).X, 0, "first sample not predicted");
Near(tracker.Observe(1, new(0.6f, 0, 0), 0.1, 0.5f).X, 3.6f, "steady motion extrapolation");
Near(tracker.Observe(1, new(0.6f, 0, 0), 0.11, 0.5f).X, 3.6f, "explicit click rescan retains velocity");
Near(tracker.Observe(1, new(20, 0, 0), 0.2, 0.5f).X, 20, "dash resets extrapolation");
Near(tracker.Observe(1, new(20.6f, 0, 0), 1.2, 0.5f).X, 20.6f, "stale sample resets extrapolation");
Near(tracker.Observe(1, new(21.2f, 0, 0), 1.3, 0).X, 21.2f, "zero prediction horizon");
tracker.Prune(3); Check(tracker.Count == 0, "departed objects pruned");
tracker.Observe(1, Vector3.Zero, 4, 1); tracker.Clear(); Check(tracker.Count == 0, "zone reset clears history");
var validPlan = a.Best!;
Check(SelectionPolicy.BlockReason(true, true, false, false, false, validPlan) == null, "explicit selection allowed");
Check(SelectionPolicy.BlockReason(false, true, false, false, false, validPlan) != null, "disabled blocks selection");
Check(SelectionPolicy.BlockReason(true, false, false, false, false, validPlan) != null, "death blocks selection");
Check(SelectionPolicy.BlockReason(true, true, true, false, false, validPlan) != null, "loading blocks selection");
Check(SelectionPolicy.BlockReason(true, true, false, true, false, validPlan) != null, "casting blocks selection");
Check(SelectionPolicy.BlockReason(true, true, false, false, true, validPlan) != null, "demo blocks selection");
Check(SelectionPolicy.BlockReason(true, true, false, false, false, null) != null, "missing target blocks selection");

// Independent numerical oracle for circle/sector boundaries, including both signs of the lateral axis.
var rng = new Random(13987);
for (var n = 0; n < 1600; n++)
{
    var p = new Vector2((float)rng.NextDouble() * 30 - 15, (float)rng.NextDouble() * 30 - 15);
    var radius = (float)rng.NextDouble() * 2;
    var inside = p.Length() <= cone.Length && MathF.Abs(MathF.Atan2(p.Y, p.X)) <= MathF.PI / 4;
    var distance = float.MaxValue;
    for (var i = 0; i <= 1000; i++)
    {
        var angle = -MathF.PI / 4 + MathF.PI / 2 * i / 1000;
        var edge = new Vector2(MathF.Cos(angle), MathF.Sin(angle)) * cone.Length;
        distance = MathF.Min(distance, Vector2.Distance(p, edge));
    }
    foreach (var angle in new[] { -MathF.PI / 4, MathF.PI / 4 })
    {
        var edge = new Vector2(MathF.Cos(angle), MathF.Sin(angle)) * cone.Length;
        for (var i = 0; i <= 1000; i++) distance = MathF.Min(distance, Vector2.Distance(p, edge * i / 1000));
    }
    // Numerical oracle has finite resolution; skip samples within its discretization error.
    if (MathF.Abs(distance - radius) > 0.025f)
        Check(Hit(cone, p.X, p.Y, radius) == (inside || distance <= radius), $"sector oracle {n}");
}

// Rotation invariance and deterministic target election under randomized object-table ordering.
for (var n = 0; n < 300; n++)
{
    var points = Enumerable.Range(1, 20).Select(i => E((ulong)i, (float)rng.NextDouble() * 40 - 20,
        (float)rng.NextDouble() * 40 - 20)).ToArray();
    var profile = n % 3 == 0 ? circle : n % 3 == 1 ? cone : line;
    var expected = Analyze(points, profile, 7);
    Check(Analyze(points.OrderBy(_ => rng.Next()).ToArray(), profile, 7).Best?.TargetId == expected.Best?.TargetId,
        $"stable election permutation {n}");
    var rotation = Matrix4x4.CreateRotationY(0.62f);
    var rotated = points.Select(e => e with { Position = Vector3.Transform(e.Position, rotation),
        Predicted = Vector3.Transform(e.Predicted, rotation) }).ToArray();
    Check(Analyze(rotated, profile, 7).Best?.Hits == expected.Best?.Hits, $"rotation invariant hit count {n}");
}
var corrupt = new Profile { Radius = float.NaN, CastRange = float.PositiveInfinity, AngleDegrees = -400, Shape = (Shape)999 };
corrupt.Normalize();
Check(corrupt.Radius == 5 && corrupt.CastRange == 25 && corrupt.AngleDegrees == 5 && corrupt.Shape == Shape.Circle, "corrupt config normalized");

var busy = Enumerable.Range(1, 144).Select(i => E((ulong)i, (float)rng.NextDouble() * 60 - 30,
    (float)rng.NextDouble() * 60 - 30)).ToArray();
var timer = Stopwatch.StartNew();
for (var i = 0; i < 100; i++) Analyze(busy, cone, 7);
timer.Stop();
Console.WriteLine($"PASS: {checks} assertions. 144-enemy planner average: {timer.Elapsed.TotalMilliseconds / 100:F3} ms (local synthetic benchmark).");
