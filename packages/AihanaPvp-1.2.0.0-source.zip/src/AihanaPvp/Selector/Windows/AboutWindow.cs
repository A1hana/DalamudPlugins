using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility.Raii;
using Dalamud.Interface.Windowing;

namespace PvpAutoLb.Windows;

public sealed class AboutWindow : Window, IDisposable
{
    public AboutWindow() : base("PVP 选人助手 — About###PvpAutoLbAbout")
    {
        Size = new Vector2(420, 190);
        SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints
        {
            MinimumSize = new Vector2(360, 160),
            MaximumSize = new Vector2(560, 320),
        };
    }

    public void Dispose() { }

    public override void Draw()
    {
        using var style = Styling.PushWindowStyle();

        ImGui.SetWindowFontScale(1.35f);
        using (ImRaii.PushColor(ImGuiCol.Text, Styling.TextStrong))
            ImGui.TextUnformatted("PVP 选人助手");
        ImGui.SetWindowFontScale(1f);

        using (ImRaii.PushColor(ImGuiCol.Text, Styling.TextSecondary))
            ImGui.TextUnformatted("通过 /pvp 打开统一菜单");

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();

        using (ImRaii.PushColor(ImGuiCol.Text, Styling.TextDim))
            ImGui.TextWrapped("Selects an eligible PvP target when your Limit Break is ready. Target-only mode is the default; automatic LB use can be enabled in Settings.");

        ImGui.Spacing();
        using (ImRaii.PushColor(ImGuiCol.Text, Styling.TextMuted))
            ImGui.TextUnformatted($"Build {typeof(AboutWindow).Assembly.GetName().Version}");
    }
}
